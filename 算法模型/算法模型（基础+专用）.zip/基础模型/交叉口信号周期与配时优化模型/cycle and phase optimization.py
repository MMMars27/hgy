cycle_length = 60 # 初始信号周期
total_cycle_length = cycle_length # 当前周期结束的时间（绝对时间）
last_cycle_length = 0 # 上一个周期的长度
g1_ = None
g2_ = None
g_min = 5
g_max = 50
start_time_of_current_cycle = 0
s = 1800
tls_id = "C"


def signal_optimization():
    global cycle_length, total_cycle_length, last_cycle_length, g1_, g2_, start_time_of_current_cycle
    time = traci.simulation.getTime()
    if time > 0 and time % total_cycle_length == 0:
        y_WE = max_q_WE * 3600 / (1800 * cycle_length)
        y_NS = max_q_NS * 3600 / (1800 * cycle_length)
        last_cycle_length = cycle_length
        start_time_of_current_cycle = total_cycle_length
        print(f'start_time_of_current_cycle: ', start_time_of_current_cycle)
        print(f'last cycle length:', last_cycle_length)
        if y_NS + y_WE < 1:
            cycle_length = int((1.5 * 6 + 5) / (1 - y_NS - y_WE))
            print(f'new cycle length:', cycle_length)
        else:
            cycle_length = cycle_length
        total_cycle_length = total_cycle_length + cycle_length
        print(f'cumulated cycle length:', total_cycle_length)

        r1 = (q_WE * 3600) / (4 * s * last_cycle_length)
        r2 = (q_NS * 3600) / (4 * s * last_cycle_length)

        model = gp.Model("my_model")
        g1 = model.addVar(vtype=GRB.INTEGER, name="g1", lb=g_min, ub=g_max)
        g2 = model.addVar(vtype=GRB.INTEGER, name="g2", lb=g_min, ub=g_max)
        lamda1 = model.addVar(vtype=GRB.CONTINUOUS, name="lamda1")
        lamda2 = model.addVar(vtype=GRB.CONTINUOUS, name="lamda2")
        n1 = model.addVar(vtype=GRB.CONTINUOUS, name="n1")
        n2 = model.addVar(vtype=GRB.CONTINUOUS, name="n2")
        k1 = model.addVar(vtype=GRB.CONTINUOUS, name="k1")
        k2 = model.addVar(vtype=GRB.CONTINUOUS, name="k2")
        p1 = model.addVar(vtype=GRB.CONTINUOUS, name="p1")
        p2 = model.addVar(vtype=GRB.CONTINUOUS, name="p2")
        d1 = gp.QuadExpr()
        d1.addTerms(cycle_length, p1, k1)
        d1.addConstant((r1 ** 2 / (2 * q_WE * (1 - r1))))
        d2 = gp.QuadExpr()
        d2.addTerms(cycle_length, p2, k2)
        d2.addConstant((r2 ** 2 / (2 * q_NS * (1 - r2))))
        model.setObjective(d1 * q_WE + d2 * q_NS, GRB.MINIMIZE)
        model.addConstr(g1 + g2 == cycle_length, "c1")
        model.addConstr(lamda1 == g1 / cycle_length, "c2")
        model.addConstr(lamda2 == g2 / cycle_length, "c3")
        model.addConstr(n1 == 1 - lamda1, "c4")
        model.addConstr(n2 == 1 - lamda2, "c5")
        model.addConstr(k1 == 1 / (2 * (1 - lamda1 * r1)), "c4")
        model.addConstr(k2 == 1 / (2 * (1 - lamda2 * r2)), "c5")
        model.addConstr(p1 == n1 * n1, "c6")
        model.addConstr(p2 == n2 * n2, "c7")
        model.optimize()
        if model.status == gp.GRB.OPTIMAL:
            g1_ = g1.x
            g2_ = g2.x
            print(f"Optimal value of g1: {int(g1_)}")
            print(f"Optimal value of g2: {int(g2_)}")
            print(f"Optimal value of the objective function: {model.objVal}")
        else:
            print('无解')
        current_program = traci.trafficlight.getAllProgramLogics("C")[0]
        phases = current_program.phases
        phases[0].duration = g1_
        phases[1].duration = g2_
        current_program.phases = phases
        traci.trafficlight.setProgramLogic("C", current_program)