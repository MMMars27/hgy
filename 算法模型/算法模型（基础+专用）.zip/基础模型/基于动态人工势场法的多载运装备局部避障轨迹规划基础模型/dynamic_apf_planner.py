from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib.pyplot as plt
import numpy as np


@dataclass
class MovingObject:
    object_id: str
    object_type: str
    x: float
    y: float
    vx: float
    vy: float
    radius: float

    @property
    def position(self) -> np.ndarray:
        return np.array([self.x, self.y], dtype=float)

    @property
    def velocity(self) -> np.ndarray:
        return np.array([self.vx, self.vy], dtype=float)


@dataclass
class PlanningTarget:
    goal_x: float = 50.0
    goal_y: float = 0.0
    ego_radius: float = 1.2

    @property
    def goal(self) -> np.ndarray:
        return np.array([self.goal_x, self.goal_y], dtype=float)


@dataclass
class APFConfig:
    k_att: float = 0.75
    k_rep: float = 28.0
    influence_radius: float = 7.0
    safety_margin: float = 0.8
    max_speed: float = 6.0
    dt: float = 0.10
    max_plan_time: float = 90.0
    goal_tolerance: float = 0.8


@dataclass
class TrajectoryPoint:
    step: int
    time_s: float
    x: float
    y: float
    vx: float
    vy: float
    speed: float
    min_clearance: float
    attractive_force: float
    repulsive_force: float


def demo_inputs() -> Tuple[List[MovingObject], PlanningTarget, APFConfig]:
    objects = [
        MovingObject('ego', 'ego', 0.0, 0.0, 3.5, 0.0, 1.2),
        MovingObject('obj_1', 'vehicle', 15.0, 0.4, 1.0, 0.0, 1.5),
        MovingObject('obj_2', 'vehicle', 27.0, -1.7, 0.7, 0.25, 1.4),
        MovingObject('obj_3', 'vehicle', 38.0, 2.2, 0.5, -0.15, 1.3),
    ]
    target = PlanningTarget(goal_x=50.0, goal_y=0.0, ego_radius=1.2)
    config = APFConfig()
    return objects, target, config


def _parse_scalar(value: str):
    s = value.strip()
    if s.lower() in {'true', 'false'}:
        return s.lower() == 'true'
    try:
        if any(c in s.lower() for c in ('.', 'e')):
            return float(s)
        return int(s)
    except ValueError:
        return s.strip('"\'')


def load_state_csv(path: Path) -> List[MovingObject]:
    objects: List[MovingObject] = []
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            objects.append(
                MovingObject(
                    object_id=row['object_id'],
                    object_type=row['object_type'],
                    x=float(row['x']),
                    y=float(row['y']),
                    vx=float(row['vx']),
                    vy=float(row['vy']),
                    radius=float(row['radius']),
                )
            )
    return objects


def load_target_json(path: Path) -> PlanningTarget:
    data = json.loads(path.read_text(encoding='utf-8'))
    return PlanningTarget(
        goal_x=float(data['goal_x']),
        goal_y=float(data['goal_y']),
        ego_radius=float(data['ego_radius']),
    )


def load_config_toml(path: Path) -> APFConfig:
    # The configuration used by this model is a flat TOML key/value file, so a
    # tiny parser keeps the script self-contained and avoids extra dependencies.
    data: Dict[str, object] = {}
    for raw in path.read_text(encoding='utf-8').splitlines():
        line = raw.split('#', 1)[0].strip()
        if not line or '=' not in line:
            continue
        key, value = line.split('=', 1)
        data[key.strip()] = _parse_scalar(value)
    defaults = asdict(APFConfig())
    defaults.update(data)
    return APFConfig(**defaults)


def write_demo_inputs(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    objects, target, config = demo_inputs()

    with (directory / 'interaction_state.csv').open(
        'w', newline='', encoding='utf-8-sig'
    ) as f:
        writer = csv.writer(f)
        writer.writerow(['object_id', 'object_type', 'x', 'y', 'vx', 'vy', 'radius'])
        for obj in objects:
            writer.writerow([
                obj.object_id, obj.object_type, obj.x, obj.y,
                obj.vx, obj.vy, obj.radius,
            ])

    (directory / 'planning_target.json').write_text(
        json.dumps(asdict(target), ensure_ascii=False, indent=2), encoding='utf-8'
    )

    config_lines = [
        f'k_att = {config.k_att}',
        f'k_rep = {config.k_rep}',
        f'influence_radius = {config.influence_radius}',
        f'safety_margin = {config.safety_margin}',
        f'max_speed = {config.max_speed}',
        f'dt = {config.dt}',
        f'max_plan_time = {config.max_plan_time}',
        f'goal_tolerance = {config.goal_tolerance}',
    ]
    (directory / 'config.toml').write_text('\n'.join(config_lines) + '\n', encoding='utf-8')


def attractive_force(position: np.ndarray, goal: np.ndarray, k_att: float) -> np.ndarray:
    return k_att * (goal - position)


def repulsive_force(
    position: np.ndarray,
    obstacle_position: np.ndarray,
    combined_radius: float,
    goal_direction: np.ndarray,
    config: APFConfig,
) -> np.ndarray:
    delta = position - obstacle_position
    center_distance = float(np.linalg.norm(delta))
    if center_distance < 1e-9:
        delta = np.array([0.0, 1.0])
        center_distance = 1e-9

    clearance = center_distance - combined_radius
    if clearance >= config.influence_radius:
        return np.zeros(2, dtype=float)

    min_clearance_eps = 0.15
    tangential_gain = 0.22
    d = max(clearance, min_clearance_eps)
    rep_mag = config.k_rep * (
        1.0 / d - 1.0 / config.influence_radius
    ) / (d ** 2)

    away = delta / center_distance
    rep = rep_mag * away

    # A small tangential component breaks the symmetric local minimum that can
    # appear when a moving obstacle lies exactly on the goal line. The side is
    # chosen deterministically and still remains dominated by the repulsive term.
    tangent_a = np.array([away[1], -away[0]], dtype=float)
    tangent_b = -tangent_a

    # Prefer the tangent that keeps a positive component toward the goal. If the
    # two are tied (e.g. obstacle directly ahead), choose upward passage.
    score_a = float(np.dot(tangent_a, goal_direction))
    score_b = float(np.dot(tangent_b, goal_direction))
    if abs(score_a - score_b) < 1e-9:
        tangent = tangent_a if tangent_a[1] >= tangent_b[1] else tangent_b
    else:
        tangent = tangent_a if score_a > score_b else tangent_b

    rep += tangential_gain * rep_mag * tangent
    return rep


def plan_trajectory(
    objects: List[MovingObject],
    target: PlanningTarget,
    config: APFConfig,
) -> Tuple[List[TrajectoryPoint], Dict[str, object]]:
    ego_candidates = [o for o in objects if o.object_type.lower() == 'ego']
    if len(ego_candidates) != 1:
        raise ValueError('Exactly one object with object_type=ego is required.')

    ego = ego_candidates[0]
    obstacles = [o for o in objects if o.object_id != ego.object_id]

    position = ego.position.copy()
    velocity = ego.velocity.copy()
    goal = target.goal
    start = position.copy()

    records: List[TrajectoryPoint] = []
    path_length = 0.0
    global_min_clearance = float('inf')
    collision = False
    start_clock = time.perf_counter()

    max_steps = max(1, int(math.ceil(config.max_plan_time / config.dt)))
    for step in range(max_steps + 1):
        t = step * config.dt
        goal_vector = goal - position
        goal_distance = float(np.linalg.norm(goal_vector))
        if goal_distance <= config.goal_tolerance:
            break

        goal_direction = goal_vector / max(goal_distance, 1e-9)
        f_att = attractive_force(position, goal, config.k_att)
        f_rep_total = np.zeros(2, dtype=float)
        min_clearance = float('inf')

        for obs in obstacles:
            obs_pos = obs.position + obs.velocity * t
            combined_radius = target.ego_radius + obs.radius + config.safety_margin
            clearance = float(np.linalg.norm(position - obs_pos)) - combined_radius
            min_clearance = min(min_clearance, clearance)
            global_min_clearance = min(global_min_clearance, clearance)
            if clearance < 0.0:
                collision = True

            f_rep_total += repulsive_force(
                position,
                obs_pos,
                combined_radius,
                goal_direction,
                config,
            )

        total_force = f_att + f_rep_total
        force_norm = float(np.linalg.norm(total_force))
        if force_norm < 1e-9:
            desired_velocity = config.max_speed * goal_direction
        else:
            desired_velocity = config.max_speed * total_force / force_norm

        # Smooth the velocity command so the path is continuous and easier to
        # track by a downstream controller.
        velocity = (
            (1.0 - 0.45) * velocity
            + 0.45 * desired_velocity
        )
        speed = float(np.linalg.norm(velocity))
        if speed > config.max_speed:
            velocity *= config.max_speed / speed
            speed = config.max_speed

        records.append(
            TrajectoryPoint(
                step=step,
                time_s=t,
                x=float(position[0]),
                y=float(position[1]),
                vx=float(velocity[0]),
                vy=float(velocity[1]),
                speed=speed,
                min_clearance=float(min_clearance),
                attractive_force=float(np.linalg.norm(f_att)),
                repulsive_force=float(np.linalg.norm(f_rep_total)),
            )
        )

        new_position = position + velocity * config.dt
        path_length += float(np.linalg.norm(new_position - position))
        position = new_position

    final_goal_distance = float(np.linalg.norm(goal - position))
    success = final_goal_distance <= config.goal_tolerance and not collision
    compute_ms = (time.perf_counter() - start_clock) * 1000.0

    # Append final state so the output trajectory includes the actual terminal point.
    final_t = len(records) * config.dt
    current_min = float('inf')
    for obs in obstacles:
        obs_pos = obs.position + obs.velocity * final_t
        combined_radius = target.ego_radius + obs.radius + config.safety_margin
        current_min = min(
            current_min,
            float(np.linalg.norm(position - obs_pos)) - combined_radius,
        )
    global_min_clearance = min(global_min_clearance, current_min)
    records.append(
        TrajectoryPoint(
            step=len(records),
            time_s=final_t,
            x=float(position[0]),
            y=float(position[1]),
            vx=float(velocity[0]),
            vy=float(velocity[1]),
            speed=float(np.linalg.norm(velocity)),
            min_clearance=float(current_min),
            attractive_force=float(np.linalg.norm(attractive_force(position, goal, config.k_att))),
            repulsive_force=0.0,
        )
    )

    mean_speed = float(np.mean([p.speed for p in records])) if records else 0.0
    summary: Dict[str, object] = {
        'model_name': '基于动态人工势场法的多载运装备局部避障轨迹规划基础模型',
        'success': bool(success),
        'collision': bool(collision),
        'steps': int(len(records) - 1),
        'travel_time_s': float(final_t),
        'path_length_m': float(path_length),
        'min_clearance_m': float(global_min_clearance),
        'final_goal_distance_m': float(final_goal_distance),
        'mean_speed_mps': mean_speed,
        'compute_time_ms': float(compute_ms),
        'start': [float(start[0]), float(start[1])],
        'goal': [float(goal[0]), float(goal[1])],
        'final_position': [float(position[0]), float(position[1])],
    }
    return records, summary


def save_results(
    trajectory: List[TrajectoryPoint],
    summary: Dict[str, object],
    objects: List[MovingObject],
    target: PlanningTarget,
    config: APFConfig,
    output_dir: Path,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    traj_path = output_dir / 'planned_trajectory.csv'
    with traj_path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow([
            'step', 'time_s', 'x', 'y', 'vx', 'vy', 'speed',
            'min_clearance', 'attractive_force', 'repulsive_force',
        ])
        for p in trajectory:
            writer.writerow([
                p.step, f'{p.time_s:.3f}', f'{p.x:.6f}', f'{p.y:.6f}',
                f'{p.vx:.6f}', f'{p.vy:.6f}', f'{p.speed:.6f}',
                f'{p.min_clearance:.6f}', f'{p.attractive_force:.6f}',
                f'{p.repulsive_force:.6f}',
            ])

    (output_dir / 'planning_summary.json').write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8'
    )

    (output_dir / 'final_state.txt').write_text(
        '\n'.join([
            f"final_x={summary['final_position'][0]:.6f}",
            f"final_y={summary['final_position'][1]:.6f}",
            f"mean_speed={summary['mean_speed_mps']:.6f}",
            f"goal_distance={summary['final_goal_distance_m']:.6f}",
        ]) + '\n',
        encoding='utf-8',
    )

    (output_dir / 'runtime_log.txt').write_text(
        '\n'.join([
            'model_name=dynamic_apf_local_planner',
            f"status={'PASS' if summary['success'] else 'FAIL'}",
            f"steps={summary['steps']}",
            f"compute_time_ms={summary['compute_time_ms']:.6f}",
        ]) + '\n',
        encoding='utf-8',
    )

    times = np.array([p.time_s for p in trajectory])
    xs = np.array([p.x for p in trajectory])
    ys = np.array([p.y for p in trajectory])
    clearances = np.array([p.min_clearance for p in trajectory])

    # Trajectory result figure
    fig = plt.figure(figsize=(9.0, 5.2))
    ax = plt.gca()
    ax.plot(xs, ys, linewidth=2.2, label='Planned trajectory')
    ax.scatter([xs[0]], [ys[0]], marker='o', s=70, label='Start')
    ax.scatter([target.goal_x], [target.goal_y], marker='*', s=150, label='Goal')

    t_end = times[-1]
    for obs in [o for o in objects if o.object_type.lower() != 'ego']:
        t_line = np.linspace(0.0, t_end, 80)
        ox = obs.x + obs.vx * t_line
        oy = obs.y + obs.vy * t_line
        ax.plot(ox, oy, linestyle='--', linewidth=1.2, label=f'{obs.object_id} motion')
        ax.scatter([obs.x], [obs.y], marker='s', s=55)

    ax.set_xlabel('x / m')
    ax.set_ylabel('y / m')
    ax.grid(alpha=0.25)
    ax.axis('equal')
    ax.legend(ncol=2, fontsize=8)
    fig.tight_layout()
    fig.savefig(output_dir / 'trajectory_result.png', dpi=180)
    plt.close(fig)

    # Clearance result figure
    fig = plt.figure(figsize=(8.2, 4.5))
    ax = plt.gca()
    ax.plot(times, clearances, linewidth=2.0, label='Minimum clearance')
    ax.axhline(0.0, linestyle='--', linewidth=1.0, label='Collision boundary')
    ax.set_xlabel('time / s')
    ax.set_ylabel('minimum clearance / m')
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / 'clearance_result.png', dpi=180)
    plt.close(fig)


def run_from_args(args: argparse.Namespace) -> Tuple[List[TrajectoryPoint], Dict[str, object]]:
    if args.write_demo_data:
        write_demo_inputs(Path(args.write_demo_data))
        print(f'Demo input files written to: {args.write_demo_data}')
        return [], {}

    if args.demo or not (args.state and args.target and args.config):
        objects, target, config = demo_inputs()
    else:
        objects = load_state_csv(Path(args.state))
        target = load_target_json(Path(args.target))
        config = load_config_toml(Path(args.config))

    trajectory, summary = plan_trajectory(objects, target, config)
    save_results(
        trajectory,
        summary,
        objects,
        target,
        config,
        Path(args.output_dir),
    )

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return trajectory, summary


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description='Dynamic artificial-potential-field local trajectory planner.'
    )
    parser.add_argument('--state', type=str, help='interaction_state.csv')
    parser.add_argument('--target', type=str, help='planning_target.json')
    parser.add_argument('--config', type=str, help='config.toml')
    parser.add_argument('--output-dir', type=str, default='data/output')
    parser.add_argument('--demo', action='store_true', help='Run the built-in test case.')
    parser.add_argument(
        '--write-demo-data',
        type=str,
        help='Write the exact demo input files to the specified directory and exit.',
    )
    return parser


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    run_from_args(args)


if __name__ == '__main__':
    main()
