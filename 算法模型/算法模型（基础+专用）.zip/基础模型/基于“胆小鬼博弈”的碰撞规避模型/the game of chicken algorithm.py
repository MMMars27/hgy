import random

def init():
    v = random.uniform(20, 40)
    d = random.uniform(0, 90)
    return [d, v, 0]

def cal_time(car):
    return (90 - car[0]) / car[1] + (110 + car[0]) / car[2]

def tradition(car):
    car1, car2, car3, car4 = car
    return max(200 / car1[1], 200 / car3[1]) + max(200 / car2[1], 200 / car4[1])

def game_run(player1, player2, car):
    car1, car2, car3, car4 = car
    car1[2] = car1[1] * (1 + player2[0] * 0.4)
    car2[2] = car2[1] * (1 + player1[0] * 0.4)
    car3[2] = car3[1] * (1 + player2[1] * 0.4)
    car4[2] = car4[1] * (1 + player1[1] * 0.4)
    accident = any([abs((car4[0] + 15) / car4[2] - (car1[0] + 5) / car1[2]) < 1,
                    abs((car1[0] + 15) / car1[2] - (car2[0] + 5) / car2[2]) < 1,
                    abs((car2[0] + 15) / car2[2] - (car3[0] + 5) / car3[2]) < 1,
                    abs((car3[0] + 15) / car3[2] - (car4[0] + 5) / car4[2]) < 1])
    return (cal_time(car1) + cal_time(car2) + cal_time(car3) + cal_time(car4)) / 4 + accident * 9999999

def main():
    action = [[1, 1], [1, 0], [1, -1], [0, 1], [0, 0], [0, -1], [-1, 1], [-1, 0], [-1, 1]]
    car = [init(), init(), init(), init()]
    print("init car:", car)
    min_t = 999
    min_t_action = None
    for i in range(9):
        for j in range(9):
            t = game_run(action[i], action[j], car)  # run(player1, player2)
            if t < 9999999:
                print("%.1f" % t, end=" ")
                if t < min_t:
                    min_t = t
                    min_t_action = [action[i], action[j]]
            else:
                print("inf", end=" ")
        print()
    if min_t_action:
        print("min of game: ", min_t_action, "%.1f" % min_t)
    else:
        print("min of game: accident")
    print("tradition time: ", "%.1f" % tradition(car))

if __name__ == "__main__":
    main()