#!/usr/bin/env python3
"""Graph-consensus multi-vehicle speed decision with a safety-barrier filter.

The model computes longitudinal target accelerations and speeds for a connected
vehicle group. A graph-consensus controller provides cooperative nominal
commands, while a time-headway control-barrier inequality limits unsafe closing
acceleration. The script is self-contained and writes CSV, JSON and PNG results.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import time
from dataclasses import dataclass
from pathlib import Path
from statistics import fmean, pstdev

from PIL import Image, ImageDraw, ImageFont


@dataclass
class VehicleState:
    vehicle_id: str
    position: float
    speed: float
    acceleration: float = 0.0


DEFAULT_CONFIG = {
    "simulation": {"duration": 30.0, "dt": 0.1, "random_seed": 20260903},
    "vehicle": {
        "length": 4.5,
        "initial_positions": [0.0, -22.0, -45.0, -69.0, -94.0, -120.0],
        "initial_speeds": [14.0, 9.0, 11.0, 8.0, 10.0, 7.0],
    },
    "graph": {
        # adjacency_matrix[i][j] is the weight of vehicle j's speed received by i.
        "adjacency_matrix": [
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 1.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 1.0, 0.0],
        ],
        "leader_pinning_weight": [1.0, 0.30, 0.25, 0.20, 0.15, 0.10],
    },
    "control": {
        "reference_speed": 15.0,
        "minimum_gap": 5.0,
        "time_headway": 1.0,
        "position_gain": 0.30,
        "velocity_gain": 0.85,
        "leader_gain": 0.20,
        "reference_gain": 0.25,
        "barrier_gain": 0.90,
        "acceleration_min": -3.0,
        "acceleration_max": 2.0,
        "jerk_limit": 2.5,
        "speed_min": 0.0,
        "speed_max": 22.0,
        "communication_dropout": 0.05,
    },
}


def clip(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


def load_config(path: Path | None) -> dict:
    config = json.loads(json.dumps(DEFAULT_CONFIG))
    if path is None:
        return config
    supplied = json.loads(path.read_text(encoding="utf-8"))
    for section, values in supplied.items():
        if isinstance(values, dict) and section in config:
            config[section].update(values)
        else:
            config[section] = values
    return config


def validate_config(config: dict) -> None:
    positions = config["vehicle"]["initial_positions"]
    speeds = config["vehicle"]["initial_speeds"]
    if len(positions) != len(speeds) or len(positions) < 2:
        raise ValueError("initial_positions and initial_speeds must have equal length >= 2")
    if any(positions[i - 1] <= positions[i] for i in range(1, len(positions))):
        raise ValueError("vehicles must be ordered from front to rear")
    if config["simulation"]["dt"] <= 0 or config["simulation"]["duration"] <= 0:
        raise ValueError("duration and dt must be positive")
    if config["control"]["time_headway"] <= 0:
        raise ValueError("time_headway must be positive")
    adjacency = config["graph"]["adjacency_matrix"]
    pinning = config["graph"]["leader_pinning_weight"]
    vehicle_count = len(positions)
    if len(adjacency) != vehicle_count or any(len(row) != vehicle_count for row in adjacency):
        raise ValueError("adjacency_matrix must be square and match the vehicle count")
    if len(pinning) != vehicle_count:
        raise ValueError("leader_pinning_weight must match the vehicle count")
    if any(weight < 0 for row in adjacency for weight in row) or any(weight < 0 for weight in pinning):
        raise ValueError("graph weights must be non-negative")
    if not config["control"]["acceleration_min"] < config["control"]["acceleration_max"]:
        raise ValueError("acceleration_min must be smaller than acceleration_max")
    if not 0.0 <= config["control"]["communication_dropout"] < 1.0:
        raise ValueError("communication_dropout must be in [0, 1)")


def desired_gap(speed: float, minimum_gap: float, time_headway: float) -> float:
    return minimum_gap + time_headway * speed


def nominal_consensus_accelerations(states: list[VehicleState], config: dict, rng: random.Random) -> list[float]:
    ctl = config["control"]
    length = config["vehicle"]["length"]
    reference_speed = ctl["reference_speed"]
    adjacency = config["graph"]["adjacency_matrix"]
    pinning = config["graph"]["leader_pinning_weight"]
    commands: list[float] = []
    for i, ego in enumerate(states):
        if i == 0:
            commands.append(ctl["reference_gain"] * (reference_speed - ego.speed))
            continue
        ego, predecessor, leader = states[i], states[i - 1], states[0]
        spacing = predecessor.position - ego.position - length
        spacing_error = spacing - desired_gap(ego.speed, ctl["minimum_gap"], ctl["time_headway"])
        consensus_term = 0.0
        for j, weight in enumerate(adjacency[i]):
            if weight > 0.0 and rng.random() >= ctl["communication_dropout"]:
                consensus_term += weight * (states[j].speed - ego.speed)
        leader_difference = 0.0
        if pinning[i] > 0.0 and rng.random() >= ctl["communication_dropout"]:
            leader_difference = pinning[i] * (leader.speed - ego.speed)
        command = (
            ctl["position_gain"] * spacing_error
            + ctl["velocity_gain"] * consensus_term
            + ctl["leader_gain"] * leader_difference
            + ctl["reference_gain"] * (reference_speed - ego.speed)
        )
        commands.append(command)
    return commands


def safety_filter(states: list[VehicleState], nominal: list[float], config: dict) -> tuple[list[float], list[float]]:
    """Project nominal commands onto acceleration, jerk and CBF constraints."""
    ctl = config["control"]
    length = config["vehicle"]["length"]
    dt = config["simulation"]["dt"]
    accelerations, barrier_values = [], [math.inf]
    for i, state in enumerate(states):
        jerk_delta = ctl["jerk_limit"] * dt
        feasible_lower = max(ctl["acceleration_min"], state.acceleration - jerk_delta)
        feasible_upper = min(ctl["acceleration_max"], state.acceleration + jerk_delta)
        if i > 0:
            predecessor = states[i - 1]
            gap = predecessor.position - state.position - length
            h_value = gap - desired_gap(state.speed, ctl["minimum_gap"], ctl["time_headway"])
            # h_dot + alpha*h >= 0 gives an upper bound on the follower acceleration.
            cbf_upper = (
                predecessor.speed - state.speed + ctl["barrier_gain"] * h_value
            ) / ctl["time_headway"]
            feasible_upper = min(feasible_upper, cbf_upper)
            barrier_values.append(h_value)
        if feasible_lower <= feasible_upper:
            command = clip(nominal[i], feasible_lower, feasible_upper)
        else:
            # A CBF/jerk conflict is resolved in favor of collision avoidance.
            command = clip(feasible_upper, ctl["acceleration_min"], ctl["acceleration_max"])
        accelerations.append(command)
    return accelerations, barrier_values


def integrate(states: list[VehicleState], accelerations: list[float], config: dict) -> None:
    dt = config["simulation"]["dt"]
    ctl = config["control"]
    for state, acceleration in zip(states, accelerations):
        state.position += state.speed * dt + 0.5 * acceleration * dt * dt
        state.speed = clip(state.speed + acceleration * dt, ctl["speed_min"], ctl["speed_max"])
        state.acceleration = acceleration


def simulate(config: dict) -> tuple[list[dict], dict]:
    validate_config(config)
    rng = random.Random(config["simulation"]["random_seed"])
    positions = config["vehicle"]["initial_positions"]
    speeds = config["vehicle"]["initial_speeds"]
    states = [VehicleState(f"V{i + 1}", x, v) for i, (x, v) in enumerate(zip(positions, speeds))]
    dt = config["simulation"]["dt"]
    steps = int(round(config["simulation"]["duration"] / dt))
    length = config["vehicle"]["length"]
    rows: list[dict] = []
    start = time.perf_counter()
    for step in range(steps + 1):
        current_time = step * dt
        nominal = nominal_consensus_accelerations(states, config, rng)
        commands, barriers = safety_filter(states, nominal, config)
        for i, state in enumerate(states):
            physical_gap = math.inf if i == 0 else states[i - 1].position - state.position - length
            rows.append({
                "time_s": current_time,
                "vehicle_id": state.vehicle_id,
                "position_m": state.position,
                "speed_mps": state.speed,
                "nominal_acceleration_mps2": nominal[i],
                "command_acceleration_mps2": commands[i],
                "physical_gap_m": physical_gap,
                "barrier_margin_m": barriers[i],
            })
        if step < steps:
            integrate(states, commands, config)
    elapsed_ms = (time.perf_counter() - start) * 1000.0
    finite_gaps = [r["physical_gap_m"] for r in rows if math.isfinite(r["physical_gap_m"])]
    finite_barriers = [r["barrier_margin_m"] for r in rows if math.isfinite(r["barrier_margin_m"])]
    final_speeds = [state.speed for state in states]
    summary = {
        "vehicle_count": len(states),
        "duration_s": config["simulation"]["duration"],
        "reference_speed_mps": config["control"]["reference_speed"],
        "final_mean_speed_mps": fmean(final_speeds),
        "final_speed_std_mps": pstdev(final_speeds),
        "final_max_reference_error_mps": max(abs(v - config["control"]["reference_speed"]) for v in final_speeds),
        "minimum_physical_gap_m": min(finite_gaps),
        "minimum_barrier_margin_m": min(finite_barriers),
        "maximum_absolute_acceleration_mps2": max(abs(r["command_acceleration_mps2"]) for r in rows),
        "safety_violation_count": sum(1 for x in finite_barriers if x < -1e-6),
        "runtime_ms": elapsed_ms,
    }
    return rows, summary


def write_csv(rows: list[dict], path: Path) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: ("" if isinstance(v, float) and not math.isfinite(v) else f"{v:.6f}" if isinstance(v, float) else v) for k, v in row.items()})


def scale(value: float, low: float, high: float, pixel_low: float, pixel_high: float) -> float:
    if high <= low:
        return (pixel_low + pixel_high) / 2.0
    return pixel_low + (value - low) / (high - low) * (pixel_high - pixel_low)


def draw_chart(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], title: str,
               x_values: list[float], series: dict[str, list[float]], y_label: str,
               colors: list[str], font: ImageFont.FreeTypeFont, small: ImageFont.FreeTypeFont) -> None:
    left, top, right, bottom = box
    plot_left, plot_top, plot_right, plot_bottom = left + 72, top + 42, right - 25, bottom - 48
    values = [v for vals in series.values() for v in vals if math.isfinite(v)]
    y_min, y_max = min(values), max(values)
    pad = max((y_max - y_min) * 0.12, 0.5)
    y_min, y_max = y_min - pad, y_max + pad
    draw.rectangle((plot_left, plot_top, plot_right, plot_bottom), fill="white", outline="#333333", width=2)
    for j in range(5):
        y = plot_top + (plot_bottom - plot_top) * j / 4
        value = y_max - (y_max - y_min) * j / 4
        draw.line((plot_left, y, plot_right, y), fill="#dddddd", width=1)
        draw.text((plot_left - 8, y), f"{value:.1f}", font=small, fill="#333333", anchor="rm")
    for j in range(7):
        x = plot_left + (plot_right - plot_left) * j / 6
        value = x_values[-1] * j / 6
        draw.line((x, plot_top, x, plot_bottom), fill="#eeeeee", width=1)
        draw.text((x, plot_bottom + 8), f"{value:.0f}", font=small, fill="#333333", anchor="ma")
    for color, (name, vals) in zip(colors, series.items()):
        points = []
        for x, y in zip(x_values, vals):
            if math.isfinite(y):
                points.append((scale(x, x_values[0], x_values[-1], plot_left, plot_right), scale(y, y_min, y_max, plot_bottom, plot_top)))
        if len(points) > 1:
            draw.line(points, fill=color, width=3)
    draw.text(((left + right) / 2, top + 6), title, font=font, fill="#111111", anchor="ma")
    draw.text(((plot_left + plot_right) / 2, bottom - 4), "Time (s)", font=small, fill="#333333", anchor="ma")
    draw.text((left + 8, (plot_top + plot_bottom) / 2), y_label, font=small, fill="#333333", anchor="lm")
    lx = plot_left + 8
    for color, name in zip(colors, series):
        draw.line((lx, plot_top + 12, lx + 24, plot_top + 12), fill=color, width=4)
        draw.text((lx + 30, plot_top + 12), name, font=small, fill="#222222", anchor="lm")
        lx += 90


def plot_results(rows: list[dict], config: dict, path: Path) -> None:
    ids = sorted({r["vehicle_id"] for r in rows}, key=lambda x: int(x[1:]))
    times = sorted({r["time_s"] for r in rows})
    by_id = {vehicle_id: [r for r in rows if r["vehicle_id"] == vehicle_id] for vehicle_id in ids}
    font_path = "/System/Library/Fonts/Supplemental/Arial.ttf"
    font = ImageFont.truetype(font_path, 24)
    small = ImageFont.truetype(font_path, 17)
    image = Image.new("RGB", (1500, 1500), "white")
    draw = ImageDraw.Draw(image)
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"]
    speed_series = {v: [r["speed_mps"] for r in by_id[v]] for v in ids}
    gap_series = {v: [r["physical_gap_m"] for r in by_id[v]] for v in ids[1:]}
    accel_series = {v: [r["command_acceleration_mps2"] for r in by_id[v]] for v in ids}
    draw_chart(draw, (40, 30, 1460, 470), "Vehicle speed consensus", times, speed_series, "m/s", colors, font, small)
    draw_chart(draw, (40, 520, 1460, 960), "Inter-vehicle physical gap", times, gap_series, "m", colors[1:], font, small)
    draw_chart(draw, (40, 1010, 1460, 1450), "Safety-filtered acceleration", times, accel_series, "m/s^2", colors, font, small)
    image.save(path, "PNG", dpi=(180, 180))


def run(config_path: Path | None, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    config = load_config(config_path)
    rows, summary = simulate(config)
    write_csv(rows, output_dir / "consensus_trajectory.csv")
    (output_dir / "consensus_metrics.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    plot_results(rows, config, output_dir / "consensus_result.png")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, help="optional JSON configuration file")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"), help="result directory")
    args = parser.parse_args()
    run(args.config, args.output_dir)


if __name__ == "__main__":
    main()
