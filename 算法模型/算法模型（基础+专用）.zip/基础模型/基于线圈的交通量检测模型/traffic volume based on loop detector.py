detected_vehicles_WE = set()
detected_vehicles_NS = set()
# 以下根据具体场景修改检测器id
WE_loop_IDlist = ["WC_0", "WC_1", "EC_0", "EC_1"]
WE_loop_flow = {"WC_0": 0, "WC_1": 0, "EC_0": 0, "EC_1": 0}
NS_loop_IDlist = ["NC_0", "NC_1", "SC_0", "SC_1"]
NS_loop_flow = {"NC_0": 0, "NC_1": 0, "SC_0": 0, "SC_1": 0}
def main():
    q_WE = 0
    max_q_WE = 0
    for i in WE_loop_IDlist:
        current_vehicle_ids = traci.inductionloop.getLastStepVehicleIDs(i)
        new_vehicles_WE = [veh_id for veh_id in current_vehicle_ids if veh_id not in detected_vehicles_WE]
        detected_vehicles_WE.update(new_vehicles_WE)
        WE_loop_flow[i] += len(new_vehicles_WE)
    if time > 0 and time % total_cycle_length == 0:
        q_WE = sum(WE_loop_flow.values())
        max_q_WE = max(i for i in WE_loop_flow.values())
        for i in WE_loop_IDlist:
            WE_loop_flow[i] = 0

    q_NS = 0
    max_q_NS = 0
    for i in NS_loop_IDlist:
        current_vehicle_ids = traci.inductionloop.getLastStepVehicleIDs(i)
        new_vehicles_NS = [veh_id for veh_id in current_vehicle_ids if veh_id not in detected_vehicles_NS]
        detected_vehicles_NS.update(new_vehicles_NS)
        NS_loop_flow[i] += len(new_vehicles_NS)
    if time > 0 and time % total_cycle_length == 0:
        q_NS = sum(NS_loop_flow.values())
        max_q_NS = max(i for i in NS_loop_flow.values())
        for i in NS_loop_IDlist:
            NS_loop_flow[i] = 0

    if time > 0 and time % total_cycle_length == 0:
        print(f'**', time, f'**')
        print(f'q_WE:', q_WE)
        print(f'max_q_WE:', max_q_WE)
        print(f'q_NS:', q_NS)
        print(f'max_q_NS:', max_q_NS)