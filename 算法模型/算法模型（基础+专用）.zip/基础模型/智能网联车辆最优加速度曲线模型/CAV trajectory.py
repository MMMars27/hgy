M = 1680
alpha = 0.666
beta_1 = 0.072
beta_2 = 0.0344
d_1 = 0.269
d_2 = 0.0171
d_3 = 0.000672
v0 = 10
v_max = 20
v_min = 4.47
R = 300
safe_h = 2
a_max = 3
a_min = 0
decel_max = -3
controlled_CAVs = {}
completed_CAVs = set()
calculated_CAVs = {}

def get_CAV_acceleration(v_0, t_0, t_f, id):
    delta_t = 1
    model = gp.Model("my_model")
    model.setParam('NonConvex', 2)
    model.Params.NonConvex = 2
    model.Params.Heuristics = 0.8
    model.Params.MIPFocus = 3
    model.Params.MIPGap = 0.1
    model.Params.TimeLimit = 600
    model.Params.Threads = 16
    model.Params.FeasibilityTol = 1e-4
    model.Params.IntFeasTol = 1e-5

    variables_a = {}
    variables_v = {}
    indicators = {}
    variables_vv = {}
    variables_aav = {}
    variables_x = {}
    variables_a_sq = {}
    variables_v_cubic = {}

    for i in range(int(t_0), int(t_f + 2)):
        a_name = f'a{i}'
        v_name = f'v{i}'
        x_name = f'x{i}'
        variables_a[a_name] = model.addVar(vtype=gp.GRB.CONTINUOUS, name=a_name, lb=decel_max, ub=a_max)
        variables_v[v_name] = model.addVar(vtype=gp.GRB.CONTINUOUS, name=v_name, lb=v_min, ub=v_max)
        variables_x[x_name] = model.addVar(vtype=gp.GRB.CONTINUOUS, name=x_name, lb=0, ub=R + 20)
        indicators[a_name] = model.addVar(vtype=gp.GRB.BINARY, name=f"ind_{a_name}")
        variables_a_sq[a_name] = model.addVar(lb=0, ub=a_max ** 2, name=f"a_sq_{a_name}")
        variables_v_cubic[v_name] = model.addVar(lb=v_min ** 3, ub=v_max ** 3, name=f"v_cubic_{v_name}")
        model.addConstr(variables_a_sq[a_name] == variables_a[a_name] ** 2)
        variables_aav[a_name] = model.addVar(lb=0, ub=a_max ** 2 * v_max, name=f"aav_{a_name}")
        model.addConstr(variables_aav[a_name] == variables_a_sq[a_name] * variables_v[v_name])
        variables_vv[a_name] = model.addVar(lb=0, ub=v_max ** 2, name=f"v_sq_{a_name}")
        model.addConstr(variables_vv[a_name] == variables_v[v_name] ** 2)
    model.update()

    def fuel_consumption(a_t, v_t, aav_t, vv_t, ind_t):
        return (
                alpha
                + beta_1 * d_1 * v_t
                + beta_1 * d_2 * v_t ** 2
                + beta_1 * d_3 * vv_t * v_t
                + M * a_t * v_t / 1000
                + beta_2 * M * aav_t * ind_t
                + 0.5 * a_t ** 2
        )
    cost = alpha + beta_1 * (d_1 * v_0 + d_2 * (v_0 ** 2) + d_3 * (v_0 ** 3))
    a_names = natsorted(list(variables_a.keys()))
    v_names = natsorted(list(variables_v.keys()))
    x_names = natsorted(list(variables_x.keys()))

    # 计算总成本
    for index in range(len(a_names) - 1):
        a_t = variables_a[a_names[index + 1]]
        v_t = variables_v[v_names[index + 1]]
        aav_t = variables_aav[a_names[index + 1]]
        vv_t = variables_vv[a_names[index + 1]]
        ind_t = indicators[a_names[index + 1]]
        cost += fuel_consumption(a_t, v_t, aav_t, vv_t, ind_t)
    print(cost)
    model.setObjective(cost, GRB.MINIMIZE)
    model.update()

    model.addConstr(variables_v[v_names[0]] == v_0, 'first_v')
    model.addConstr(variables_x[x_names[0]] == 0, 'first_x')
    model.addConstr(variables_a[a_names[0]] == 0, 'first_a')

    for i in range(len(a_names) - 1):
        model.addConstr(variables_v[v_names[i+1]] == variables_v[v_names[i]] + variables_a[a_names[i+1]] * delta_t)
        model.addConstr(variables_x[x_names[i+1]] == variables_x[x_names[i]] + variables_v[v_names[i+1]] * delta_t)
    model.update()

    model.addConstr(variables_x[x_names[-1]] == 295, 'c_stop_line') # 修改
    model.addConstr(variables_v[v_names[-1]] == 20, 'c_pass_speed') # 修改
    model.update()

    for i in range(len(a_names)):
        epsilon = 1e-6
        model.addConstr((indicators[a_names[i]] == 1) >> (variables_a[a_names[i]] >= 0), 'positive_a')
        model.addConstr((indicators[a_names[i]] == 0) >> (variables_a[a_names[i]] <= -epsilon), 'negative_a')
    model.update()

    model.optimize()

    if model.status == GRB.Status.INFEASIBLE:
        model.computeIIS()
        model.write("model.ilp")

    if model.status == gp.GRB.OPTIMAL:
        a_list = [round(variables_a[i].X, 5) for i in a_names]
        v_list = [round(variables_v[i].X, 5) for i in v_names]
        x_list = [round(variables_x[i].X, 5) for i in x_names]
        print(model.objVal)
        print(f'！！！！optimal speed of {id}:', v_list)
    else:
        print("模型未找到可行解！")
        return [], [], []
    return a_list, v_list, x_list