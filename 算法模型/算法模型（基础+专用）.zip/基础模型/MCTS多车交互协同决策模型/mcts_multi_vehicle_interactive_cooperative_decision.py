#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MCTS多车交互协同决策模型

功能：
1) 读取多车状态、候选动作库与搜索配置；
2) 在搜索树中显式滚动自车动作和周车交互响应；
3) 以安全、通行效率、协作扰动和舒适性构造联合效用；
4) 输出最优动作、候选动作统计、预测轨迹、搜索统计与测试指标；
5) 可生成测试轨迹可视化图。

仅依赖 numpy 和 matplotlib（matplotlib 仅用于结果绘图）。
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import time
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

try:
    import tomllib  # Python >= 3.11
except ModuleNotFoundError:  # pragma: no cover
    tomllib = None


@dataclass(frozen=True)
class VehicleState:
    vehicle_id: str
    behavior_type: str
    x: float
    y: float
    speed: float
    heading: float
    desired_speed: float

    @property
    def vx(self) -> float:
        return self.speed * math.cos(self.heading)

    @property
    def vy(self) -> float:
        return self.speed * math.sin(self.heading)


@dataclass(frozen=True)
class Action:
    action_id: int
    name: str
    acceleration: float
    yaw_rate: float
    duration_steps: int = 1
    enabled: bool = True


@dataclass
class Config:
    dt: float = 0.5
    horizon_steps: int = 8
    simulations: int = 900
    exploration_c: float = 1.35
    safe_distance: float = 5.0
    w_safety: float = 6.0
    w_cooperation: float = 0.8
    w_efficiency: float = 1.0
    w_comfort: float = 0.15
    discount: float = 0.95
    max_speed: float = 20.0
    collision_distance: float = 2.4
    random_seed: int = 7


@dataclass
class TransitionInfo:
    min_distance: float
    min_ttc: float
    collision: bool
    agent_braking: float
    reward: float
    safety_reward: float
    efficiency_reward: float
    cooperation_reward: float
    comfort_reward: float


class Node:
    def __init__(
        self,
        state: Tuple[VehicleState, ...],
        actions: Sequence[Action],
        parent: Optional["Node"] = None,
        action: Optional[Action] = None,
        depth: int = 0,
        transition_info: Optional[TransitionInfo] = None,
    ) -> None:
        self.state = state
        self.actions = list(actions)
        self.parent = parent
        self.action = action
        self.depth = depth
        self.transition_info = transition_info
        self.children: List[Node] = []
        self.untried: List[Action] = list(actions)
        self.visits = 0
        self.value_sum = 0.0
        self.collision_rollouts = 0
        self.min_distance_seen = float("inf")

    @property
    def mean_value(self) -> float:
        return self.value_sum / self.visits if self.visits else 0.0


# --------------------------- I/O ---------------------------

def write_demo_inputs(input_dir: Path) -> None:
    input_dir.mkdir(parents=True, exist_ok=True)
    rows = [
        ["ego", "ego", 0.0, 0.0, 10.0, 0.0, 12.0],
        ["veh_front", "neutral", 28.0, 0.0, 7.5, 0.0, 9.0],
        ["veh_rear", "assertive", -18.0, 0.0, 11.5, 0.0, 13.0],
        ["veh_cross_s", "cooperative", 42.0, -14.0, 7.0, math.pi / 2, 8.0],
        ["veh_cross_n", "assertive", 46.0, 13.0, 8.0, -math.pi / 2, 9.0],
        ["veh_left", "neutral", 5.0, 5.2, 10.5, 0.0, 11.0],
        ["veh_right", "cooperative", 7.0, -5.2, 9.0, 0.0, 10.0],
        ["veh_front_left", "neutral", 32.0, 5.2, 7.0, 0.0, 9.0],
    ]
    with (input_dir / "scene_state.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["vehicle_id", "behavior_type", "x", "y", "speed", "heading", "desired_speed"])
        w.writerows(rows)

    actions = [
        {"action_id": 0, "name": "hard_brake", "acceleration": -3.0, "yaw_rate": 0.0, "duration_steps": 1, "enabled": True},
        {"action_id": 1, "name": "mild_brake", "acceleration": -1.4, "yaw_rate": 0.0, "duration_steps": 1, "enabled": True},
        {"action_id": 2, "name": "keep", "acceleration": 0.0, "yaw_rate": 0.0, "duration_steps": 1, "enabled": True},
        {"action_id": 3, "name": "accelerate", "acceleration": 1.0, "yaw_rate": 0.0, "duration_steps": 1, "enabled": True},
        {"action_id": 4, "name": "left_yield", "acceleration": -0.6, "yaw_rate": 0.08, "duration_steps": 1, "enabled": True},
        {"action_id": 5, "name": "right_yield", "acceleration": -0.6, "yaw_rate": -0.08, "duration_steps": 1, "enabled": True},
    ]
    (input_dir / "action_library.json").write_text(json.dumps(actions, ensure_ascii=False, indent=2), encoding="utf-8")

    config_text = """dt = 0.5
horizon_steps = 8
simulations = 900
exploration_c = 1.35
safe_distance = 5.0
"""
    (input_dir / "config.toml").write_text(config_text, encoding="utf-8")


def load_scene(path: Path) -> Tuple[VehicleState, ...]:
    states: List[VehicleState] = []
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            states.append(
                VehicleState(
                    vehicle_id=row["vehicle_id"],
                    behavior_type=row["behavior_type"].strip().lower(),
                    x=float(row["x"]),
                    y=float(row["y"]),
                    speed=float(row["speed"]),
                    heading=float(row["heading"]),
                    desired_speed=float(row["desired_speed"]),
                )
            )
    if not states:
        raise ValueError("scene_state.csv 为空")
    if states[0].behavior_type != "ego":
        # 为减少接口歧义，要求第一行为 ego。
        raise ValueError("scene_state.csv 第一行必须为 behavior_type=ego")
    return tuple(states)


def load_actions(path: Path) -> List[Action]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    actions = [
        Action(
            int(x["action_id"]),
            str(x["name"]),
            float(x["acceleration"]),
            float(x["yaw_rate"]),
            int(x.get("duration_steps", 1)),
            bool(x.get("enabled", True)),
        )
        for x in raw
        if bool(x.get("enabled", True))
    ]
    if not actions:
        raise ValueError("action_library.json 不能为空")
    return actions


def load_config(path: Path, seed_override: Optional[int] = None) -> Config:
    cfg = Config()
    if tomllib is not None:
        with path.open("rb") as f:
            data = tomllib.load(f)
    else:  # 极简兜底解析，仅支持 key = value
        data = {}
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = [x.strip() for x in line.split("=", 1)]
            data[k] = float(v) if "." in v else int(v)
    for key in ["dt", "horizon_steps", "simulations", "exploration_c", "safe_distance"]:
        if key in data:
            setattr(cfg, key, type(getattr(cfg, key))(data[key]))
    if seed_override is not None:
        cfg.random_seed = int(seed_override)
    return cfg


# --------------------------- Dynamics and interaction model ---------------------------

def advance_vehicle(v: VehicleState, acceleration: float, yaw_rate: float, cfg: Config, duration_steps: int = 1) -> VehicleState:
    # Semi-implicit integration; duration_steps 支持短时动作原语。
    dt = cfg.dt * max(1, int(duration_steps))
    new_speed = float(np.clip(v.speed + acceleration * dt, 0.0, cfg.max_speed))
    new_heading = v.heading + yaw_rate * dt
    new_x = v.x + new_speed * math.cos(new_heading) * dt
    new_y = v.y + new_speed * math.sin(new_heading) * dt
    return replace(v, x=new_x, y=new_y, speed=new_speed, heading=new_heading)


def closest_approach(a: VehicleState, b: VehicleState, horizon: float = 4.0) -> Tuple[float, float]:
    r = np.array([b.x - a.x, b.y - a.y], dtype=float)
    v = np.array([b.vx - a.vx, b.vy - a.vy], dtype=float)
    vv = float(v @ v)
    if vv < 1e-8:
        return float(np.linalg.norm(r)), float("inf")
    t = -float(r @ v) / vv
    if t <= 0.0:
        return float(np.linalg.norm(r)), float("inf")
    t_clip = min(t, horizon)
    d = float(np.linalg.norm(r + v * t_clip))
    return d, t if t <= horizon else float("inf")


def behavior_parameters(kind: str) -> Tuple[float, float, float]:
    """返回 (yield_gain, noise_sigma, response_gain)。"""
    if kind == "cooperative":
        return 1.15, 0.12, 0.80
    if kind == "assertive":
        return 0.28, 0.28, 0.45
    return 0.65, 0.20, 0.60


def predict_agent_acceleration(agent: VehicleState, ego: VehicleState, cfg: Config, rng: np.random.Generator) -> float:
    yield_gain, noise_sigma, response_gain = behavior_parameters(agent.behavior_type)
    base = np.clip(0.65 * (agent.desired_speed - agent.speed), -1.8, 1.0)
    d_ca, ttc = closest_approach(agent, ego, horizon=max(3.0, cfg.dt * cfg.horizon_steps))
    risk = 0.0
    if math.isfinite(ttc):
        spatial = max(0.0, cfg.safe_distance - d_ca) / max(cfg.safe_distance, 1e-6)
        temporal = max(0.0, 3.5 - ttc) / 3.5
        risk = spatial * (0.4 + 0.6 * temporal)
    # 合作型主体更容易在潜在冲突下减速，激进型主体保留更高期望速度。
    interaction_brake = 3.0 * yield_gain * risk
    noisy = float(base - interaction_brake + rng.normal(0.0, noise_sigma * (0.2 + risk)))
    # response_gain 控制主体对交互风险的响应速度。
    return float(np.clip(response_gain * noisy + (1.0 - response_gain) * base, -3.0, 1.2))


def transition(
    state: Tuple[VehicleState, ...],
    ego_action: Action,
    cfg: Config,
    rng: np.random.Generator,
) -> Tuple[Tuple[VehicleState, ...], TransitionInfo]:
    ego0 = state[0]
    ego1 = advance_vehicle(ego0, ego_action.acceleration, ego_action.yaw_rate, cfg, ego_action.duration_steps)
    next_states = [ego1]
    agent_braking = 0.0
    for agent in state[1:]:
        a = predict_agent_acceleration(agent, ego1, cfg, rng)
        agent1 = advance_vehicle(agent, a, 0.0, cfg, ego_action.duration_steps)
        agent_braking += max(0.0, agent.speed - agent1.speed)
        next_states.append(agent1)

    min_distance = float("inf")
    min_ttc = float("inf")
    collision = False
    for agent1 in next_states[1:]:
        d_now = math.hypot(agent1.x - ego1.x, agent1.y - ego1.y)
        d_ca, ttc = closest_approach(ego1, agent1, horizon=3.5)
        min_distance = min(min_distance, d_now, d_ca)
        if math.isfinite(ttc) and d_ca < cfg.safe_distance:
            min_ttc = min(min_ttc, ttc)
        if d_now < cfg.collision_distance:
            collision = True

    # 安全收益：碰撞给出强惩罚；安全距离内采用二次惩罚，并引入 TTC 约束。
    safety_reward = 0.0
    if collision:
        safety_reward -= 20.0
    if min_distance < cfg.safe_distance:
        safety_reward -= ((cfg.safe_distance - min_distance) / cfg.safe_distance) ** 2 * 4.0
    if math.isfinite(min_ttc) and min_ttc < 3.0:
        safety_reward -= ((3.0 - min_ttc) / 3.0) ** 2 * 2.5

    speed_error = abs(ego1.desired_speed - ego1.speed) / max(ego1.desired_speed, 1.0)
    efficiency_reward = 1.0 - speed_error
    # 频繁迫使周车强制减速会降低协作收益。
    cooperation_reward = -agent_braking / max(len(next_states) - 1, 1)
    comfort_reward = -(0.12 * ego_action.acceleration ** 2 + 0.08 * (ego_action.yaw_rate / 0.08) ** 2)

    reward = (
        cfg.w_safety * safety_reward
        + cfg.w_efficiency * efficiency_reward
        + cfg.w_cooperation * cooperation_reward
        + cfg.w_comfort * comfort_reward
    )
    info = TransitionInfo(
        min_distance=min_distance,
        min_ttc=min_ttc,
        collision=collision,
        agent_braking=agent_braking,
        reward=reward,
        safety_reward=safety_reward,
        efficiency_reward=efficiency_reward,
        cooperation_reward=cooperation_reward,
        comfort_reward=comfort_reward,
    )
    return tuple(next_states), info


# --------------------------- MCTS ---------------------------

def ucb_score(parent: Node, child: Node, c: float) -> float:
    if child.visits == 0:
        return float("inf")
    return child.mean_value + c * math.sqrt(math.log(parent.visits + 1.0) / child.visits)


def heuristic_action(state: Tuple[VehicleState, ...], actions: Sequence[Action], cfg: Config, rng: np.random.Generator) -> Action:
    # 轻量一阶试探，避免 rollout 完全随机导致方差过大。
    if rng.random() < 0.18:
        return actions[int(rng.integers(0, len(actions)))]
    best_action = actions[0]
    best_score = -float("inf")
    # 用独立种子做近似试探，避免改变主滚动随机数序列太多。
    for a in actions:
        local_rng = np.random.default_rng(int(rng.integers(0, 2**31 - 1)))
        _, info = transition(state, a, cfg, local_rng)
        if info.reward > best_score:
            best_score = info.reward
            best_action = a
    return best_action


def rollout(state: Tuple[VehicleState, ...], depth: int, actions: Sequence[Action], cfg: Config, rng: np.random.Generator) -> Tuple[float, bool, float]:
    total = 0.0
    gamma = 1.0
    collision = False
    min_distance = float("inf")
    s = state
    for _ in range(depth, cfg.horizon_steps):
        a = heuristic_action(s, actions, cfg, rng)
        s, info = transition(s, a, cfg, rng)
        total += gamma * info.reward
        gamma *= cfg.discount
        collision = collision or info.collision
        min_distance = min(min_distance, info.min_distance)
        if info.collision:
            break
    return total, collision, min_distance


def mcts(initial_state: Tuple[VehicleState, ...], actions: Sequence[Action], cfg: Config) -> Tuple[Node, Dict[str, float]]:
    rng = np.random.default_rng(cfg.random_seed)
    root = Node(initial_state, actions, depth=0)
    expanded_nodes = 1
    start = time.perf_counter()

    for _ in range(cfg.simulations):
        node = root
        cumulative = 0.0
        gamma = 1.0
        path_infos: List[TransitionInfo] = []

        # Selection
        while not node.untried and node.children and node.depth < cfg.horizon_steps:
            node = max(node.children, key=lambda ch: ucb_score(node, ch, cfg.exploration_c))
            if node.transition_info is not None:
                cumulative += gamma * node.transition_info.reward
                gamma *= cfg.discount
                path_infos.append(node.transition_info)
                if node.transition_info.collision:
                    break

        # Expansion
        if node.depth < cfg.horizon_steps and node.untried and not any(i.collision for i in path_infos):
            idx = int(rng.integers(0, len(node.untried)))
            action = node.untried.pop(idx)
            next_state, info = transition(node.state, action, cfg, rng)
            child = Node(next_state, actions, parent=node, action=action, depth=node.depth + 1, transition_info=info)
            node.children.append(child)
            node = child
            expanded_nodes += 1
            cumulative += gamma * info.reward
            gamma *= cfg.discount
            path_infos.append(info)

        # Simulation
        rollout_value = 0.0
        rollout_collision = any(i.collision for i in path_infos)
        rollout_min_distance = min((i.min_distance for i in path_infos), default=float("inf"))
        if not rollout_collision and node.depth < cfg.horizon_steps:
            rv, rc, rmin = rollout(node.state, node.depth, actions, cfg, rng)
            rollout_value = gamma * rv
            rollout_collision = rc
            rollout_min_distance = min(rollout_min_distance, rmin)

        total_value = cumulative + rollout_value

        # Backpropagation
        cur: Optional[Node] = node
        while cur is not None:
            cur.visits += 1
            cur.value_sum += total_value
            if rollout_collision:
                cur.collision_rollouts += 1
            cur.min_distance_seen = min(cur.min_distance_seen, rollout_min_distance)
            cur = cur.parent

    runtime_ms = (time.perf_counter() - start) * 1000.0
    stats = {
        "simulations": cfg.simulations,
        "max_depth": cfg.horizon_steps,
        "expanded_nodes": expanded_nodes,
        "runtime_ms": runtime_ms,
        "random_seed": cfg.random_seed,
    }
    return root, stats


def evaluate_root_actions(
    initial_state: Tuple[VehicleState, ...],
    actions: Sequence[Action],
    cfg: Config,
    trials: int = 45,
) -> Dict[int, Tuple[float, float]]:
    """返回 action_id -> (collision_rate, min_distance)。"""
    result: Dict[int, Tuple[float, float]] = {}
    for action in actions:
        collisions = 0
        min_d = float("inf")
        for k in range(trials):
            rng = np.random.default_rng(cfg.random_seed * 1000 + action.action_id * 100 + k)
            s, info = transition(initial_state, action, cfg, rng)
            coll = info.collision
            local_min = min(math.hypot(v.x - s[0].x, v.y - s[0].y) for v in s[1:])
            for depth in range(1, cfg.horizon_steps):
                a = heuristic_action(s, actions, cfg, rng)
                s, inf = transition(s, a, cfg, rng)
                coll = coll or inf.collision
                actual_min = min(math.hypot(v.x - s[0].x, v.y - s[0].y) for v in s[1:])
                local_min = min(local_min, actual_min)
                if inf.collision:
                    break
            collisions += int(coll)
            min_d = min(min_d, local_min)
        result[action.action_id] = (collisions / trials, min_d)
    return result


def select_action(root: Node, actions: Sequence[Action]) -> Action:
    if not root.children:
        return actions[0]
    # 鲁棒根节点策略：优先访问次数，其次平均价值。
    best = max(root.children, key=lambda ch: (ch.visits, ch.mean_value))
    return best.action if best.action is not None else actions[0]


def generate_representative_trajectory(
    initial_state: Tuple[VehicleState, ...],
    selected: Action,
    actions: Sequence[Action],
    cfg: Config,
) -> Tuple[np.ndarray, np.ndarray, float, float, int]:
    rng = np.random.default_rng(cfg.random_seed + 2026)
    s = initial_state
    ids = np.array([v.vehicle_id for v in s], dtype="U64")
    traj = np.zeros((cfg.horizon_steps + 1, len(s), 4), dtype=float)
    for j, v in enumerate(s):
        traj[0, j] = [v.x, v.y, v.speed, v.heading]
    min_d = float("inf")
    min_ttc = float("inf")
    collisions = 0
    for k in range(cfg.horizon_steps):
        # 第一步执行所选动作；后续采用低风险启发式滚动，代表下一次重规划前的短时预测。
        a = selected if k == 0 else heuristic_action(s, actions, cfg, rng)
        s, info = transition(s, a, cfg, rng)
        actual_min = min(math.hypot(v.x - s[0].x, v.y - s[0].y) for v in s[1:])
        min_d = min(min_d, actual_min)
        if math.isfinite(info.min_ttc):
            min_ttc = min(min_ttc, info.min_ttc)
        collisions += int(info.collision)
        for j, v in enumerate(s):
            traj[k + 1, j] = [v.x, v.y, v.speed, v.heading]
    times = np.arange(cfg.horizon_steps + 1, dtype=float) * cfg.dt
    return times, traj, min_d, min_ttc, collisions


# --------------------------- Outputs ---------------------------

def save_plot(output_dir: Path, ids: Sequence[str], traj: np.ndarray, selected: Action) -> None:
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return
    fig, ax = plt.subplots(figsize=(7.0, 4.6), dpi=180)
    for j, vid in enumerate(ids):
        lw = 2.4 if j == 0 else 1.25
        marker = "o" if j == 0 else None
        ax.plot(traj[:, j, 0], traj[:, j, 1], linewidth=lw, marker=marker, markersize=2.8, label=str(vid))
        ax.text(traj[0, j, 0], traj[0, j, 1], str(vid), fontsize=7)
    ax.set_xlabel("x / m")
    ax.set_ylabel("y / m")
    ax.set_title(f"Representative multi-vehicle rollout: {selected.name}")
    ax.grid(True, linewidth=0.5, alpha=0.35)
    ax.axis("equal")
    ax.legend(fontsize=6, ncol=2, loc="best")
    fig.tight_layout()
    fig.savefig(output_dir / "trajectory_result.png", bbox_inches="tight")
    plt.close(fig)


def write_outputs(
    output_dir: Path,
    initial_state: Tuple[VehicleState, ...],
    actions: Sequence[Action],
    cfg: Config,
    root: Node,
    selected: Action,
    tree_stats: Dict[str, float],
    eval_stats: Dict[int, Tuple[float, float]],
) -> Dict[str, float]:
    output_dir.mkdir(parents=True, exist_ok=True)
    times, traj, min_distance, min_ttc, collisions = generate_representative_trajectory(initial_state, selected, actions, cfg)
    ids = np.array([v.vehicle_id for v in initial_state], dtype="U64")

    selected_child = next((ch for ch in root.children if ch.action and ch.action.action_id == selected.action_id), None)
    root_visits = selected_child.visits if selected_child else 0
    root_value = selected_child.mean_value if selected_child else 0.0
    risk_score = max(0.0, (cfg.safe_distance - min_distance) / cfg.safe_distance)
    if math.isfinite(min_ttc):
        risk_score += max(0.0, (2.5 - min_ttc) / 2.5)
    risk_score = float(min(2.0, risk_score))

    selected_eval_collision, selected_eval_min_distance = eval_stats[selected.action_id]

    command = {
        "action": selected.name,
        "u": [selected.acceleration, selected.yaw_rate],
    }
    (output_dir / "command.json").write_text(
        json.dumps(command, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    search_stats = {
        "visits": int(root_visits),
        "value": float(root_value),
        "nodes": int(tree_stats["expanded_nodes"]),
        "runtime_ms": float(tree_stats["runtime_ms"]),
    }
    (output_dir / "search_stats.json").write_text(
        json.dumps(search_stats, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    with (output_dir / "action_values.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["action", "visits", "value"])
        child_by_id = {ch.action.action_id: ch for ch in root.children if ch.action is not None}
        for a in actions:
            ch = child_by_id.get(a.action_id)
            w.writerow([a.name, ch.visits if ch else 0, f"{ch.mean_value if ch else 0.0:.6f}"])

    safety = {
        "collision_rate": float(selected_eval_collision),
        "min_distance": float(selected_eval_min_distance),
        "risk_score": risk_score,
    }
    (output_dir / "safety.json").write_text(
        json.dumps(safety, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    np.savez_compressed(
        output_dir / "trajectories.npz",
        time=times,
        vehicle_ids=ids,
        x=traj[:, :, 0],
        y=traj[:, :, 1],
        speed=traj[:, :, 2],
        heading=traj[:, :, 3],
        action_id=np.array([selected.action_id], dtype=int),
        dt=np.array([cfg.dt], dtype=float),
        horizon=np.array([cfg.horizon_steps], dtype=int),
    )

    report_lines = [
        f"model: interactive_predictive_mcts_cooperative_decision",
        f"action: {selected.name}",
        f"accel: {selected.acceleration:.3f} m/s^2",
        f"yaw_rate: {selected.yaw_rate:.3f} rad/s",
        f"safety: collision_rate={selected_eval_collision:.3f}, min_distance={selected_eval_min_distance:.3f} m",
        f"efficiency: ego desired_speed={initial_state[0].desired_speed:.3f} m/s",
        f"cooperation: heterogeneous agent responses were rolled out in tree search",
        f"runtime: runtime_ms={tree_stats['runtime_ms']:.3f}, expanded_nodes={tree_stats['expanded_nodes']}",
        f"conclusion: selected by maximum root visit count under safety-cooperation utility",
    ]
    (output_dir / "decision.txt").write_text("\n".join(report_lines) + "\n", encoding="utf-8")

    visit_ratio = root_visits / max(root.visits, 1)
    runtime_ms = float(tree_stats["runtime_ms"])
    save_plot(output_dir, ids, traj, selected)
    return {
        "min_distance": min_distance,
        "min_ttc": min_ttc,
        "collisions": collisions,
        "visit_ratio": visit_ratio,
        "runtime_ms": runtime_ms,
        "risk_score": risk_score,
    }


def run_model(input_dir: Path, output_dir: Path, seed: Optional[int] = None) -> Dict[str, object]:
    scene = load_scene(input_dir / "scene_state.csv")
    actions = load_actions(input_dir / "action_library.json")
    cfg = load_config(input_dir / "config.toml", seed_override=seed)
    root, tree_stats = mcts(scene, actions, cfg)
    selected = select_action(root, actions)
    eval_stats = evaluate_root_actions(scene, actions, cfg)
    metrics = write_outputs(output_dir, scene, actions, cfg, root, selected, tree_stats, eval_stats)
    return {
        "selected_action": selected.name,
        "tree_statistics": tree_stats,
        "metrics": metrics,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Multi-agent interactive MCTS cooperative decision model")
    parser.add_argument("--input_dir", type=Path, default=Path("data/input"))
    parser.add_argument("--output_dir", type=Path, default=Path("data/output"))
    parser.add_argument("--demo", action="store_true", help="generate built-in demo inputs before running")
    parser.add_argument("--seed", type=int, default=None)
    args = parser.parse_args()

    if args.demo:
        write_demo_inputs(args.input_dir)
    result = run_model(args.input_dir, args.output_dir, seed=args.seed)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
