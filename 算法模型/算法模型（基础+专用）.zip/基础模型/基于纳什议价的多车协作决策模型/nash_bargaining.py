#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基于纳什议价的多车协作决策模型

功能：
1. 读取多车状态、异质主体参数与算法配置；
2. 基于运动学模型生成各车短时动作-轨迹候选；
3. 计算多车成对净空、安全、效率、速度跟踪和舒适性效用；
4. 以保守失协同策略作为分歧点，求解加权 Nash Bargaining Solution；
5. 输出联合决策、协作增益、成对安全指标、多车预测轨迹和可读摘要；
6. 可使用 --demo 自动生成可复现实验输入并运行测试。

算法为基础模型，不绑定单一换道/合流/交叉口拓扑。测试样例采用共享冲突区多车协同通行。
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np


@dataclass
class VehicleState:
    vehicle_id: str
    x: float
    y: float
    speed: float
    heading: float
    desired_speed: float
    safety_radius: float


@dataclass
class AgentProfile:
    vehicle_id: str
    priority_weight: float
    cooperation_factor: float
    min_acceleration: float
    max_acceleration: float
    max_yaw_rate: float


@dataclass(frozen=True)
class Action:
    acceleration: float
    yaw_rate: float


@dataclass
class Candidate:
    action: Action
    trajectory: np.ndarray  # shape [T, 4] => x, y, speed, heading
    progress_score: float
    speed_score: float
    comfort_score: float


def _float(row: dict, key: str) -> float:
    return float(row[key])


def generate_demo_inputs(input_dir: Path) -> None:
    """生成固定、可复现的 8 车共享冲突区测试输入。"""
    input_dir.mkdir(parents=True, exist_ok=True)
    states = [
        ["v1", -32.0, -2.0, 10.0, 0.0, 10.5, 1.40],
        ["v2",  31.5,  2.0,  9.8, math.pi, 10.0, 1.40],
        ["v3",   2.0, -31.5,  9.0, math.pi/2, 9.5, 1.40],
        ["v4",  -2.0,  32.0,  9.2, -math.pi/2, 9.5, 1.40],
        ["v5", -62.0, -2.0, 10.3, 0.0, 10.5, 1.40],
        ["v6",  64.0,  2.0,  9.7, math.pi, 10.0, 1.40],
        ["v7",   2.0, -60.0,  8.8, math.pi/2, 9.5, 1.40],
        ["v8",  -2.0,  62.0,  9.0, -math.pi/2, 9.5, 1.40],
    ]
    with (input_dir / "vehicle_states.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["vehicle_id", "x", "y", "speed", "heading", "desired_speed", "safety_radius"])
        w.writerows(states)

    profiles = [
        ["v1", 1.10, 0.85, -3.0, 1.0, 0.0],
        ["v2", 1.00, 0.75, -3.0, 1.0, 0.0],
        ["v3", 0.95, 0.90, -3.0, 1.0, 0.0],
        ["v4", 1.05, 0.80, -3.0, 1.0, 0.0],
        ["v5", 0.80, 0.90, 0.0, 0.0, 0.0],
        ["v6", 0.80, 0.85, 0.0, 0.0, 0.0],
        ["v7", 0.78, 0.95, 0.0, 0.0, 0.0],
        ["v8", 0.78, 0.90, 0.0, 0.0, 0.0],
    ]
    with (input_dir / "agent_profiles.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["vehicle_id", "priority_weight", "cooperation_factor", "min_acceleration", "max_acceleration", "max_yaw_rate"])
        w.writerows(profiles)

    config = {
        "dt": 0.5,
        "horizon_steps": 12,
        "acceleration_candidates": [-3.0, -1.5, 0.0, 1.0],
        "min_clearance": 0.65,
        "max_candidates_per_vehicle": 4,
    }
    (input_dir / "config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")


def load_inputs(input_dir: Path) -> Tuple[List[VehicleState], Dict[str, AgentProfile], dict]:
    states: List[VehicleState] = []
    with (input_dir / "vehicle_states.csv").open(encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            states.append(VehicleState(
                r["vehicle_id"], _float(r,"x"), _float(r,"y"), _float(r,"speed"),
                _float(r,"heading"), _float(r,"desired_speed"), _float(r,"safety_radius")
            ))
    profiles: Dict[str, AgentProfile] = {}
    with (input_dir / "agent_profiles.csv").open(encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            p = AgentProfile(
                r["vehicle_id"], _float(r,"priority_weight"), _float(r,"cooperation_factor"),
                _float(r,"min_acceleration"), _float(r,"max_acceleration"), _float(r,"max_yaw_rate")
            )
            profiles[p.vehicle_id] = p
    config = json.loads((input_dir / "config.json").read_text(encoding="utf-8"))
    missing = [s.vehicle_id for s in states if s.vehicle_id not in profiles]
    if missing:
        raise ValueError(f"agent_profiles.csv 缺少车辆: {missing}")
    if len(states) < 2:
        raise ValueError("至少需要 2 辆车参与协同决策")
    return states, profiles, config


def rollout(state: VehicleState, action: Action, dt: float, horizon_steps: int, min_accel: float, max_accel: float) -> np.ndarray:
    traj = np.zeros((horizon_steps + 1, 4), dtype=float)
    x, y, v, psi = state.x, state.y, state.speed, state.heading
    traj[0] = [x, y, v, psi]
    a = float(np.clip(action.acceleration, min_accel, max_accel))
    for k in range(1, horizon_steps + 1):
        # 先用当前速度推进位置，再更新速度和航向，适合短时开环动作原语。
        x += v * math.cos(psi) * dt
        y += v * math.sin(psi) * dt
        v = max(0.0, v + a * dt)
        psi = psi + action.yaw_rate * dt
        traj[k] = [x, y, v, psi]
    return traj


def build_candidates(state: VehicleState, profile: AgentProfile, config: dict) -> List[Candidate]:
    dt = float(config["dt"])
    H = int(config["horizon_steps"])
    accs = [float(a) for a in config["acceleration_candidates"] if profile.min_acceleration - 1e-9 <= float(a) <= profile.max_acceleration + 1e-9]
    if not accs:
        accs = [0.0]
    if abs(profile.max_yaw_rate) < 1e-9:
        yaws = [0.0]
    else:
        yaws = [-profile.max_yaw_rate, 0.0, profile.max_yaw_rate]

    raw: List[Candidate] = []
    T = dt * H
    a_scale = max(1.0, abs(profile.min_acceleration), abs(profile.max_acceleration))
    w_scale = max(0.08, abs(profile.max_yaw_rate))
    for a, w in itertools.product(accs, yaws):
        action = Action(a, w)
        tr = rollout(state, action, dt, H, profile.min_acceleration, profile.max_acceleration)
        dx = tr[-1,0] - tr[0,0]
        dy = tr[-1,1] - tr[0,1]
        progress = dx * math.cos(state.heading) + dy * math.sin(state.heading)
        denom = max(1.0, state.desired_speed * T)
        progress_score = float(np.clip(progress / denom, 0.0, 1.25))
        speed_score = math.exp(-abs(tr[-1,2] - state.desired_speed) / max(1.5, 0.30 * state.desired_speed))
        comfort_score = math.exp(-0.65 * abs(a) / a_scale - 0.50 * abs(w) / w_scale)
        raw.append(Candidate(action, tr, progress_score, speed_score, comfort_score))

    max_n = max(1, int(config.get("max_candidates_per_vehicle", len(raw))))
    if len(raw) <= max_n:
        return raw
    # 预筛选只用于控制联合组合规模。优先保留“最强制动+零横摆”和“保持速度+零横摆”，
    # 再按效率/舒适性预评分补齐，避免把必要的安全动作筛掉。
    scores = [0.55*c.progress_score + 0.30*c.speed_score + 0.15*c.comfort_score for c in raw]
    mandatory = []
    zero_yaw = [i for i,c in enumerate(raw) if abs(c.action.yaw_rate) < 1e-9]
    if zero_yaw:
        mandatory.append(min(zero_yaw, key=lambda i: raw[i].action.acceleration))
        zero_acc = [i for i in zero_yaw if abs(raw[i].action.acceleration) < 1e-9]
        if zero_acc:
            mandatory.append(zero_acc[0])
    ordered_all = sorted(range(len(raw)), key=lambda i: scores[i], reverse=True)
    keep = []
    for i in mandatory + ordered_all:
        if i not in keep:
            keep.append(i)
        if len(keep) >= max_n:
            break
    return [raw[i] for i in keep]


def pairwise_metrics(states: List[VehicleState], selected: List[Candidate]) -> Tuple[np.ndarray, List[dict], float]:
    n = len(states)
    per_vehicle_min = np.full(n, np.inf, dtype=float)
    rows: List[dict] = []
    global_min = np.inf
    for i in range(n):
        for j in range(i+1, n):
            pi = selected[i].trajectory[:, :2]
            pj = selected[j].trajectory[:, :2]
            center = np.linalg.norm(pi - pj, axis=1)
            clearance = center - (states[i].safety_radius + states[j].safety_radius)
            k = int(np.argmin(clearance))
            cmin = float(clearance[k])
            dmin = float(center[k])
            per_vehicle_min[i] = min(per_vehicle_min[i], cmin)
            per_vehicle_min[j] = min(per_vehicle_min[j], cmin)
            global_min = min(global_min, cmin)
            rows.append({
                "vehicle_i": states[i].vehicle_id,
                "vehicle_j": states[j].vehicle_id,
                "min_center_distance": dmin,
                "min_clearance": cmin,
                "step_of_min": k,
            })
    return per_vehicle_min, rows, float(global_min)


def utilities(states: List[VehicleState], profiles: Dict[str, AgentProfile], selected: List[Candidate], min_clearance: float) -> Tuple[np.ndarray, List[dict], float]:
    mins, safety_rows, global_min = pairwise_metrics(states, selected)
    safe_clearance = min_clearance + 5.0
    u = np.zeros(len(states), dtype=float)
    for i, (s, c) in enumerate(zip(states, selected)):
        coop = float(np.clip(profiles[s.vehicle_id].cooperation_factor, 0.0, 1.0))
        safety_score = float(np.clip((mins[i] - min_clearance) / max(1e-6, safe_clearance - min_clearance), 0.0, 1.0))
        # cooperation_factor 越高，越强调安全并略降低个体效率权重。
        w_s = 0.42 + 0.16 * coop
        w_e = 0.30 - 0.08 * coop
        w_v = 0.18
        w_c = 1.0 - (w_s + w_e + w_v)
        u[i] = w_s*safety_score + w_e*c.progress_score + w_v*c.speed_score + w_c*c.comfort_score
    return u, safety_rows, global_min


def fallback_candidates(states: List[VehicleState], profiles: Dict[str, AgentProfile], config: dict) -> List[Candidate]:
    out = []
    dt = float(config["dt"]); H = int(config["horizon_steps"])
    for s in states:
        p = profiles[s.vehicle_id]
        a = p.min_acceleration
        act = Action(a, 0.0)
        tr = rollout(s, act, dt, H, p.min_acceleration, p.max_acceleration)
        T = dt * H
        dx, dy = tr[-1,0]-tr[0,0], tr[-1,1]-tr[0,1]
        progress = dx*math.cos(s.heading) + dy*math.sin(s.heading)
        prog = float(np.clip(progress/max(1.0,s.desired_speed*T),0.0,1.25))
        spd = math.exp(-abs(tr[-1,2]-s.desired_speed)/max(1.5,0.30*s.desired_speed))
        a_scale=max(1.0,abs(p.min_acceleration),abs(p.max_acceleration))
        comf=math.exp(-0.65*abs(a)/a_scale)
        out.append(Candidate(act,tr,prog,spd,comf))
    return out


def solve(states: List[VehicleState], profiles: Dict[str, AgentProfile], config: dict) -> dict:
    start = time.perf_counter()
    cand_lists = [build_candidates(s, profiles[s.vehicle_id], config) for s in states]
    min_clear = float(config["min_clearance"])

    fb = fallback_candidates(states, profiles, config)
    d, _, fb_clear = utilities(states, profiles, fb, min_clear)
    # 若全体最强制动仍不满足最小净空，则将分歧点安全项按实测效用保留，后续仍优先寻找可行方案。
    epsilon = 0.025
    tol = 1e-8
    weights = np.array([max(0.05, profiles[s.vehicle_id].priority_weight) for s in states], dtype=float)
    weights = weights / weights.sum()

    best = None
    best_log = -np.inf
    best_social = -np.inf
    feasible_count = 0
    rational_count = 0
    evaluated = 0

    for combo in itertools.product(*[range(len(c)) for c in cand_lists]):
        evaluated += 1
        selected = [cand_lists[i][combo[i]] for i in range(len(states))]
        u, safety_rows, global_min = utilities(states, profiles, selected, min_clear)
        if global_min < min_clear - 1e-9:
            continue
        feasible_count += 1
        gains = u - d
        social = float(np.dot(weights, u))
        # 个体理性约束：协商结果不低于失协同保守策略；等效用允许通过 epsilon 进入乘积。
        if np.all(gains >= -tol):
            rational_count += 1
            log_obj = float(np.dot(weights, np.log(np.maximum(gains, 0.0) + epsilon)))
            if log_obj > best_log:
                best_log = log_obj
                best = (combo, selected, u, gains, safety_rows, global_min, "nash")
        if social > best_social:
            best_social = social
            if best is None:
                best = (combo, selected, u, gains, safety_rows, global_min, "safe_social_fallback")

    # 在极端输入下，如果无安全组合，直接回退到最强制动动作。
    if feasible_count == 0:
        u, safety_rows, global_min = utilities(states, profiles, fb, min_clear)
        best = (tuple([-1]*len(states)), fb, u, u-d, safety_rows, global_min, "emergency_fallback")
        best_log = float("nan")

    combo, selected, u, gains, safety_rows, global_min, mode = best
    runtime_ms = (time.perf_counter() - start) * 1000.0
    return {
        "candidate_lists": cand_lists,
        "selected": selected,
        "utilities": u,
        "disagreement": d,
        "gains": gains,
        "safety_rows": safety_rows,
        "global_min_clearance": global_min,
        "fallback_min_clearance": fb_clear,
        "objective_log_nash": best_log,
        "solution_mode": mode,
        "evaluated_combinations": evaluated,
        "safe_combinations": feasible_count,
        "individually_rational_combinations": rational_count,
        "runtime_ms": runtime_ms,
        "weights": weights,
    }


def write_outputs(states: List[VehicleState], result: dict, config: dict, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    selected: List[Candidate] = result["selected"]
    dt = float(config["dt"])
    H = int(config["horizon_steps"])

    summary = {
        "model": "基于纳什议价的多车协作决策模型",
        "solution_mode": result["solution_mode"],
        "objective_log_nash": None if not np.isfinite(result["objective_log_nash"]) else round(float(result["objective_log_nash"]), 8),
        "evaluated_combinations": int(result["evaluated_combinations"]),
        "safe_combinations": int(result["safe_combinations"]),
        "individually_rational_combinations": int(result["individually_rational_combinations"]),
        "runtime_ms": round(float(result["runtime_ms"]), 3),
        "global_min_clearance": round(float(result["global_min_clearance"]), 6),
    }
    (output_dir / "decision_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    with (output_dir / "joint_decision.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["vehicle_id", "acceleration", "yaw_rate", "utility"])
        for i, s in enumerate(states):
            c = selected[i]
            w.writerow([s.vehicle_id, f"{c.action.acceleration:.6f}", f"{c.action.yaw_rate:.6f}", f"{result['utilities'][i]:.6f}"])

    with (output_dir / "utility_gain.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["vehicle_id", "disagreement_utility", "utility_gain"])
        for i, s in enumerate(states):
            w.writerow([s.vehicle_id, f"{result['disagreement'][i]:.6f}", f"{result['gains'][i]:.6f}"])

    with (output_dir / "pairwise_safety.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["vehicle_pair", "min_clearance", "time_of_min"])
        for r in result["safety_rows"]:
            w.writerow([f"{r['vehicle_i']}|{r['vehicle_j']}", f"{r['min_clearance']:.6f}", f"{r['step_of_min']*dt:.3f}"])

    ids = np.array([s.vehicle_id for s in states])
    time_arr = np.arange(H+1,dtype=float)*dt
    x = np.stack([c.trajectory[:,0] for c in selected], axis=1)
    y = np.stack([c.trajectory[:,1] for c in selected], axis=1)
    speed = np.stack([c.trajectory[:,2] for c in selected], axis=1)
    heading = np.stack([c.trajectory[:,3] for c in selected], axis=1)
    acceleration = np.array([c.action.acceleration for c in selected],dtype=float)
    yaw_rate = np.array([c.action.yaw_rate for c in selected],dtype=float)
    np.savez(output_dir / "predicted_trajectories.npz", time=time_arr, vehicle_ids=ids, x=x, y=y, speed=speed, heading=heading, acceleration=acceleration, yaw_rate=yaw_rate, horizon=np.array([H],dtype=int))

    avg_gain=float(np.mean(result['gains']))
    min_gain=float(np.min(result['gains']))
    text = [
        "model: 基于纳什议价的多车协作决策模型",
        f"solution_mode: {result['solution_mode']}",
        f"objective_log_nash: {result['objective_log_nash']:.8f}" if np.isfinite(result['objective_log_nash']) else "objective_log_nash: nan",
        f"evaluated_combinations: {result['evaluated_combinations']}",
        "selected_actions: " + "; ".join(f"{s.vehicle_id}=({selected[i].action.acceleration:.2f},{selected[i].action.yaw_rate:.3f})" for i,s in enumerate(states)),
        f"safety: global_min_clearance={result['global_min_clearance']:.3f} m, threshold={float(config['min_clearance']):.3f} m",
        f"efficiency: mean_final_speed={np.mean(speed[-1]):.3f} m/s",
        f"fairness: mean_utility_gain={avg_gain:.4f}, min_utility_gain={min_gain:.4f}",
        f"runtime: {result['runtime_ms']:.3f} ms",
        "conclusion: joint action satisfies the configured clearance constraint and applies weighted Nash bargaining to balance individual cooperative gains.",
    ]
    (output_dir / "decision.txt").write_text("\n".join(text), encoding="utf-8")

    plot_trajectories(states, selected, config, output_dir / "cooperative_trajectory.png")


def plot_trajectories(states: List[VehicleState], selected: List[Candidate], config: dict, path: Path) -> None:
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7.0, 6.2))
    # 简洁画出两条互相垂直的道路边界，仅用于测试结果理解。
    ax.axhline(0, linewidth=0.6, alpha=0.35)
    ax.axvline(0, linewidth=0.6, alpha=0.35)
    for s, c in zip(states, selected):
        tr = c.trajectory
        ax.plot(tr[:,0], tr[:,1], marker='o', markersize=2.5, linewidth=1.2, label=f"{s.vehicle_id}: a={c.action.acceleration:.1f}")
        ax.scatter([tr[0,0]],[tr[0,1]], marker='s', s=25)
        ax.text(tr[0,0]+0.8,tr[0,1]+0.8,s.vehicle_id,fontsize=8)
    ax.set_xlabel("x / m")
    ax.set_ylabel("y / m")
    ax.set_title("Coordinated multi-vehicle trajectories")
    ax.axis("equal")
    ax.grid(True, alpha=0.22)
    ax.legend(loc="best", fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="基于纳什议价的多车协作决策模型")
    parser.add_argument("--input_dir", default="data/input")
    parser.add_argument("--output_dir", default="data/output")
    parser.add_argument("--demo", action="store_true", help="生成固定测试输入后运行")
    args = parser.parse_args()
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    if args.demo:
        generate_demo_inputs(input_dir)
    states, profiles, config = load_inputs(input_dir)
    result = solve(states, profiles, config)
    write_outputs(states, result, config, output_dir)
    print(json.dumps({
        "solution_mode": result["solution_mode"],
        "evaluated_combinations": result["evaluated_combinations"],
        "safe_combinations": result["safe_combinations"],
        "individually_rational_combinations": result["individually_rational_combinations"],
        "global_min_clearance": round(float(result["global_min_clearance"]), 4),
        "objective_log_nash": None if not np.isfinite(result["objective_log_nash"]) else round(float(result["objective_log_nash"]), 6),
        "runtime_ms": round(float(result["runtime_ms"]), 3),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
