vehicle_list = [] # 当前还在路段上（未通过停车线）的车辆列表
W_vehicle_list1 = [] # 四条进口道的车辆列表（会重复）
E_vehicle_list1 = []
N_vehicle_list1 = []
S_vehicle_list1 = []
W_vehicle_list = [] # 四条进口道上（未通过停车线）的最终车辆列表
E_vehicle_list = []
N_vehicle_list = []
S_vehicle_list = []
vehicle_state = {} # 所有车辆的状态信息，包括位置(x,y)、速度、加速度、进入交叉口时间t0、最快到达时间t_s、车辆类型、两相位的持续时间g1/g2、估计到达时间t_e、实际到达时间t_f
vehicle_state_total = {} # 所有车辆的状态信息（包括已经移除vehicle_state的车辆，以便计算t_e的时候寻找前车的t_f）
WC0_vehicle_list1 = [] # 每个车道上的车辆列表（会重复）
WC1_vehicle_list1 = []
EC0_vehicle_list1 = []
EC1_vehicle_list1 = []
NC0_vehicle_list1 = []
NC1_vehicle_list1 = []
SC0_vehicle_list1 = []
SC1_vehicle_list1 = []
WC0_vehicle_list = [] # 每个车道上的车辆列表（未通过停车线）
WC1_vehicle_list = []
EC0_vehicle_list = []
EC1_vehicle_list = []
NC0_vehicle_list = []
NC1_vehicle_list = []
SC0_vehicle_list = []
SC1_vehicle_list = []
calculated_WC0_vehicle_list = [] # 已经计算过t_f的车辆列表（每辆车只在进入范围的第1秒计算一次，然后就移除）
calculated_WC1_vehicle_list = []
calculated_EC0_vehicle_list = []
calculated_EC1_vehicle_list = []
calculated_NC0_vehicle_list = []
calculated_NC1_vehicle_list = []
calculated_SC0_vehicle_list = []
calculated_SC1_vehicle_list = []

def get_current_vehicle_state():
    global vehicle_list, W_vehicle_list, E_vehicle_list, N_vehicle_list, S_vehicle_list, WC0_vehicle_list, WC1_vehicle_list, EC0_vehicle_list, EC1_vehicle_list, NC0_vehicle_list, NC1_vehicle_list, SC0_vehicle_list, SC1_vehicle_list, calculated_WC0_vehicle_list, calculated_WC1_vehicle_list, calculated_EC0_vehicle_list, calculated_EC1_vehicle_list, calculated_NC0_vehicle_list, calculated_NC1_vehicle_list, calculated_SC0_vehicle_list, calculated_SC1_vehicle_list
    time = traci.simulation.getTime()
    departed_vehicle_ids = traci.simulation.getDepartedIDList()
    current_vehicle_ids = traci.vehicle.getIDList()
    new_vehicles = [vid for vid in departed_vehicle_ids if vid not in vehicle_list]
    vehicle_list.extend(new_vehicles)
    vehicle_list = [vid for vid in vehicle_list if vid in current_vehicle_ids]
    for vid in list(vehicle_state.keys()):
        if vid not in vehicle_list:
            del vehicle_state[vid]
    for i in vehicle_list:
        position = traci.vehicle.getPosition(i)
        x = round(position[0], 1)
        y = round(position[1], 1)
        speed1 = traci.vehicle.getSpeed(i)
        speed = round(speed1, 2)
        acceleration1 = traci.vehicle.getAcceleration(i)
        acceleration = round(acceleration1, 2)
        depart_time = int(traci.vehicle.getDeparture(i)) + 1
        vehicle_type = traci.vehicle.getTypeID(i)
        t_fastest = ((R - (v_max ** 2 - v0 ** 2) / (2 * a_max)) / v_max) + ((v_max - v0) / a_max)
        t_s = int(depart_time + t_fastest)

        current_program = traci.trafficlight.getAllProgramLogics("C")[0]
        phases = current_program.phases
        g1 = int(phases[0].duration)
        g2 = int(phases[1].duration)


        if i not in vehicle_state:
            vehicle_state[i] = {
                "x": x,
                "y": y,
                "speed": speed,
                "acceleration": acceleration,
                "depart_time": depart_time,
                "vehicle_type": vehicle_type,
                "g1": g1,
                "g2": g2,
                "t_s": t_s
            }

            vehicle_state_total[i] = {
                "x": x,
                "y": y,
                "speed": speed,
                "acceleration": acceleration,
                "depart_time": depart_time,
                "vehicle_type": vehicle_type,
                "g1": g1,
                "g2": g2,
                "t_s": t_s
            }
        else:
            vehicle_state[i]['x'] = x
            vehicle_state[i]['y'] = y
            vehicle_state[i]['speed'] = speed
            vehicle_state[i]['acceleration'] = acceleration


            vehicle_state_total[i]['x'] = x
            vehicle_state_total[i]['y'] = y
            vehicle_state_total[i]['speed'] = speed
            vehicle_state_total[i]['acceleration'] = acceleration



        # 西进口道
        if y == -1.6 or y == -4.8:
            if x > 0:
                vehicle_list.remove(i)
                del vehicle_state[i]
        # 东进口道
        if y == 1.6 or y == 4.8:
            if x < 0:
                vehicle_list.remove(i)
                del vehicle_state[i]
        # 北进口道
        if x == -1.6 or x == -4.8:
            if y < 0:
                vehicle_list.remove(i)
                del vehicle_state[i]
        # 南进口道
        if x == 1.6 or x == 4.8:
            if y > 0:
                vehicle_list.remove(i)
                del vehicle_state[i]


        if 'WE' in i:
            W_vehicle_list1.append(i)
            [W_vehicle_list.append(i) for i in W_vehicle_list1 if i not in W_vehicle_list]
        if 'EW' in i:
            E_vehicle_list1.append(i)
            [E_vehicle_list.append(i) for i in E_vehicle_list1 if i not in E_vehicle_list]
        if 'NS' in i:
            N_vehicle_list1.append(i)
            [N_vehicle_list.append(i) for i in N_vehicle_list1 if i not in N_vehicle_list]
        if 'SN' in i:
            S_vehicle_list1.append(i)
            [S_vehicle_list.append(i) for i in S_vehicle_list1 if i not in S_vehicle_list]


    W_vehicle_list = [x for x in W_vehicle_list if x in vehicle_list]
    E_vehicle_list = [x for x in E_vehicle_list if x in vehicle_list]
    N_vehicle_list = [x for x in N_vehicle_list if x in vehicle_list]
    S_vehicle_list = [x for x in S_vehicle_list if x in vehicle_list]
    for i in vehicle_list:
        lane_id = traci.vehicle.getLaneID(i)
        if lane_id == 'WC_0':
            WC0_vehicle_list1.append(i)
            [WC0_vehicle_list.append(i) for i in WC0_vehicle_list1 if i not in WC0_vehicle_list]
            WC0_vehicle_list = [x for x in WC0_vehicle_list if x in vehicle_list]
        if lane_id == 'WC_1':
            WC1_vehicle_list1.append(i)
            [WC1_vehicle_list.append(i) for i in WC1_vehicle_list1 if i not in WC1_vehicle_list]
            WC1_vehicle_list = [x for x in WC1_vehicle_list if x in vehicle_list]
        if lane_id == 'EC_0':
            EC0_vehicle_list1.append(i)
            [EC0_vehicle_list.append(i) for i in EC0_vehicle_list1 if i not in EC0_vehicle_list]
            EC0_vehicle_list = [x for x in EC0_vehicle_list if x in vehicle_list]
        if lane_id == 'EC_1':
            EC1_vehicle_list1.append(i)
            [EC1_vehicle_list.append(i) for i in EC1_vehicle_list1 if i not in EC1_vehicle_list]
            EC1_vehicle_list = [x for x in EC1_vehicle_list if x in vehicle_list]
        if lane_id == 'NC_0':
            NC0_vehicle_list1.append(i)
            [NC0_vehicle_list.append(i) for i in NC0_vehicle_list1 if i not in NC0_vehicle_list]
            NC0_vehicle_list = [x for x in NC0_vehicle_list if x in vehicle_list]
        if lane_id == 'NC_1':
            NC1_vehicle_list1.append(i)
            [NC1_vehicle_list.append(i) for i in NC1_vehicle_list1 if i not in NC1_vehicle_list]
            NC1_vehicle_list = [x for x in NC1_vehicle_list if x in vehicle_list]
        if lane_id == 'SC_0':
            SC0_vehicle_list1.append(i)
            [SC0_vehicle_list.append(i) for i in SC0_vehicle_list1 if i not in SC0_vehicle_list]
            SC0_vehicle_list = [x for x in SC0_vehicle_list if x in vehicle_list]
        if lane_id == 'SC_1':
            SC1_vehicle_list1.append(i)
            [SC1_vehicle_list.append(i) for i in SC1_vehicle_list1 if i not in SC1_vehicle_list]
            SC1_vehicle_list = [x for x in SC1_vehicle_list if x in vehicle_list]


        new_WC0_vehicles = [x for x in WC0_vehicle_list if
                            x not in calculated_WC0_vehicle_list]  # 其实就是新进来的车，这个列表里只会有一辆车

        for i in new_WC0_vehicles:

            if i == 'WE0.0':
                if len(vehicle_state[i]) == 9:
                    t_e = vehicle_state[i]['t_s']
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e

                    if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                        t_f = t_e
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time

                    elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                            total_cycle_length - start_time_of_current_cycle):
                        t_f = total_cycle_length
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
            else:
                if len(vehicle_state[i]) == 9:
                    t_e = max(vehicle_state[i]['t_s'], (vehicle_state_total[WC0_vehicle_list1[-2]]['t_f'] + safe_h))
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if t_e < total_cycle_length:
                        if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = total_cycle_length
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                    elif t_e >= total_cycle_length:
                        if 0 <= t_e - total_cycle_length < vehicle_state[i]['g1']:
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e + vehicle_state[i]['g2']
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1']):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle + vehicle_state[i][
                            'g1']) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1'] +
                                vehicle_state[i]['g2']):
                            t_f = t_e + vehicle_state[i]['g2']
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
            calculated_WC0_vehicle_list.append(i)
            new_WC0_vehicles.remove(i)

        new_WC1_vehicles = [x for x in WC1_vehicle_list if x not in calculated_WC1_vehicle_list]
        for i in new_WC1_vehicles:
            if i == 'WE1.0':
                if len(vehicle_state[i]) == 9:
                    t_e = vehicle_state[i]['t_s']
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                        t_f = t_e
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
                    elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                            total_cycle_length - start_time_of_current_cycle):
                        t_f = total_cycle_length
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
            else:
                if len(vehicle_state[i]) == 9:
                    t_e = max(vehicle_state[i]['t_s'], (vehicle_state_total[WC1_vehicle_list1[-2]]['t_f'] + safe_h))
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if t_e < total_cycle_length:
                        if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = total_cycle_length
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                    elif t_e >= total_cycle_length:
                        if 0 <= t_e - total_cycle_length < vehicle_state[i]['g1']:
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e + vehicle_state[i]['g2']
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1']):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle + vehicle_state[i][
                            'g1']) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1'] +
                                vehicle_state[i]['g2']):
                            t_f = t_e + vehicle_state[i]['g2']
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

            calculated_WC1_vehicle_list.append(i)
            new_WC1_vehicles.remove(i)

        new_EC0_vehicles = [x for x in EC0_vehicle_list if x not in calculated_EC0_vehicle_list]
        for i in new_EC0_vehicles:
            if i == 'EW0.0':
                if len(vehicle_state[i]) == 9:
                    t_e = vehicle_state[i]['t_s']
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                        t_f = t_e
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
                    elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                            total_cycle_length - start_time_of_current_cycle):
                        t_f = total_cycle_length
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
            else:
                if len(vehicle_state[i]) == 9:
                    t_e = max(vehicle_state[i]['t_s'], (vehicle_state_total[EC0_vehicle_list1[-2]]['t_f'] + safe_h))

                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if t_e < total_cycle_length:

                        if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                        elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = total_cycle_length
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                    elif t_e >= total_cycle_length:

                        if 0 <= t_e - total_cycle_length < vehicle_state[i]['g1']:
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                        elif vehicle_state[i]['g1'] <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e + vehicle_state[i]['g2']
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                        elif (total_cycle_length - start_time_of_current_cycle) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1']):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                        elif (total_cycle_length - start_time_of_current_cycle + vehicle_state[i][
                            'g1']) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1'] +
                                vehicle_state[i]['g2']):
                            t_f = t_e + vehicle_state[i]['g2']
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

            calculated_EC0_vehicle_list.append(i)
            new_EC0_vehicles.remove(i)


        new_EC1_vehicles = [x for x in EC1_vehicle_list if x not in calculated_EC1_vehicle_list]

        for i in new_EC1_vehicles:

            if i == 'EW1.0':
                if len(vehicle_state[i]) == 9:
                    t_e = vehicle_state[i]['t_s']
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                        t_f = t_e
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
                    elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                            total_cycle_length - start_time_of_current_cycle):
                        t_f = total_cycle_length
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
            else:
                if len(vehicle_state[i]) == 9:
                    t_e = max(vehicle_state[i]['t_s'], (vehicle_state_total[EC1_vehicle_list1[-2]]['t_f'] + safe_h))

                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if t_e < total_cycle_length:

                        if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                        elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = total_cycle_length
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                    elif t_e >= total_cycle_length:

                        if 0 <= t_e - total_cycle_length < vehicle_state[i]['g1']:
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                        elif vehicle_state[i]['g1'] <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e + vehicle_state[i]['g2']
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                        elif (total_cycle_length - start_time_of_current_cycle) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1']):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

                        elif (total_cycle_length - start_time_of_current_cycle + vehicle_state[i][
                            'g1']) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1'] +
                                vehicle_state[i]['g2']):
                            t_f = t_e + vehicle_state[i]['g2']
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

            calculated_EC1_vehicle_list.append(i)
            new_EC1_vehicles.remove(i)

        new_NC0_vehicles = [x for x in NC0_vehicle_list if x not in calculated_NC0_vehicle_list]

        for i in new_NC0_vehicles:

            if i == 'NS0.0':
                if len(vehicle_state[i]) == 9:
                    t_e = vehicle_state[i]['t_s']
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                        t_f = int(start_time_of_current_cycle + vehicle_state[i]['g1'])
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
                    elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                            total_cycle_length - start_time_of_current_cycle):
                        t_f = t_e
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
            else:
                if len(vehicle_state[i]) == 9:
                    t_e = max(vehicle_state[i]['t_s'], (vehicle_state_total[NC0_vehicle_list1[-2]]['t_f'] + safe_h))

                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if t_e < total_cycle_length:
                        if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                            t_f = int(start_time_of_current_cycle + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                    elif t_e >= total_cycle_length:
                        if 0 <= t_e - total_cycle_length < vehicle_state[i]['g1']:
                            t_f = int(t_e + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1']):
                            t_f = int(t_e + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle + vehicle_state[i][
                            'g1']) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1'] +
                                vehicle_state[i]['g2']):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

            calculated_NC0_vehicle_list.append(i)
            new_NC0_vehicles.remove(i)

        new_NC1_vehicles = [x for x in NC1_vehicle_list if x not in calculated_NC1_vehicle_list]

        for i in new_NC1_vehicles:

            if i == 'NS1.0':
                if len(vehicle_state[i]) == 9:
                    t_e = vehicle_state[i]['t_s']
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                        t_f = int(start_time_of_current_cycle + vehicle_state[i]['g1'])
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
                    elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                            total_cycle_length - start_time_of_current_cycle):
                        t_f = t_e
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
            else:
                if len(vehicle_state[i]) == 9:
                    t_e = max(vehicle_state[i]['t_s'], (vehicle_state_total[NC1_vehicle_list1[-2]]['t_f'] + safe_h))

                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if t_e < total_cycle_length:
                        if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                            t_f = int(start_time_of_current_cycle + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                    elif t_e >= total_cycle_length:
                        if 0 <= t_e - total_cycle_length < vehicle_state[i]['g1']:
                            t_f = int(t_e + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1']):
                            t_f = int(t_e + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle + vehicle_state[i][
                            'g1']) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1'] +
                                vehicle_state[i]['g2']):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

            calculated_NC1_vehicle_list.append(i)
            new_NC1_vehicles.remove(i)

        new_SC0_vehicles = [x for x in SC0_vehicle_list if x not in calculated_SC0_vehicle_list]

        for i in new_SC0_vehicles:

            if i == 'SN0.0':
                if len(vehicle_state[i]) == 9:
                    t_e = vehicle_state[i]['t_s']
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                        t_f = int(start_time_of_current_cycle + vehicle_state[i]['g1'])
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
                    elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                            total_cycle_length - start_time_of_current_cycle):
                        t_f = t_e
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
            else:
                if len(vehicle_state[i]) == 9:
                    t_e = max(vehicle_state[i]['t_s'], (vehicle_state_total[SC0_vehicle_list1[-2]]['t_f'] + safe_h))

                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if t_e < total_cycle_length:
                        if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                            t_f = int(start_time_of_current_cycle + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                    elif t_e >= total_cycle_length:
                        if 0 <= t_e - total_cycle_length < vehicle_state[i]['g1']:
                            t_f = int(t_e + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1']):
                            t_f = int(t_e + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle + vehicle_state[i][
                            'g1']) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1'] +
                                vehicle_state[i]['g2']):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

            calculated_SC0_vehicle_list.append(i)
            new_SC0_vehicles.remove(i)

        new_SC1_vehicles = [x for x in SC1_vehicle_list if x not in calculated_SC1_vehicle_list]

        for i in new_SC1_vehicles:

            if i == 'SN1.0':
                if len(vehicle_state[i]) == 9:
                    t_e = vehicle_state[i]['t_s']
                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                        t_f = int(start_time_of_current_cycle + vehicle_state[i]['g1'])
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
                    elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                            total_cycle_length - start_time_of_current_cycle):
                        t_f = t_e
                        vehicle_state[i]["t_f"] = t_f
                        vehicle_state_total[i]["t_f"] = t_f
                        running_time = t_f - vehicle_state[i]["depart_time"] + 1
                        vehicle_state[i]["running_time"] = running_time
                        vehicle_state_total[i]["running_time"] = running_time
            else:
                if len(vehicle_state[i]) == 9:
                    t_e = max(vehicle_state[i]['t_s'], (vehicle_state_total[SC1_vehicle_list1[-2]]['t_f'] + safe_h))

                    vehicle_state[i]["t_e"] = t_e
                    vehicle_state_total[i]["t_e"] = t_e
                    if t_e < total_cycle_length:
                        if 0 <= t_e - start_time_of_current_cycle < vehicle_state[i]['g1']:
                            t_f = int(start_time_of_current_cycle + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - start_time_of_current_cycle < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                    elif t_e >= total_cycle_length:
                        if 0 <= t_e - total_cycle_length < vehicle_state[i]['g1']:
                            t_f = int(t_e + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif vehicle_state[i]['g1'] <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1']):
                            t_f = int(t_e + vehicle_state[i]['g1'])
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time
                        elif (total_cycle_length - start_time_of_current_cycle + vehicle_state[i][
                            'g1']) <= t_e - total_cycle_length < (
                                total_cycle_length - start_time_of_current_cycle + vehicle_state[i]['g1'] +
                                vehicle_state[i]['g2']):
                            t_f = t_e
                            vehicle_state[i]["t_f"] = t_f
                            vehicle_state_total[i]["t_f"] = t_f
                            running_time = t_f - vehicle_state[i]["depart_time"] + 1
                            vehicle_state[i]["running_time"] = running_time
                            vehicle_state_total[i]["running_time"] = running_time

            calculated_SC1_vehicle_list.append(i)
            new_SC1_vehicles.remove(i)

    print(f'*********** time:', time, f'***********')
    print(W_vehicle_list)
    print(E_vehicle_list)
    print(N_vehicle_list)
    print(S_vehicle_list)
    print('WC0:', WC0_vehicle_list)
    print('WC1:', WC1_vehicle_list)
    print('EC0:', EC0_vehicle_list)
    print('EC1:', EC1_vehicle_list)
    print('NC0:', NC0_vehicle_list)
    print('NC1:', NC1_vehicle_list)
    print('SC0:', SC0_vehicle_list)
    print('SC1:', SC1_vehicle_list)
    print(vehicle_list)
    for i, j in vehicle_state.items():
        print(f'{i}: {j}')
    return W_vehicle_list, E_vehicle_list, N_vehicle_list, S_vehicle_list, vehicle_list, vehicle_state, vehicle_state_total
