free_flow_speed = 20
length = 5
s_0 = 3.694
a_limit = 1.267
b = 1.209
desired_time_headway = 0.977
min_gap = 2

def get_HDV_speed(id):
    leader_info = traci.vehicle.getLeader(id)
    current_v = traci.vehicle.getSpeed(id)
    if leader_info:
        leader_id, h = leader_info
        leader_v = traci.vehicle.getSpeed(leader_id)
        gap = h + min_gap
        delta_v = leader_v - current_v
        m = s_0 + current_v * desired_time_headway + current_v * delta_v / (2 * math.sqrt(a_limit * b))
        a_tar = a_limit * (1 - (current_v / free_flow_speed) ** 4 - (m / gap) ** 2)
    else:
        a_tar = a_limit * (1 - (current_v / free_flow_speed) ** 4)
    v_tar = max(current_v + a_tar, 0)
    return v_tar

time = traci.simulation.getTime()
print(f'*********', time, f'**********')
for i in traci.vehicle.getIDList():
    if traci.vehicle.getTypeID(i) == 'HDV':
        v_tar = get_HDV_speed(i)
        print(f'vehicle {i}  target speed: ', v_tar)
        traci.vehicle.setSpeedMode(i, 80)
        traci.vehicle.setSpeed(i, v_tar)
        print(f'vehicle {i} actual speed: ', traci.vehicle.getSpeed(i))
