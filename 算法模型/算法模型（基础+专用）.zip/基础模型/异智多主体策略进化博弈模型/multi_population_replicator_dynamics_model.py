#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
异智多主体策略进化博弈模型

功能：
1. 读取多类载运装备主体的初始策略分布、群体交互权重及成对收益矩阵；
2. 计算各主体群体在当前策略分布下的期望收益；
3. 基于带突变项的多群体复制动态更新策略比例；
4. 判断收敛并输出策略演化过程、平均收益轨迹和稳定策略分布；
5. 可在 --demo 模式下直接生成可复现实验数据并运行测试。

运行示例：
    python evolutionary_game_model.py --demo --output-dir data/output

自定义数据模式：
    python evolutionary_game_model.py \
        --groups-json data/input/groups.json \
        --payoffs-npz data/input/payoff_matrices.npz \
        --config-json data/input/config.json \
        --output-dir data/output
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


@dataclass
class ModelConfig:
    dt: float = 0.05
    max_steps: int = 4000
    tolerance: float = 1e-8
    stable_steps: int = 80
    mutation_rate: float = 0.002
    min_probability: float = 1e-12
    save_interval: int = 1


@dataclass
class GroupSpec:
    group_id: str
    strategies: List[str]
    initial_distribution: np.ndarray
    learning_rate: float = 1.0


def _normalize_probability(x: np.ndarray, eps: float) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    x = np.maximum(x, eps)
    s = float(x.sum())
    if not np.isfinite(s) or s <= 0:
        return np.ones_like(x) / len(x)
    return x / s


def validate_inputs(groups: List[GroupSpec], interaction_weights: np.ndarray,
                    payoff_matrices: Dict[Tuple[int, int], np.ndarray]) -> None:
    n = len(groups)
    if n < 2:
        raise ValueError("至少需要两个主体群体。")
    if interaction_weights.shape != (n, n):
        raise ValueError(f"interaction_weights 应为 {(n, n)}，实际为 {interaction_weights.shape}")
    if np.any(interaction_weights < 0):
        raise ValueError("interaction_weights 不允许出现负值。")

    for i, g in enumerate(groups):
        s = len(g.strategies)
        if s < 2:
            raise ValueError(f"群体 {g.group_id} 至少需要两种策略。")
        if len(g.initial_distribution) != s:
            raise ValueError(f"群体 {g.group_id} 的初始分布长度与策略数不一致。")
        if g.learning_rate <= 0:
            raise ValueError("learning_rate 必须大于 0。")

    for i in range(n):
        for j in range(n):
            if i == j or interaction_weights[i, j] <= 0:
                continue
            key = (i, j)
            if key not in payoff_matrices:
                raise ValueError(f"缺少群体 {i}->{j} 的收益矩阵。")
            expected_shape = (len(groups[i].strategies), len(groups[j].strategies))
            if payoff_matrices[key].shape != expected_shape:
                raise ValueError(
                    f"收益矩阵 {i}->{j} 维度应为 {expected_shape}，实际为 {payoff_matrices[key].shape}"
                )


def expected_fitness(
    x: List[np.ndarray],
    groups: List[GroupSpec],
    interaction_weights: np.ndarray,
    payoff_matrices: Dict[Tuple[int, int], np.ndarray],
) -> Tuple[List[np.ndarray], np.ndarray]:
    """计算每个群体各策略期望收益及群体平均收益。"""
    n = len(groups)
    fitness: List[np.ndarray] = []
    mean_payoff = np.zeros(n, dtype=float)

    for i, g in enumerate(groups):
        fi = np.zeros(len(g.strategies), dtype=float)
        weight_sum = 0.0
        for j in range(n):
            if i == j:
                continue
            w = float(interaction_weights[i, j])
            if w <= 0:
                continue
            Aij = payoff_matrices[(i, j)]
            fi += w * (Aij @ x[j])
            weight_sum += w
        if weight_sum > 0:
            fi /= weight_sum
        fitness.append(fi)
        mean_payoff[i] = float(x[i] @ fi)
    return fitness, mean_payoff


def replicator_mutator_step(
    x: List[np.ndarray],
    fitness: List[np.ndarray],
    mean_payoff: np.ndarray,
    groups: List[GroupSpec],
    config: ModelConfig,
) -> List[np.ndarray]:
    """显式 Euler 离散化的带均匀突变项复制动态。"""
    new_x: List[np.ndarray] = []
    for i, g in enumerate(groups):
        xi = x[i]
        s = len(xi)
        replicator = g.learning_rate * xi * (fitness[i] - mean_payoff[i])
        mutation = config.mutation_rate * (1.0 / s - xi)
        candidate = xi + config.dt * (replicator + mutation)
        candidate = _normalize_probability(candidate, config.min_probability)
        new_x.append(candidate)
    return new_x


def run_model(
    groups: List[GroupSpec],
    interaction_weights: np.ndarray,
    payoff_matrices: Dict[Tuple[int, int], np.ndarray],
    config: ModelConfig,
) -> Tuple[pd.DataFrame, pd.DataFrame, dict]:
    validate_inputs(groups, interaction_weights, payoff_matrices)

    x = [_normalize_probability(g.initial_distribution, config.min_probability) for g in groups]
    records = []
    payoff_records = []
    stable_counter = 0
    converged = False
    last_delta = math.inf

    for step in range(config.max_steps + 1):
        fitness, mean_payoff = expected_fitness(x, groups, interaction_weights, payoff_matrices)

        if step % config.save_interval == 0:
            time_value = step * config.dt
            for i, g in enumerate(groups):
                for k, strategy in enumerate(g.strategies):
                    entropy = float(-np.sum(x[i] * np.log(np.maximum(x[i], config.min_probability))))
                    records.append({
                        "step": step,
                        "time": time_value,
                        "group_id": g.group_id,
                        "strategy": strategy,
                        "probability": float(x[i][k]),
                        "fitness": float(fitness[i][k]),
                        "mean_payoff": float(mean_payoff[i]),
                        "payoff_advantage": float(fitness[i][k] - mean_payoff[i]),
                        "distribution_entropy": entropy,
                    })
                payoff_records.append({
                    "step": step,
                    "time": time_value,
                    "group_id": g.group_id,
                    "mean_payoff": float(mean_payoff[i]),
                })

        if step == config.max_steps:
            break

        x_new = replicator_mutator_step(x, fitness, mean_payoff, groups, config)
        last_delta = max(float(np.max(np.abs(a - b))) for a, b in zip(x_new, x))
        if last_delta < config.tolerance:
            stable_counter += 1
        else:
            stable_counter = 0
        x = x_new

        if stable_counter >= config.stable_steps:
            converged = True
            break

    final_fitness, final_mean_payoff = expected_fitness(x, groups, interaction_weights, payoff_matrices)
    equilibrium = {
        "converged": converged,
        "final_step": int(step),
        "simulated_time": float(step * config.dt),
        "max_probability_delta": float(last_delta),
        "groups": {},
    }
    for i, g in enumerate(groups):
        equilibrium["groups"][g.group_id] = {
            "strategy_distribution": {s: float(x[i][k]) for k, s in enumerate(g.strategies)},
            "strategy_fitness": {s: float(final_fitness[i][k]) for k, s in enumerate(g.strategies)},
            "mean_payoff": float(final_mean_payoff[i]),
            "dominant_strategy": g.strategies[int(np.argmax(x[i]))],
        }

    return pd.DataFrame(records), pd.DataFrame(payoff_records), equilibrium


def save_outputs(evolution: pd.DataFrame, payoff_trace: pd.DataFrame,
                 equilibrium: dict, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    evolution.to_csv(output_dir / "strategy_evolution.csv", index=False, encoding="utf-8-sig")
    payoff_trace.to_csv(output_dir / "payoff_trace.csv", index=False, encoding="utf-8-sig")
    tail = evolution.sort_values(["step", "group_id", "strategy"]).groupby(["group_id", "strategy"], as_index=False).tail(1)
    tail.to_csv(output_dir / "strategy_evolution.txt", index=False, encoding="utf-8-sig")
    with open(output_dir / "equilibrium.json", "w", encoding="utf-8") as f:
        json.dump(equilibrium, f, ensure_ascii=False, indent=2)

    summary_lines = [
        f"converged={equilibrium['converged']}",
        f"final_step={equilibrium['final_step']}",
        f"simulated_time={equilibrium['simulated_time']:.6f}",
        f"max_probability_delta={equilibrium['max_probability_delta']:.12e}",
    ]
    for gid, info in equilibrium["groups"].items():
        summary_lines.append(f"[{gid}] dominant_strategy={info['dominant_strategy']} mean_payoff={info['mean_payoff']:.6f}")
        for s, p in info["strategy_distribution"].items():
            summary_lines.append(f"  {s}: {p:.6f}")
    (output_dir / "equilibrium.txt").write_text("\n".join(summary_lines), encoding="utf-8")


def make_demo_case() -> Tuple[List[GroupSpec], np.ndarray, Dict[Tuple[int, int], np.ndarray], ModelConfig]:
    """
    构造三个异智群体的抽象测试样例。
    策略仅表示通用交互决策风格，不绑定跟驰、换道、交叉口等具体场景。
    """
    strategies = ["cooperate", "maintain", "compete"]
    groups = [
        GroupSpec("G1", strategies, np.array([0.25, 0.50, 0.25]), learning_rate=0.90),
        GroupSpec("G2", strategies, np.array([0.35, 0.45, 0.20]), learning_rate=1.00),
        GroupSpec("G3", strategies, np.array([0.45, 0.40, 0.15]), learning_rate=1.10),
    ]

    interaction_weights = np.array([
        [0.0, 1.0, 0.8],
        [1.0, 0.0, 1.0],
        [0.8, 1.0, 0.0],
    ], dtype=float)

    # 收益设计遵循：协作-协作具有较高共同收益；单方面竞争可能获得短期收益，
    # 双方竞争会因冲突风险和效率损失得到较低收益；保持策略位于两者之间。
    base = np.array([
        [4.20, 3.80, 2.40],
        [3.50, 3.20, 2.55],
        [3.90, 3.00, 1.25],
    ], dtype=float)

    payoff_matrices: Dict[Tuple[int, int], np.ndarray] = {}
    n = len(groups)
    # 通过轻微群体差异表示不同自主化/决策水平主体的收益敏感度。
    row_scales = [0.96, 1.00, 1.05]
    opponent_bias = [0.00, 0.05, -0.03]
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            A = base * row_scales[i]
            A = A.copy()
            A[:, 0] += opponent_bias[j]
            payoff_matrices[(i, j)] = A

    config = ModelConfig(
        dt=0.05,
        max_steps=4000,
        tolerance=1e-8,
        stable_steps=80,
        mutation_rate=0.003,
        min_probability=1e-12,
        save_interval=1,
    )
    return groups, interaction_weights, payoff_matrices, config


def write_demo_inputs(groups: List[GroupSpec], interaction_weights: np.ndarray,
                      payoff_matrices: Dict[Tuple[int, int], np.ndarray], config: ModelConfig,
                      input_dir: Path) -> None:
    input_dir.mkdir(parents=True, exist_ok=True)
    groups_json = {
        "groups": [
            {
                "group_id": g.group_id,
                "strategies": g.strategies,
                "initial_distribution": g.initial_distribution.tolist(),
                "learning_rate": g.learning_rate,
            }
            for g in groups
        ],
        "interaction_weights": interaction_weights.tolist(),
    }
    (input_dir / "groups.json").write_text(json.dumps(groups_json, ensure_ascii=False, indent=2), encoding="utf-8")

    npz_data = {}
    for (i, j), mat in payoff_matrices.items():
        npz_data[f"payoff_{i}_{j}"] = mat
    np.savez(input_dir / "payoff_matrices.npz", **npz_data)

    config_dict = {
        "dt": config.dt,
        "max_steps": config.max_steps,
        "tolerance": config.tolerance,
        "stable_steps": config.stable_steps,
        "mutation_rate": config.mutation_rate,
        "min_probability": config.min_probability,
        "save_interval": config.save_interval,
    }
    (input_dir / "config.json").write_text(json.dumps(config_dict, ensure_ascii=False, indent=2), encoding="utf-8")


def load_custom_case(groups_json: Path, payoffs_npz: Path, config_json: Path):
    data = json.loads(groups_json.read_text(encoding="utf-8"))
    groups = []
    for item in data["groups"]:
        groups.append(GroupSpec(
            group_id=item["group_id"],
            strategies=list(item["strategies"]),
            initial_distribution=np.asarray(item["initial_distribution"], dtype=float),
            learning_rate=float(item.get("learning_rate", 1.0)),
        ))
    interaction_weights = np.asarray(data["interaction_weights"], dtype=float)

    npz = np.load(payoffs_npz)
    payoff_matrices = {}
    for key in npz.files:
        if not key.startswith("payoff_"):
            continue
        _, i, j = key.split("_")
        payoff_matrices[(int(i), int(j))] = np.asarray(npz[key], dtype=float)

    c = json.loads(config_json.read_text(encoding="utf-8"))
    config = ModelConfig(**c)
    return groups, interaction_weights, payoff_matrices, config


def main() -> None:
    parser = argparse.ArgumentParser(description="异智多主体策略进化博弈模型")
    parser.add_argument("--demo", action="store_true", help="运行内置可复现实验样例")
    parser.add_argument("--groups-json", type=Path)
    parser.add_argument("--payoffs-npz", type=Path)
    parser.add_argument("--config-json", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("data/output"))
    parser.add_argument("--write-demo-inputs", type=Path, default=None,
                        help="将内置样例输入另存到指定目录")
    args = parser.parse_args()

    if args.demo:
        groups, weights, payoffs, config = make_demo_case()
        if args.write_demo_inputs is not None:
            write_demo_inputs(groups, weights, payoffs, config, args.write_demo_inputs)
    else:
        if not (args.groups_json and args.payoffs_npz and args.config_json):
            parser.error("非 --demo 模式下必须同时提供 --groups-json、--payoffs-npz 和 --config-json")
        groups, weights, payoffs, config = load_custom_case(args.groups_json, args.payoffs_npz, args.config_json)

    evolution, payoff_trace, equilibrium = run_model(groups, weights, payoffs, config)
    save_outputs(evolution, payoff_trace, equilibrium, args.output_dir)

    print("模型运行完成。")
    print(f"converged={equilibrium['converged']}, final_step={equilibrium['final_step']}")
    for gid, info in equilibrium["groups"].items():
        dist = ", ".join(f"{k}={v:.4f}" for k, v in info["strategy_distribution"].items())
        print(f"{gid}: {dist}; dominant={info['dominant_strategy']}; mean_payoff={info['mean_payoff']:.4f}")


if __name__ == "__main__":
    main()
