#!/usr/bin/env python3
"""Cooperative slot reservation for bidirectional traffic in a one-lane work zone.

The scheduler preserves FIFO order within each direction and enumerates all
feasible interleavings of the two queues. Each candidate is assigned the
earliest safe entry/exit times under same-direction headway and opposite-
direction clearance constraints. The minimum-cost schedule is exported with
reproducible metrics and a PNG visualization.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont


@dataclass(frozen=True)
class Vehicle:
    vehicle_id: str
    direction: str
    ready_time_s: float
    distance_to_entry_m: float
    speed_mps: float
    priority_weight: float = 1.0


DEFAULT_CONFIG = {
    "scenario": {
        "workzone_length_m": 80.0,
        "traverse_speed_mps": 10.0,
        "same_direction_headway_s": 2.0,
        "opposite_clearance_s": 1.0,
        "speed_limit_mps": 12.0,
        "acceleration_min_mps2": -3.0,
        "acceleration_max_mps2": 2.0,
        "control_response_s": 2.0,
    },
    "objective": {
        "switch_penalty": 4.0,
        "fairness_weight": 0.35,
    },
    "vehicles": [
        {"vehicle_id": "E1", "direction": "E", "ready_time_s": 0.0, "distance_to_entry_m": 36.0, "speed_mps": 8.0, "priority_weight": 1.0},
        {"vehicle_id": "E2", "direction": "E", "ready_time_s": 1.0, "distance_to_entry_m": 44.0, "speed_mps": 7.5, "priority_weight": 1.0},
        {"vehicle_id": "E3", "direction": "E", "ready_time_s": 2.2, "distance_to_entry_m": 55.0, "speed_mps": 8.5, "priority_weight": 1.4},
        {"vehicle_id": "E4", "direction": "E", "ready_time_s": 4.0, "distance_to_entry_m": 68.0, "speed_mps": 8.0, "priority_weight": 1.0},
        {"vehicle_id": "E5", "direction": "E", "ready_time_s": 6.0, "distance_to_entry_m": 82.0, "speed_mps": 9.0, "priority_weight": 1.0},
        {"vehicle_id": "W1", "direction": "W", "ready_time_s": 0.4, "distance_to_entry_m": 38.0, "speed_mps": 7.5, "priority_weight": 1.0},
        {"vehicle_id": "W2", "direction": "W", "ready_time_s": 1.4, "distance_to_entry_m": 49.0, "speed_mps": 8.0, "priority_weight": 1.0},
        {"vehicle_id": "W3", "direction": "W", "ready_time_s": 3.0, "distance_to_entry_m": 61.0, "speed_mps": 8.5, "priority_weight": 1.0},
        {"vehicle_id": "W4", "direction": "W", "ready_time_s": 5.0, "distance_to_entry_m": 73.0, "speed_mps": 8.0, "priority_weight": 1.3},
        {"vehicle_id": "W5", "direction": "W", "ready_time_s": 7.0, "distance_to_entry_m": 88.0, "speed_mps": 9.0, "priority_weight": 1.0},
    ],
}


def clip(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


def load_config(path: Path | None) -> dict:
    config = json.loads(json.dumps(DEFAULT_CONFIG))
    if path is None:
        return config
    supplied = json.loads(path.read_text(encoding="utf-8"))
    for key, value in supplied.items():
        if isinstance(value, dict) and isinstance(config.get(key), dict):
            config[key].update(value)
        else:
            config[key] = value
    return config


def parse_vehicles(config: dict) -> list[Vehicle]:
    vehicles = [Vehicle(**item) for item in config["vehicles"]]
    if len(vehicles) < 2:
        raise ValueError("at least two vehicles are required")
    if len({v.vehicle_id for v in vehicles}) != len(vehicles):
        raise ValueError("vehicle_id values must be unique")
    if any(v.direction not in {"E", "W"} for v in vehicles):
        raise ValueError("direction must be E or W")
    if any(v.ready_time_s < 0 or v.distance_to_entry_m < 0 or v.speed_mps < 0 or v.priority_weight <= 0 for v in vehicles):
        raise ValueError("vehicle times, distances and speeds must be non-negative; priority must be positive")
    return vehicles


def validate_config(config: dict) -> None:
    scenario = config["scenario"]
    positive = [
        "workzone_length_m", "traverse_speed_mps", "same_direction_headway_s",
        "opposite_clearance_s", "speed_limit_mps", "control_response_s",
    ]
    if any(float(scenario[name]) <= 0 for name in positive):
        raise ValueError("scenario time, length and speed parameters must be positive")
    if scenario["acceleration_min_mps2"] >= scenario["acceleration_max_mps2"]:
        raise ValueError("acceleration bounds are invalid")
    if config["objective"]["switch_penalty"] < 0 or config["objective"]["fairness_weight"] < 0:
        raise ValueError("objective weights must be non-negative")
    vehicles = parse_vehicles(config)
    if {vehicle.direction for vehicle in vehicles} != {"E", "W"}:
        raise ValueError("the bidirectional work-zone model requires at least one E and one W vehicle")


def minimum_travel_time(vehicle: Vehicle, scenario: dict) -> float:
    """Minimum approach time under the acceleration and speed limits."""
    distance = vehicle.distance_to_entry_m
    speed = min(vehicle.speed_mps, scenario["speed_limit_mps"])
    acceleration = scenario["acceleration_max_mps2"]
    speed_limit = scenario["speed_limit_mps"]
    if distance <= 0.0:
        return 0.0
    if acceleration <= 0.0 or speed >= speed_limit:
        return distance / max(speed, 1e-6)
    acceleration_distance = (speed_limit * speed_limit - speed * speed) / (2.0 * acceleration)
    if distance <= acceleration_distance:
        return (-speed + math.sqrt(speed * speed + 2.0 * acceleration * distance)) / acceleration
    return (speed_limit - speed) / acceleration + (distance - acceleration_distance) / speed_limit


def effective_ready_time(vehicle: Vehicle, scenario: dict) -> float:
    return max(vehicle.ready_time_s, minimum_travel_time(vehicle, scenario))


def direction_queues(vehicles: Iterable[Vehicle], scenario: dict) -> dict[str, list[Vehicle]]:
    return {
        direction: sorted(
            (v for v in vehicles if v.direction == direction),
            key=lambda v: (effective_ready_time(v, scenario), v.vehicle_id),
        )
        for direction in ("E", "W")
    }


def enumerate_fifo_sequences(east: list[Vehicle], west: list[Vehicle]) -> Iterable[list[Vehicle]]:
    sequence: list[Vehicle] = []

    def visit(i: int, j: int) -> Iterable[list[Vehicle]]:
        if i == len(east) and j == len(west):
            yield list(sequence)
            return
        if i < len(east):
            sequence.append(east[i])
            yield from visit(i + 1, j)
            sequence.pop()
        if j < len(west):
            sequence.append(west[j])
            yield from visit(i, j + 1)
            sequence.pop()

    yield from visit(0, 0)


def schedule_sequence(sequence: list[Vehicle], config: dict) -> tuple[list[dict], dict]:
    scenario = config["scenario"]
    objective = config["objective"]
    traversal = scenario["workzone_length_m"] / scenario["traverse_speed_mps"]
    rows: list[dict] = []
    last_direction: str | None = None
    last_entry = -math.inf
    last_exit = -math.inf
    switch_count = 0
    for order, vehicle in enumerate(sequence, 1):
        release_time = effective_ready_time(vehicle, scenario)
        if last_direction is None:
            entry = release_time
        elif vehicle.direction == last_direction:
            entry = max(release_time, last_entry + scenario["same_direction_headway_s"])
        else:
            entry = max(release_time, last_exit + scenario["opposite_clearance_s"])
            switch_count += 1
        exit_time = entry + traversal
        delay = entry - release_time
        time_to_entry = max(entry, 0.1)
        target_speed = min(scenario["speed_limit_mps"], vehicle.distance_to_entry_m / time_to_entry)
        target_acceleration = clip(
            (target_speed - vehicle.speed_mps) / scenario["control_response_s"],
            scenario["acceleration_min_mps2"],
            scenario["acceleration_max_mps2"],
        )
        rows.append({
            "order": order,
            "vehicle_id": vehicle.vehicle_id,
            "direction": vehicle.direction,
            "input_release_time_s": vehicle.ready_time_s,
            "kinematic_arrival_time_s": minimum_travel_time(vehicle, scenario),
            "effective_ready_time_s": release_time,
            "entry_time_s": entry,
            "exit_time_s": exit_time,
            "delay_s": delay,
            "priority_weight": vehicle.priority_weight,
            "target_speed_mps": target_speed,
            "target_acceleration_mps2": target_acceleration,
        })
        last_direction = vehicle.direction
        last_entry = entry
        last_exit = exit_time
    weighted_delay = sum(r["priority_weight"] * r["delay_s"] for r in rows)
    max_delay = max(r["delay_s"] for r in rows)
    cost = weighted_delay + objective["switch_penalty"] * switch_count + objective["fairness_weight"] * max_delay
    return rows, {
        "objective_value": cost,
        "weighted_delay_s": weighted_delay,
        "maximum_delay_s": max_delay,
        "mean_delay_s": sum(r["delay_s"] for r in rows) / len(rows),
        "switch_count": switch_count,
        "makespan_s": max(r["exit_time_s"] for r in rows),
    }


def optimize_schedule(config: dict) -> tuple[list[dict], dict]:
    validate_config(config)
    vehicles = parse_vehicles(config)
    scenario = config["scenario"]
    queues = direction_queues(vehicles, scenario)
    best_rows: list[dict] | None = None
    best_metrics: dict | None = None
    evaluated = 0
    start = time.perf_counter()
    for sequence in enumerate_fifo_sequences(queues["E"], queues["W"]):
        rows, metrics = schedule_sequence(sequence, config)
        evaluated += 1
        key = (metrics["objective_value"], metrics["maximum_delay_s"], metrics["switch_count"])
        if best_metrics is None or key < (
            best_metrics["objective_value"], best_metrics["maximum_delay_s"], best_metrics["switch_count"]
        ):
            best_rows, best_metrics = rows, metrics
    assert best_rows is not None and best_metrics is not None
    runtime_ms = (time.perf_counter() - start) * 1000.0
    fcfs_sequence = sorted(vehicles, key=lambda v: (effective_ready_time(v, scenario), v.vehicle_id))
    _, fcfs_metrics = schedule_sequence(fcfs_sequence, config)
    baseline_delay = fcfs_metrics["weighted_delay_s"]
    best_metrics.update({
        "vehicle_count": len(vehicles),
        "candidate_sequence_count": evaluated,
        "opposite_overlap_count": count_opposite_overlaps(best_rows),
        "minimum_same_direction_headway_s": minimum_same_direction_headway(best_rows),
        "fcfs_weighted_delay_s": fcfs_metrics["weighted_delay_s"],
        "weighted_delay_improvement_percent": (
            100.0 * (baseline_delay - best_metrics["weighted_delay_s"]) / baseline_delay
            if baseline_delay > 0.0 else 0.0
        ),
        "runtime_ms": runtime_ms,
    })
    return best_rows, best_metrics


def count_opposite_overlaps(rows: list[dict]) -> int:
    count = 0
    for i, left in enumerate(rows):
        for right in rows[i + 1:]:
            overlap = max(left["entry_time_s"], right["entry_time_s"]) < min(left["exit_time_s"], right["exit_time_s"]) - 1e-9
            if overlap and left["direction"] != right["direction"]:
                count += 1
    return count


def minimum_same_direction_headway(rows: list[dict]) -> float:
    differences: list[float] = []
    for direction in ("E", "W"):
        entries = sorted(r["entry_time_s"] for r in rows if r["direction"] == direction)
        differences.extend(entries[i] - entries[i - 1] for i in range(1, len(entries)))
    return min(differences) if differences else math.inf


def write_csv(rows: list[dict], path: Path) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: f"{v:.6f}" if isinstance(v, float) else v for k, v in row.items()})


def plot_results(rows: list[dict], metrics: dict, path: Path) -> None:
    image = Image.new("RGB", (1500, 1050), "white")
    draw = ImageDraw.Draw(image)
    font_path = "/System/Library/Fonts/Supplemental/Arial.ttf"
    title_font = ImageFont.truetype(font_path, 31)
    font = ImageFont.truetype(font_path, 23)
    small = ImageFont.truetype(font_path, 18)
    colors = {"E": "#2474B5", "W": "#E07A2D"}
    left, right = 190, 1435
    top, bottom = 120, 580
    end_time = max(r["exit_time_s"] for r in rows)
    draw.text((750, 38), "One-lane work-zone reservation schedule", font=title_font, fill="#111111", anchor="ma")
    for tick in range(0, int(math.ceil(end_time / 5.0)) * 5 + 1, 5):
        x = left + (right - left) * tick / end_time
        draw.line((x, top, x, bottom), fill="#dddddd", width=1)
        draw.text((x, bottom + 12), str(tick), font=small, fill="#333333", anchor="ma")
    row_height = (bottom - top) / len(rows)
    for index, row in enumerate(rows):
        y = top + index * row_height + row_height / 2
        x1 = left + (right - left) * row["entry_time_s"] / end_time
        x2 = left + (right - left) * row["exit_time_s"] / end_time
        draw.text((left - 18, y), f"{row['vehicle_id']} ({row['direction']})", font=small, fill="#222222", anchor="rm")
        draw.rounded_rectangle((x1, y - 15, x2, y + 15), radius=8, fill=colors[row["direction"]], outline="#333333")
        draw.text(((x1 + x2) / 2, y), f"{row['entry_time_s']:.1f}-{row['exit_time_s']:.1f}", font=small, fill="white", anchor="mm")
    draw.text(((left + right) / 2, bottom + 34), "Time (s)", font=font, fill="#222222", anchor="ma")
    chart_top, chart_bottom = 735, 980
    max_delay = max(r["delay_s"] for r in rows)
    bar_width = (right - left) / len(rows)
    draw.text((750, 670), "Vehicle entry delay", font=title_font, fill="#111111", anchor="ma")
    for index, row in enumerate(rows):
        x1 = left + index * bar_width + 12
        x2 = left + (index + 1) * bar_width - 12
        y2 = chart_bottom
        y1 = chart_bottom - (chart_bottom - chart_top) * row["delay_s"] / max(max_delay, 1.0)
        draw.rectangle((x1, y1, x2, y2), fill=colors[row["direction"]], outline="#333333")
        draw.text(((x1 + x2) / 2, y1 - 8), f"{row['delay_s']:.1f}", font=small, fill="#222222", anchor="ms")
        draw.text(((x1 + x2) / 2, y2 + 8), row["vehicle_id"], font=small, fill="#222222", anchor="ma")
    draw.text((left - 18, chart_top), "Delay (s)", font=small, fill="#222222", anchor="rs")
    draw.text((right, 1018), f"Opposite overlap: {metrics['opposite_overlap_count']}   Switches: {metrics['switch_count']}", font=small, fill="#333333", anchor="ra")
    image.save(path, "PNG", dpi=(180, 180))


def run(config_path: Path | None, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    config = load_config(config_path)
    rows, metrics = optimize_schedule(config)
    write_csv(rows, output_dir / "workzone_schedule.csv")
    (output_dir / "workzone_metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    plot_results(rows, metrics, output_dir / "workzone_result.png")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, help="optional JSON configuration file")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"), help="result directory")
    args = parser.parse_args()
    run(args.config, args.output_dir)


if __name__ == "__main__":
    main()
