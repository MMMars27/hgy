#!/usr/bin/env python3
"""基于贝叶斯意图推断的后车快速逼近协同避让模型。

适用场景：正常多车道行驶中，后车以较高相对速度快速逼近自车。模型根据
后车加速度与横向速度观测推断其减速、持续逼近或向相邻车道超越的意图，
再联合相邻车道前后车辆选择保持、加速或协同换道避让方案。

运行示例：
    python rear_approach_bayesian_evasion.py --demo --output-dir data/output
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


MODES = ("cooperative_brake", "persistent_approach", "adjacent_overtake")
MANEUVERS = ("keep_lane", "accelerate", "change_left")
MODE_LABELS = {
    "cooperative_brake": "主动减速",
    "persistent_approach": "持续逼近",
    "adjacent_overtake": "向左超越",
}
MANEUVER_LABELS = {
    "keep_lane": "保持车道",
    "accelerate": "纵向加速",
    "change_left": "协同向左换道",
}


@dataclass
class VehicleState:
    vehicle_id: str
    role: str
    lane: int
    position_m: float
    speed_mps: float
    length_m: float = 4.8


@dataclass
class Observation:
    time_s: float
    acceleration_mps2: float
    lateral_speed_mps: float


@dataclass
class Config:
    time_step_s: float = 0.2
    decision_horizon_s: float = 4.0
    simulation_time_s: float = 5.0
    lane_width_m: float = 3.5
    lane_change_duration_s: float = 3.0
    standstill_gap_m: float = 4.0
    time_headway_s: float = 1.0
    gap_uncertainty_scale_m: float = 2.0
    risk_weight: float = 120.0
    control_weight: float = 0.8
    speed_weight: float = 0.15
    lane_change_cost: float = 1.2
    cooperation_weight: float = 0.7
    reference_speed_mps: float = 24.0
    maximum_acceptable_risk: float = 0.15


MODE_MEANS = {
    "cooperative_brake": (-2.2, 0.0),
    "persistent_approach": (0.15, 0.0),
    "adjacent_overtake": (0.0, 0.75),
}
MODE_SIGMAS = {
    "cooperative_brake": (0.65, 0.20),
    "persistent_approach": (0.55, 0.18),
    "adjacent_overtake": (0.75, 0.28),
}
TRANSITION = {
    "cooperative_brake": {"cooperative_brake": 0.86, "persistent_approach": 0.10, "adjacent_overtake": 0.04},
    "persistent_approach": {"cooperative_brake": 0.06, "persistent_approach": 0.88, "adjacent_overtake": 0.06},
    "adjacent_overtake": {"cooperative_brake": 0.04, "persistent_approach": 0.08, "adjacent_overtake": 0.88},
}


def normal_pdf(value: float, mean: float, sigma: float) -> float:
    z = (value - mean) / sigma
    return math.exp(-0.5 * z * z) / (sigma * math.sqrt(2.0 * math.pi))


def bayesian_intent_inference(observations: Sequence[Observation]) -> List[Dict[str, float]]:
    """利用隐意图马尔可夫转移与二维高斯观测似然递推后验概率。"""
    posterior = {mode: 1.0 / len(MODES) for mode in MODES}
    history: List[Dict[str, float]] = []
    for obs in observations:
        prior = {
            mode: sum(posterior[previous] * TRANSITION[previous][mode] for previous in MODES)
            for mode in MODES
        }
        unnormalized = {}
        for mode in MODES:
            mean_a, mean_vy = MODE_MEANS[mode]
            sigma_a, sigma_vy = MODE_SIGMAS[mode]
            likelihood = normal_pdf(obs.acceleration_mps2, mean_a, sigma_a) * normal_pdf(
                obs.lateral_speed_mps, mean_vy, sigma_vy
            )
            unnormalized[mode] = max(1e-15, likelihood * prior[mode])
        normalizer = sum(unnormalized.values())
        posterior = {mode: unnormalized[mode] / normalizer for mode in MODES}
        history.append({
            "time_s": obs.time_s,
            "observed_acceleration_mps2": obs.acceleration_mps2,
            "observed_lateral_speed_mps": obs.lateral_speed_mps,
            **{f"probability_{mode}": posterior[mode] for mode in MODES},
        })
    return history


def desired_gap(speed_mps: float, config: Config) -> float:
    return config.standstill_gap_m + config.time_headway_s * max(0.0, speed_mps)


def logistic_collision_risk(minimum_margin_m: float, scale_m: float) -> float:
    exponent = max(-60.0, min(60.0, minimum_margin_m / scale_m))
    return 1.0 / (1.0 + math.exp(exponent))


def propagate(position: float, speed: float, acceleration: float, horizon: float) -> Tuple[float, float]:
    next_speed = max(0.0, speed + acceleration * horizon)
    next_position = position + speed * horizon + 0.5 * acceleration * horizon * horizon
    return next_position, next_speed


def evaluate_maneuver(
    maneuver: str,
    states: Dict[str, VehicleState],
    posterior: Dict[str, float],
    config: Config,
) -> Dict[str, float | str]:
    """评价一个自车动作和相邻车道协同加速度组合的期望社会代价。"""
    ego = states["ego"]
    rear = states["fast_rear"]
    adj_front = states["adjacent_front"]
    adj_rear = states["adjacent_rear"]
    ego_actions = {"keep_lane": 0.0, "accelerate": 1.2, "change_left": 0.2}
    ego_acceleration = ego_actions[maneuver]
    cooperation_grid = (-1.0, -0.5, 0.0, 0.5, 1.0) if maneuver == "change_left" else (0.0,)
    best: Dict[str, float | str] | None = None
    horizon = config.decision_horizon_s

    for front_acceleration in cooperation_grid:
        for rear_acceleration in cooperation_grid:
            ego_x, ego_v = propagate(ego.position_m, ego.speed_mps, ego_acceleration, horizon)
            af_x, _ = propagate(adj_front.position_m, adj_front.speed_mps, front_acceleration, horizon)
            ar_x, ar_v = propagate(adj_rear.position_m, adj_rear.speed_mps, rear_acceleration, horizon)
            front_margin = af_x - ego_x - 0.5 * (adj_front.length_m + ego.length_m) - desired_gap(ego_v, config)
            rear_margin = ego_x - ar_x - 0.5 * (ego.length_m + adj_rear.length_m) - desired_gap(ar_v, config)

            expected_rear_risk = 0.0
            for mode in MODES:
                mode_acceleration, _ = MODE_MEANS[mode]
                rear_x, rear_v = propagate(rear.position_m, rear.speed_mps, mode_acceleration, horizon)
                same_lane_margin = ego_x - rear_x - 0.5 * (ego.length_m + rear.length_m) - desired_gap(rear_v, config)
                risk = logistic_collision_risk(same_lane_margin, config.gap_uncertainty_scale_m)
                if maneuver == "change_left":
                    # 横向分离后，持续逼近风险显著下降；若后车也左侧超越，则保留冲突概率。
                    exposure = 0.06 if mode != "adjacent_overtake" else 0.72
                    risk *= exposure
                expected_rear_risk += posterior[mode] * risk

            adjacent_risk = 0.0
            if maneuver == "change_left":
                adjacent_risk = max(
                    logistic_collision_risk(front_margin, config.gap_uncertainty_scale_m),
                    logistic_collision_risk(rear_margin, config.gap_uncertainty_scale_m),
                )
            total_risk = 1.0 - (1.0 - expected_rear_risk) * (1.0 - adjacent_risk)
            control_cost = config.control_weight * ego_acceleration * ego_acceleration
            speed_cost = config.speed_weight * (ego_v - config.reference_speed_mps) ** 2
            cooperation_cost = config.cooperation_weight * (
                front_acceleration * front_acceleration + rear_acceleration * rear_acceleration
            )
            discrete_cost = config.lane_change_cost if maneuver == "change_left" else 0.0
            total_cost = config.risk_weight * total_risk + control_cost + speed_cost + cooperation_cost + discrete_cost
            candidate: Dict[str, float | str] = {
                "maneuver": maneuver,
                "maneuver_label": MANEUVER_LABELS[maneuver],
                "expected_collision_risk": total_risk,
                "objective_value": total_cost,
                "ego_acceleration_mps2": ego_acceleration,
                "adjacent_front_acceleration_mps2": front_acceleration,
                "adjacent_rear_acceleration_mps2": rear_acceleration,
                "predicted_adjacent_front_margin_m": front_margin,
                "predicted_adjacent_rear_margin_m": rear_margin,
            }
            if best is None or float(candidate["objective_value"]) < float(best["objective_value"]):
                best = candidate
    assert best is not None
    return best


def select_maneuver(
    states: Dict[str, VehicleState], posterior: Dict[str, float], config: Config
) -> Tuple[List[Dict[str, float | str]], Dict[str, float | str]]:
    evaluations = [evaluate_maneuver(maneuver, states, posterior, config) for maneuver in MANEUVERS]
    feasible = [row for row in evaluations if float(row["expected_collision_risk"]) <= config.maximum_acceptable_risk]
    selected = min(feasible or evaluations, key=lambda row: float(row["objective_value"]))
    for row in evaluations:
        row["selected"] = "是" if row is selected else "否"
    return evaluations, selected


def smoothstep5(progress: float) -> float:
    s = min(1.0, max(0.0, progress))
    return 10.0 * s ** 3 - 15.0 * s ** 4 + 6.0 * s ** 5


def simulate_trajectory(
    states: Dict[str, VehicleState], selected: Dict[str, float | str], config: Config
) -> List[Dict[str, float]]:
    current = {role: VehicleState(**asdict(state)) for role, state in states.items()}
    history: List[Dict[str, float]] = []
    dt = config.time_step_s
    lane_change = str(selected["maneuver"]) == "change_left"
    accelerations = {
        "ego": float(selected["ego_acceleration_mps2"]),
        "fast_rear": -0.4,
        "adjacent_front": float(selected["adjacent_front_acceleration_mps2"]),
        "adjacent_rear": float(selected["adjacent_rear_acceleration_mps2"]),
    }
    steps = int(round(config.simulation_time_s / dt)) + 1
    for step in range(steps):
        time_s = step * dt
        progress = smoothstep5(time_s / config.lane_change_duration_s) if lane_change else 0.0
        ego_y = config.lane_width_m * (1.0 - progress)
        lateral_separation = config.lane_width_m - ego_y
        ego = current["ego"]
        rear = current["fast_rear"]
        af = current["adjacent_front"]
        ar = current["adjacent_rear"]
        rear_gap = ego.position_m - rear.position_m - 0.5 * (ego.length_m + rear.length_m)
        rear_margin = rear_gap - desired_gap(rear.speed_mps, config)
        front_gap = af.position_m - ego.position_m - 0.5 * (af.length_m + ego.length_m)
        adjacent_rear_gap = ego.position_m - ar.position_m - 0.5 * (ego.length_m + ar.length_m)
        adjacent_front_margin = front_gap - desired_gap(ego.speed_mps, config)
        adjacent_rear_margin = adjacent_rear_gap - desired_gap(ar.speed_mps, config)
        closing_speed = max(0.0, rear.speed_mps - ego.speed_mps)
        ttc = rear_gap / closing_speed if closing_speed > 1e-6 else 99.0
        exposure = max(0.0, 1.0 - lateral_separation / config.lane_width_m)
        effective_risk = exposure * logistic_collision_risk(rear_margin, config.gap_uncertainty_scale_m)
        history.append({
            "time_s": round(time_s, 3),
            "ego_position_m": ego.position_m,
            "ego_speed_mps": ego.speed_mps,
            "ego_lateral_position_m": ego_y,
            "fast_rear_position_m": rear.position_m,
            "fast_rear_speed_mps": rear.speed_mps,
            "adjacent_front_position_m": af.position_m,
            "adjacent_front_speed_mps": af.speed_mps,
            "adjacent_rear_position_m": ar.position_m,
            "adjacent_rear_speed_mps": ar.speed_mps,
            "same_lane_rear_gap_m": rear_gap,
            "same_lane_rear_margin_m": rear_margin,
            "adjacent_front_margin_m": adjacent_front_margin,
            "adjacent_rear_margin_m": adjacent_rear_margin,
            "rear_ttc_s": min(99.0, ttc),
            "effective_collision_risk": effective_risk,
        })
        if step == steps - 1:
            break
        for role, state in current.items():
            acceleration = accelerations[role]
            state.position_m += state.speed_mps * dt + 0.5 * acceleration * dt * dt
            state.speed_mps = max(0.0, state.speed_mps + acceleration * dt)
    return history


def metrics_from_results(
    posterior_history: List[Dict[str, float]],
    evaluations: List[Dict[str, float | str]],
    selected: Dict[str, float | str],
    trajectory: List[Dict[str, float]],
    config: Config,
) -> Dict[str, object]:
    final_posterior = posterior_history[-1]
    dominant_mode = max(MODES, key=lambda mode: final_posterior[f"probability_{mode}"])
    during_change = [row for row in trajectory if row["time_s"] <= config.lane_change_duration_s + 1e-9]
    return {
        "model": "基于贝叶斯意图推断的后车快速逼近协同避让模型",
        "dominant_rear_intent": dominant_mode,
        "dominant_rear_intent_label": MODE_LABELS[dominant_mode],
        "dominant_intent_probability": round(final_posterior[f"probability_{dominant_mode}"], 4),
        "selected_maneuver": selected["maneuver"],
        "selected_maneuver_label": selected["maneuver_label"],
        "selected_expected_collision_risk": round(float(selected["expected_collision_risk"]), 4),
        "keep_lane_expected_collision_risk": round(float(evaluations[0]["expected_collision_risk"]), 4),
        "risk_reduction_ratio": round(
            1.0 - float(selected["expected_collision_risk"]) / max(1e-9, float(evaluations[0]["expected_collision_risk"])), 4
        ),
        "minimum_adjacent_front_margin_m": round(min(row["adjacent_front_margin_m"] for row in during_change), 3),
        "minimum_adjacent_rear_margin_m": round(min(row["adjacent_rear_margin_m"] for row in during_change), 3),
        "minimum_rear_ttc_before_lateral_separation_s": round(min(row["rear_ttc_s"] for row in during_change[:4]), 3),
        "lane_change_completed": trajectory[-1]["ego_lateral_position_m"] <= 1e-6,
        "simulation_steps": len(trajectory),
    }


def write_csv(path: Path, rows: Iterable[Dict[str, object]]) -> None:
    rows = list(rows)
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _pillow_components():
    from PIL import Image, ImageDraw, ImageFont
    return Image, ImageDraw, ImageFont


def _font(size: int, bold: bool = False):
    _, _, image_font = _pillow_components()
    candidates = [
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/System/Library/Fonts/STHeiti Medium.ttc" if bold else "/System/Library/Fonts/STHeiti Light.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            try:
                return image_font.truetype(candidate, size, index=0)
            except OSError:
                continue
    return image_font.load_default()


def _polyline(draw, points, color, width=4, dashed=False):
    if not dashed:
        draw.line(points, fill=color, width=width, joint="curve")
        return
    for start, end in zip(points, points[1:]):
        x1, y1 = start
        x2, y2 = end
        distance = math.hypot(x2 - x1, y2 - y1)
        if distance <= 0:
            continue
        ux, uy = (x2 - x1) / distance, (y2 - y1) / distance
        cursor = 0.0
        while cursor < distance:
            finish = min(distance, cursor + 10)
            draw.line((x1 + ux * cursor, y1 + uy * cursor, x1 + ux * finish, y1 + uy * finish), fill=color, width=width)
            cursor += 18


def _line_chart(path: Path, title: str, times: List[float], series, y_label: str, size=(1600, 820)) -> None:
    image_cls, image_draw, _ = _pillow_components()
    image = image_cls.new("RGB", size, "white")
    draw = image_draw.Draw(image)
    title_font, label_font, tick_font = _font(40, True), _font(26), _font(21)
    left, top, right, bottom = 145, 110, size[0] - 70, size[1] - 135
    values = [value for _, items, _, _ in series for value in items]
    y_min, y_max = min(values), max(values)
    span = max(1e-6, y_max - y_min)
    y_min -= 0.08 * span
    y_max += 0.08 * span
    x_min, x_max = min(times), max(times)
    sx = lambda value: left + (value - x_min) / max(1e-9, x_max - x_min) * (right - left)
    sy = lambda value: bottom - (value - y_min) / max(1e-9, y_max - y_min) * (bottom - top)
    draw.text((size[0] / 2, 42), title, font=title_font, fill="#1F1F1F", anchor="mm")
    for index in range(6):
        value = y_min + (y_max - y_min) * index / 5
        y = sy(value)
        draw.line((left, y, right, y), fill="#E2E2E2", width=2)
        draw.text((left - 15, y), f"{value:.2f}", font=tick_font, fill="#505050", anchor="rm")
    for index in range(6):
        value = x_min + (x_max - x_min) * index / 5
        x = sx(value)
        draw.line((x, top, x, bottom), fill="#EEEEEE", width=2)
        draw.text((x, bottom + 18), f"{value:.1f}", font=tick_font, fill="#505050", anchor="ma")
    draw.line((left, top, left, bottom), fill="#333333", width=3)
    draw.line((left, bottom, right, bottom), fill="#333333", width=3)
    for _, items, color, dashed in series:
        _polyline(draw, [(sx(t), sy(v)) for t, v in zip(times, items)], color, 5 if not dashed else 3, dashed)
    for index, (label, _, color, dashed) in enumerate(series):
        x = left + 10 + (index % 3) * 420
        y = size[1] - 72 + (index // 3) * 34
        _polyline(draw, [(x, y), (x + 48, y)], color, 4, dashed)
        draw.text((x + 60, y), label, font=tick_font, fill="#303030", anchor="lm")
    draw.text(((left + right) / 2, size[1] - 104), "时间 / s", font=label_font, fill="#303030", anchor="mm")
    draw.text((left + 12, top + 10), y_label, font=label_font, fill="#303030", anchor="la")
    image.save(path)


def draw_intent_and_risk(posterior_history, evaluations, path: Path) -> None:
    image_cls, _, _ = _pillow_components()
    upper_path, lower_path = path.with_name("_intent.png"), path.with_name("_risk.png")
    times = [float(row["time_s"]) for row in posterior_history]
    _line_chart(upper_path, "后车隐含驾驶意图后验概率", times, [
        ("主动减速", [float(row["probability_cooperative_brake"]) for row in posterior_history], "#70AD47", False),
        ("持续逼近", [float(row["probability_persistent_approach"]) for row in posterior_history], "#C00000", False),
        ("向左超越", [float(row["probability_adjacent_overtake"]) for row in posterior_history], "#4472C4", False),
    ], "后验概率", size=(1600, 560))
    image = image_cls.new("RGB", (1600, 1040), "white")
    image.paste(image_cls.open(upper_path), (0, 0))
    from PIL import ImageDraw
    draw = ImageDraw.Draw(image)
    title_font, label_font, value_font = _font(38, True), _font(27), _font(23)
    draw.text((800, 610), "候选动作期望碰撞风险", font=title_font, fill="#1F1F1F", anchor="mm")
    left, top, right, bottom = 210, 670, 1450, 930
    max_risk = max(float(row["expected_collision_risk"]) for row in evaluations) * 1.12
    bar_width = 220
    colors = ["#A5A5A5", "#ED7D31", "#4472C4"]
    for index, (row, color) in enumerate(zip(evaluations, colors)):
        center = left + 210 + index * 390
        value = float(row["expected_collision_risk"])
        height = value / max(1e-9, max_risk) * (bottom - top)
        draw.rectangle((center - bar_width / 2, bottom - height, center + bar_width / 2, bottom), fill=color)
        draw.text((center, bottom - height - 12), f"{value:.3f}", font=value_font, fill="#303030", anchor="ms")
        draw.text((center, bottom + 22), str(row["maneuver_label"]), font=label_font, fill="#303030", anchor="ma")
    threshold_y = bottom - 0.15 / max(1e-9, max_risk) * (bottom - top)
    _polyline(draw, [(left, threshold_y), (right, threshold_y)], "#C00000", 3, True)
    draw.text((right, threshold_y - 8), "风险阈值 0.15", font=value_font, fill="#C00000", anchor="rs")
    image.save(path)
    upper_path.unlink()


def draw_cooperative_trajectories(trajectory, path: Path) -> None:
    image_cls, _, _ = _pillow_components()
    position_path, lateral_path = path.with_name("_position.png"), path.with_name("_lateral.png")
    times = [float(row["time_s"]) for row in trajectory]
    _line_chart(position_path, "四车纵向轨迹", times, [
        ("相邻车道前车", [float(row["adjacent_front_position_m"]) for row in trajectory], "#70AD47", False),
        ("自车", [float(row["ego_position_m"]) for row in trajectory], "#4472C4", False),
        ("快速逼近后车", [float(row["fast_rear_position_m"]) for row in trajectory], "#C00000", False),
        ("相邻车道后车", [float(row["adjacent_rear_position_m"]) for row in trajectory], "#ED7D31", False),
    ], "纵向位置 / m", size=(1600, 560))
    _line_chart(lateral_path, "自车横向换道轨迹", times, [
        ("自车横向位置", [float(row["ego_lateral_position_m"]) for row in trajectory], "#4472C4", False),
        ("原车道中心", [3.5 for _ in trajectory], "#A5A5A5", True),
        ("目标车道中心", [0.0 for _ in trajectory], "#70AD47", True),
    ], "横向位置 / m", size=(1600, 520))
    image = image_cls.new("RGB", (1600, 1100), "white")
    image.paste(image_cls.open(position_path), (0, 0))
    image.paste(image_cls.open(lateral_path), (0, 580))
    image.save(path)
    position_path.unlink()
    lateral_path.unlink()


def draw_algorithm_flow(path: Path) -> None:
    image_cls, image_draw, _ = _pillow_components()
    image = image_cls.new("RGB", (1500, 1180), "white")
    draw = image_draw.Draw(image)
    title_font, node_font = _font(44, True), _font(29)
    draw.text((750, 55), "后车快速逼近意图推断与协同避让流程", font=title_font, fill="#1F1F1F", anchor="mm")
    labels = [
        "读取四车状态、后车观测序列与模型配置",
        "通过马尔可夫转移预测后车隐含意图先验",
        "根据加速度与横向速度似然更新贝叶斯后验",
        "生成保持、加速和协同向左换道候选动作",
        "联合相邻车道车辆控制计算期望碰撞风险与社会代价",
        "满足风险约束时选择最小代价动作并生成连续轨迹",
        "输出意图后验、决策评价、协同轨迹及运行结果图",
    ]
    ys = [150, 300, 450, 600, 750, 900, 1050]
    for y, label in zip(ys, labels):
        draw.rounded_rectangle((230, y - 52, 1270, y + 52), radius=22, fill="#DCE6F1", outline="#4F81BD", width=4)
        draw.text((750, y), label, font=node_font, fill="#1F1F1F", anchor="mm")
    for y1, y2 in zip(ys, ys[1:]):
        draw.line((750, y1 + 54, 750, y2 - 56), fill="#4F81BD", width=5)
        draw.polygon([(750, y2 - 45), (735, y2 - 67), (765, y2 - 67)], fill="#4F81BD")
    image.save(path)


def write_outputs(posterior_history, evaluations, trajectory, metrics, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "intent_posterior.csv", posterior_history)
    write_csv(output_dir / "maneuver_evaluation.csv", evaluations)
    write_csv(output_dir / "cooperative_trajectory.csv", trajectory)
    (output_dir / "decision_metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    draw_intent_and_risk(posterior_history, evaluations, output_dir / "intent_and_risk.png")
    draw_cooperative_trajectories(trajectory, output_dir / "cooperative_trajectories.png")
    draw_algorithm_flow(output_dir / "algorithm_flow.png")


def demo_inputs() -> Tuple[List[VehicleState], List[Observation], Config]:
    states = [
        VehicleState("CAV-E", "ego", 2, 60.0, 22.0),
        VehicleState("HV-R", "fast_rear", 2, 22.0, 31.0),
        VehicleState("CAV-LF", "adjacent_front", 1, 96.0, 23.5),
        VehicleState("CAV-LR", "adjacent_rear", 1, 25.0, 23.0),
    ]
    observations = [
        Observation(0.0, -0.10, 0.03),
        Observation(0.2, 0.08, 0.02),
        Observation(0.4, 0.12, 0.01),
        Observation(0.6, 0.18, 0.00),
        Observation(0.8, 0.15, 0.02),
        Observation(1.0, 0.20, 0.01),
        Observation(1.2, 0.10, 0.00),
    ]
    return states, observations, Config()


def load_inputs(state_path: Path, observation_path: Path, config_path: Path):
    state_data = json.loads(state_path.read_text(encoding="utf-8"))
    observations = []
    with observation_path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            observations.append(Observation(
                float(row["time_s"]), float(row["acceleration_mps2"]), float(row["lateral_speed_mps"])
            ))
    config_data = json.loads(config_path.read_text(encoding="utf-8"))
    return [VehicleState(**item) for item in state_data], observations, Config(**config_data)


def run(states: Sequence[VehicleState], observations: Sequence[Observation], config: Config):
    role_map = {state.role: state for state in states}
    required = {"ego", "fast_rear", "adjacent_front", "adjacent_rear"}
    if set(role_map) != required:
        raise ValueError("车辆状态必须且仅包含 ego、fast_rear、adjacent_front、adjacent_rear 四种角色")
    posterior_history = bayesian_intent_inference(observations)
    posterior = {mode: posterior_history[-1][f"probability_{mode}"] for mode in MODES}
    evaluations, selected = select_maneuver(role_map, posterior, config)
    trajectory = simulate_trajectory(role_map, selected, config)
    metrics = metrics_from_results(posterior_history, evaluations, selected, trajectory, config)
    return posterior_history, evaluations, trajectory, metrics


def main() -> None:
    parser = argparse.ArgumentParser(description="后车快速逼近意图推断与协同避让")
    parser.add_argument("--state", type=Path, help="vehicle_states.json")
    parser.add_argument("--observations", type=Path, help="rear_observations.csv")
    parser.add_argument("--config", type=Path, help="bayes_cooperation_config.json")
    parser.add_argument("--output-dir", type=Path, default=Path("data/output"))
    parser.add_argument("--demo", action="store_true", help="运行内置后车快速逼近测试场景")
    args = parser.parse_args()
    if args.demo:
        states, observations, config = demo_inputs()
    elif args.state and args.observations and args.config:
        states, observations, config = load_inputs(args.state, args.observations, args.config)
    else:
        parser.error("请使用 --demo，或同时提供 --state、--observations 和 --config")
    posterior_history, evaluations, trajectory, metrics = run(states, observations, config)
    write_outputs(posterior_history, evaluations, trajectory, metrics, args.output_dir)
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
