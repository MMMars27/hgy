#!/usr/bin/env python3
"""基于协同预测控制的三车切入间隙重构模型。

适用场景：车辆从相邻车道切入目标车道时，目标车道前车、切入车和
目标车道后车通过纵向加速度协同，在满足前后安全间隙的条件下完成切入。

运行示例：
    python cutin_cooperative_predictive_control.py --demo --output-dir data/output
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Sequence, Tuple


@dataclass
class VehicleState:
    vehicle_id: str
    role: str
    lane: int
    position_m: float
    speed_mps: float
    length_m: float = 4.8


@dataclass
class CutInRequest:
    requester_id: str
    source_lane: int
    target_lane: int
    merge_duration_s: float = 3.0


@dataclass
class MPCConfig:
    time_step_s: float = 0.2
    prediction_horizon_s: float = 2.5
    maximum_time_s: float = 12.0
    standstill_gap_m: float = 5.0
    time_headway_s: float = 1.0
    acceleration_min_mps2: float = -2.0
    acceleration_max_mps2: float = 1.0
    acceleration_step_mps2: float = 0.5
    reference_speed_mps: float = 24.0
    weight_gap_violation: float = 320.0
    weight_control: float = 0.65
    weight_speed: float = 0.16
    weight_gap_balance: float = 0.035
    required_safe_hold_s: float = 0.6


def _frange(start: float, stop: float, step: float) -> List[float]:
    values = []
    value = start
    while value <= stop + 1e-9:
        values.append(round(value, 8))
        value += step
    return values


def desired_gap(speed_mps: float, config: MPCConfig) -> float:
    """静止间距与速度时距共同形成的纵向安全间隙。"""
    return config.standstill_gap_m + config.time_headway_s * max(0.0, speed_mps)


def predict(state: VehicleState, acceleration: float, horizon_s: float) -> Tuple[float, float]:
    v_next = max(0.0, state.speed_mps + acceleration * horizon_s)
    x_next = state.position_m + state.speed_mps * horizon_s + 0.5 * acceleration * horizon_s ** 2
    return x_next, v_next


def gaps(front: VehicleState, cutin: VehicleState, rear: VehicleState) -> Tuple[float, float]:
    front_gap = front.position_m - cutin.position_m - 0.5 * (front.length_m + cutin.length_m)
    rear_gap = cutin.position_m - rear.position_m - 0.5 * (cutin.length_m + rear.length_m)
    return front_gap, rear_gap


def evaluate_controls(
    front: VehicleState,
    cutin: VehicleState,
    rear: VehicleState,
    controls: Tuple[float, float, float],
    config: MPCConfig,
) -> Tuple[float, Dict[str, float]]:
    """评价预测时域末端的三车协同加速度组合。"""
    a_front, a_cutin, a_rear = controls
    horizon = config.prediction_horizon_s
    xf, vf = predict(front, a_front, horizon)
    xc, vc = predict(cutin, a_cutin, horizon)
    xr, vr = predict(rear, a_rear, horizon)
    mean_length = 0.5 * (front.length_m + cutin.length_m)
    front_gap = xf - xc - mean_length
    rear_gap = xc - xr - 0.5 * (cutin.length_m + rear.length_m)
    desired_front = desired_gap(vc, config)
    desired_rear = desired_gap(vr, config)
    front_violation = max(0.0, desired_front - front_gap)
    rear_violation = max(0.0, desired_rear - rear_gap)

    gap_penalty = config.weight_gap_violation * (front_violation ** 2 + rear_violation ** 2)
    control_penalty = config.weight_control * (a_front ** 2 + a_cutin ** 2 + a_rear ** 2)
    speed_penalty = config.weight_speed * sum(
        (speed - config.reference_speed_mps) ** 2 for speed in (vf, vc, vr)
    )
    balance_penalty = config.weight_gap_balance * (front_gap - rear_gap) ** 2
    score = gap_penalty + control_penalty + speed_penalty + balance_penalty
    return score, {
        "predicted_front_gap_m": front_gap,
        "predicted_rear_gap_m": rear_gap,
        "predicted_front_margin_m": front_gap - desired_front,
        "predicted_rear_margin_m": rear_gap - desired_rear,
    }


def select_controls(
    front: VehicleState, cutin: VehicleState, rear: VehicleState, config: MPCConfig
) -> Tuple[Tuple[float, float, float], Dict[str, float], int]:
    """离散化有界加速度空间，求解单步滚动时域协同控制。"""
    grid = _frange(
        config.acceleration_min_mps2,
        config.acceleration_max_mps2,
        config.acceleration_step_mps2,
    )
    best_controls = (0.0, 0.0, 0.0)
    best_score = math.inf
    best_info: Dict[str, float] = {}
    evaluated = 0
    for controls in itertools.product(grid, repeat=3):
        score, info = evaluate_controls(front, cutin, rear, controls, config)
        evaluated += 1
        if score < best_score:
            best_score = score
            best_controls = controls
            best_info = info
    best_info["objective_value"] = best_score
    return best_controls, best_info, evaluated


def _integrate(state: VehicleState, acceleration: float, dt: float) -> None:
    state.position_m += state.speed_mps * dt + 0.5 * acceleration * dt ** 2
    state.speed_mps = max(0.0, state.speed_mps + acceleration * dt)


def simulate(
    states: Sequence[VehicleState], request: CutInRequest, config: MPCConfig
) -> Tuple[List[Dict[str, float]], Dict[str, object]]:
    role_map = {item.role: VehicleState(**asdict(item)) for item in states}
    required_roles = {"target_front", "cutin", "target_rear"}
    if set(role_map) != required_roles:
        raise ValueError("车辆状态必须且仅包含 target_front、cutin、target_rear 三种角色")
    front = role_map["target_front"]
    cutin = role_map["cutin"]
    rear = role_map["target_rear"]
    if cutin.vehicle_id != request.requester_id:
        raise ValueError("切入请求车辆编号与 cutin 角色车辆不一致")

    dt = config.time_step_s
    safe_hold_steps = max(1, int(math.ceil(config.required_safe_hold_s / dt)))
    safe_counter = 0
    merge_start_time = None
    merge_complete_time = None
    evaluated_total = 0
    history: List[Dict[str, float]] = []

    steps = int(math.ceil(config.maximum_time_s / dt)) + 1
    for step in range(steps):
        time_s = step * dt
        front_gap, rear_gap = gaps(front, cutin, rear)
        desired_front = desired_gap(cutin.speed_mps, config)
        desired_rear = desired_gap(rear.speed_mps, config)
        front_margin = front_gap - desired_front
        rear_margin = rear_gap - desired_rear

        if merge_start_time is None:
            safe_counter = safe_counter + 1 if front_margin >= 0.0 and rear_margin >= 0.0 else 0
            if safe_counter >= safe_hold_steps:
                merge_start_time = time_s - (safe_hold_steps - 1) * dt

        if merge_start_time is not None:
            progress = min(1.0, max(0.0, (time_s - merge_start_time) / request.merge_duration_s))
            smooth_progress = 10 * progress ** 3 - 15 * progress ** 4 + 6 * progress ** 5
            lateral_position_m = 3.5 * (1.0 - smooth_progress)
            if progress >= 1.0 and merge_complete_time is None:
                merge_complete_time = time_s
        else:
            lateral_position_m = 3.5

        controls, prediction, evaluated = select_controls(front, cutin, rear, config)
        evaluated_total += evaluated
        a_front, a_cutin, a_rear = controls
        history.append({
            "time_s": round(time_s, 3),
            "front_position_m": front.position_m,
            "front_speed_mps": front.speed_mps,
            "front_acceleration_mps2": a_front,
            "cutin_position_m": cutin.position_m,
            "cutin_speed_mps": cutin.speed_mps,
            "cutin_acceleration_mps2": a_cutin,
            "cutin_lateral_position_m": lateral_position_m,
            "rear_position_m": rear.position_m,
            "rear_speed_mps": rear.speed_mps,
            "rear_acceleration_mps2": a_rear,
            "front_gap_m": front_gap,
            "rear_gap_m": rear_gap,
            "desired_front_gap_m": desired_front,
            "desired_rear_gap_m": desired_rear,
            "front_margin_m": front_margin,
            "rear_margin_m": rear_margin,
            "objective_value": prediction["objective_value"],
        })

        if merge_complete_time is not None:
            break
        _integrate(front, a_front, dt)
        _integrate(cutin, a_cutin, dt)
        _integrate(rear, a_rear, dt)

    min_front_margin = min(row["front_margin_m"] for row in history)
    min_rear_margin = min(row["rear_margin_m"] for row in history)
    completed_rows = [row for row in history if merge_start_time is not None and row["time_s"] >= merge_start_time]
    min_merge_front_margin = min(row["front_margin_m"] for row in completed_rows) if completed_rows else min_front_margin
    min_merge_rear_margin = min(row["rear_margin_m"] for row in completed_rows) if completed_rows else min_rear_margin
    peak_deceleration = min(
        min(row["front_acceleration_mps2"], row["cutin_acceleration_mps2"], row["rear_acceleration_mps2"])
        for row in history
    )
    metrics = {
        "model": "基于协同预测控制的三车切入间隙重构模型",
        "requester_id": request.requester_id,
        "merge_started": merge_start_time is not None,
        "merge_completed": merge_complete_time is not None,
        "merge_start_time_s": None if merge_start_time is None else round(merge_start_time, 2),
        "merge_complete_time_s": None if merge_complete_time is None else round(merge_complete_time, 2),
        "minimum_front_margin_during_merge_m": round(min_merge_front_margin, 3),
        "minimum_rear_margin_during_merge_m": round(min_merge_rear_margin, 3),
        "peak_deceleration_mps2": round(peak_deceleration, 3),
        "control_combinations_per_step": int((
            (config.acceleration_max_mps2 - config.acceleration_min_mps2)
            / config.acceleration_step_mps2 + 1
        ) ** 3),
        "evaluated_control_combinations": evaluated_total,
        "simulation_steps": len(history),
    }
    return history, metrics


def write_outputs(history: List[Dict[str, float]], metrics: Dict[str, object], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "cooperative_trajectory.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(history[0]))
        writer.writeheader()
        writer.writerows(history)
    (output_dir / "control_metrics.json").write_text(
        json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    draw_gap_evolution(history, metrics, output_dir / "safety_gap_evolution.png")
    draw_vehicle_trajectories(history, metrics, output_dir / "vehicle_trajectories.png")
    draw_algorithm_flow(output_dir / "algorithm_flow.png")


def _pillow_components():
    from PIL import Image, ImageDraw, ImageFont
    return Image, ImageDraw, ImageFont


def _font(size: int, bold: bool = False):
    _, _, image_font = _pillow_components()
    candidates = [
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/System/Library/Fonts/STHeiti Medium.ttc" if bold else "/System/Library/Fonts/STHeiti Light.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            try:
                return image_font.truetype(candidate, size, index=0)
            except OSError:
                continue
    return image_font.load_default()


def _polyline(draw, points, color, width=4, dashed=False):
    if not dashed:
        draw.line(points, fill=color, width=width, joint="curve")
        return
    for start, end in zip(points, points[1:]):
        x1, y1 = start
        x2, y2 = end
        distance = math.hypot(x2 - x1, y2 - y1)
        if distance <= 0:
            continue
        ux, uy = (x2 - x1) / distance, (y2 - y1) / distance
        cursor = 0.0
        while cursor < distance:
            seg_end = min(distance, cursor + 11)
            draw.line((x1 + ux * cursor, y1 + uy * cursor, x1 + ux * seg_end, y1 + uy * seg_end), fill=color, width=width)
            cursor += 20


def _draw_chart(
    path: Path,
    title: str,
    x_values: List[float],
    series: List[Tuple[str, List[float], str, bool]],
    y_label: str,
    verticals: List[Tuple[str, float, str]] | None = None,
    size: Tuple[int, int] = (1600, 900),
) -> None:
    image_cls, image_draw, _ = _pillow_components()
    image = image_cls.new("RGB", size, "white")
    draw = image_draw.Draw(image)
    title_font, label_font, tick_font = _font(42, True), _font(27), _font(22)
    left, top, right, bottom = 150, 125, size[0] - 75, size[1] - 145
    all_y = [value for _, values, _, _ in series for value in values]
    y_min, y_max = min(all_y), max(all_y)
    span = max(1.0, y_max - y_min)
    y_min -= 0.08 * span
    y_max += 0.08 * span
    x_min, x_max = min(x_values), max(x_values)

    def sx(value):
        return left + (value - x_min) / max(1e-9, x_max - x_min) * (right - left)

    def sy(value):
        return bottom - (value - y_min) / max(1e-9, y_max - y_min) * (bottom - top)

    draw.text((size[0] / 2, 45), title, font=title_font, fill="#1F1F1F", anchor="mm")
    for i in range(6):
        value = y_min + (y_max - y_min) * i / 5
        y = sy(value)
        draw.line((left, y, right, y), fill="#E0E0E0", width=2)
        draw.text((left - 18, y), f"{value:.1f}", font=tick_font, fill="#505050", anchor="rm")
    for i in range(6):
        value = x_min + (x_max - x_min) * i / 5
        x = sx(value)
        draw.line((x, top, x, bottom), fill="#EEEEEE", width=2)
        draw.text((x, bottom + 18), f"{value:.1f}", font=tick_font, fill="#505050", anchor="ma")
    draw.line((left, top, left, bottom), fill="#333333", width=3)
    draw.line((left, bottom, right, bottom), fill="#333333", width=3)
    for _, values, color, dashed in series:
        _polyline(draw, [(sx(x), sy(y)) for x, y in zip(x_values, values)], color, 5 if not dashed else 3, dashed)
    if verticals:
        for _, value, color in verticals:
            x = sx(value)
            draw.line((x, top, x, bottom), fill=color, width=3)
    legend_x, legend_y = left + 10, size[1] - 83
    legend_entries = [(name, color, dashed) for name, _, color, dashed in series]
    if verticals:
        legend_entries += [(name, color, False) for name, _, color in verticals]
    for index, (name, color, dashed) in enumerate(legend_entries):
        col, row = index % 3, index // 3
        x, y = legend_x + col * 440, legend_y + row * 40
        _polyline(draw, [(x, y), (x + 52, y)], color, 4, dashed)
        draw.text((x + 65, y), name, font=tick_font, fill="#303030", anchor="lm")
    draw.text(((left + right) / 2, size[1] - 112), "时间 / s", font=label_font, fill="#303030", anchor="mm")
    draw.text((left + 14, top + 12), y_label, font=label_font, fill="#303030", anchor="la")
    image.save(path)


def draw_gap_evolution(history: List[Dict[str, float]], metrics: Dict[str, object], path: Path) -> None:
    t = [row["time_s"] for row in history]
    verticals = []
    if metrics["merge_start_time_s"] is not None:
        verticals.append(("切入开始", float(metrics["merge_start_time_s"]), "#70AD47"))
    if metrics["merge_complete_time_s"] is not None:
        verticals.append(("切入完成", float(metrics["merge_complete_time_s"]), "#A5A5A5"))
    _draw_chart(
        path,
        "三车协同切入过程安全间隙演化",
        t,
        [
            ("切入车-前车实际间隙", [row["front_gap_m"] for row in history], "#4472C4", False),
            ("前向安全间隙", [row["desired_front_gap_m"] for row in history], "#4472C4", True),
            ("后车-切入车实际间隙", [row["rear_gap_m"] for row in history], "#ED7D31", False),
            ("后向安全间隙", [row["desired_rear_gap_m"] for row in history], "#ED7D31", True),
        ],
        "纵向间隙 / m",
        verticals,
    )


def draw_vehicle_trajectories(history: List[Dict[str, float]], metrics: Dict[str, object], path: Path) -> None:
    image_cls, image_draw, _ = _pillow_components()
    image = image_cls.new("RGB", (1600, 1080), "white")
    temp_position = path.with_name("_position_panel.png")
    temp_speed = path.with_name("_speed_panel.png")
    t = [row["time_s"] for row in history]
    _draw_chart(temp_position, "三车纵向轨迹", t, [
        ("目标车道前车", [row["front_position_m"] for row in history], "#4472C4", False),
        ("切入车", [row["cutin_position_m"] for row in history], "#ED7D31", False),
        ("目标车道后车", [row["rear_position_m"] for row in history], "#70AD47", False),
    ], "纵向位置 / m", size=(1600, 530))
    _draw_chart(temp_speed, "三车速度响应", t, [
        ("目标车道前车", [row["front_speed_mps"] for row in history], "#4472C4", False),
        ("切入车", [row["cutin_speed_mps"] for row in history], "#ED7D31", False),
        ("目标车道后车", [row["rear_speed_mps"] for row in history], "#70AD47", False),
    ], "速度 / (m/s)", size=(1600, 530))
    upper = image_cls.open(temp_position)
    lower = image_cls.open(temp_speed)
    image.paste(upper, (0, 0))
    image.paste(lower, (0, 550))
    image.save(path)
    temp_position.unlink()
    temp_speed.unlink()


def draw_algorithm_flow(path: Path) -> None:
    image_cls, image_draw, _ = _pillow_components()
    image = image_cls.new("RGB", (1500, 1180), "white")
    draw = image_draw.Draw(image)
    title_font, node_font = _font(44, True), _font(30)
    draw.text((750, 55), "三车切入间隙协同预测控制流程", font=title_font, fill="#1F1F1F", anchor="mm")
    labels = [
        "读取三车状态、切入请求与控制配置",
        "计算前后实际间隙及速度相关安全阈值",
        "枚举有界三车纵向加速度组合",
        "预测时域末端状态并计算间隙、舒适性与效率代价",
        "执行最优控制首步并滚动更新三车状态",
        "安全间隙连续保持后生成五次多项式切入轨迹",
        "输出控制指标、轨迹数据和运行结果图",
    ]
    y_positions = [150, 300, 450, 600, 750, 900, 1050]
    for y, label in zip(y_positions, labels):
        draw.rounded_rectangle((280, y - 52, 1220, y + 52), radius=22, fill="#DCE6F1", outline="#4F81BD", width=4)
        draw.text((750, y), label, font=node_font, fill="#1F1F1F", anchor="mm")
    for y1, y2 in zip(y_positions, y_positions[1:]):
        draw.line((750, y1 + 54, 750, y2 - 56), fill="#4F81BD", width=5)
        draw.polygon([(750, y2 - 45), (735, y2 - 67), (765, y2 - 67)], fill="#4F81BD")
    image.save(path)


def demo_inputs() -> Tuple[List[VehicleState], CutInRequest, MPCConfig]:
    states = [
        VehicleState("CAV-F", "target_front", 2, 60.0, 23.0),
        VehicleState("CAV-C", "cutin", 1, 31.0, 22.0),
        VehicleState("CAV-R", "target_rear", 2, 0.0, 25.0),
    ]
    request = CutInRequest("CAV-C", source_lane=1, target_lane=2, merge_duration_s=3.0)
    return states, request, MPCConfig()


def load_inputs(state_path: Path, request_path: Path, config_path: Path) -> Tuple[List[VehicleState], CutInRequest, MPCConfig]:
    state_data = json.loads(state_path.read_text(encoding="utf-8"))
    request_data = json.loads(request_path.read_text(encoding="utf-8"))
    config_data = json.loads(config_path.read_text(encoding="utf-8"))
    return [VehicleState(**item) for item in state_data], CutInRequest(**request_data), MPCConfig(**config_data)


def main() -> None:
    parser = argparse.ArgumentParser(description="三车切入间隙协同预测控制")
    parser.add_argument("--state", type=Path, help="vehicle_states.json")
    parser.add_argument("--request", type=Path, help="cutin_request.json")
    parser.add_argument("--config", type=Path, help="mpc_config.json")
    parser.add_argument("--output-dir", type=Path, default=Path("data/output"))
    parser.add_argument("--demo", action="store_true", help="运行内置三车切入测试场景")
    args = parser.parse_args()
    if args.demo:
        states, request, config = demo_inputs()
    elif args.state and args.request and args.config:
        states, request, config = load_inputs(args.state, args.request, args.config)
    else:
        parser.error("请使用 --demo，或同时提供 --state、--request 和 --config")
    history, metrics = simulate(states, request, config)
    write_outputs(history, metrics, args.output_dir)
    print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
