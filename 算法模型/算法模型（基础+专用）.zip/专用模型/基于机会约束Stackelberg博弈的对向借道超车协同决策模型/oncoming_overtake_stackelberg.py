#!/usr/bin/env python3
"""基于机会约束Stackelberg博弈的对向借道超车协同决策模型。

适用场景：正常双向两车道道路中，自车受前方慢车约束并提出借用对向车道
超车请求。模型预测慢车和对向来车的最优响应，利用机会约束筛选安全超车
时窗，并生成驶出、超越和返回本车道的连续轨迹。

运行示例：
    python oncoming_overtake_stackelberg.py --demo --output-dir data/output
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


@dataclass
class VehicleState:
    vehicle_id: str
    role: str
    lane: int
    direction: int
    position_m: float
    speed_mps: float
    length_m: float = 4.8


@dataclass
class OvertakeRequest:
    ego_id: str
    source_lane: int = 0
    opposing_lane: int = 1
    desired_speed_mps: float = 24.0


@dataclass
class Config:
    time_step_s: float = 0.1
    decision_horizon_s: float = 8.0
    simulation_time_s: float = 8.0
    lane_width_m: float = 3.5
    lane_transition_time_s: float = 1.2
    minimum_opposing_hold_s: float = 0.4
    standstill_gap_m: float = 4.0
    return_time_headway_s: float = 0.8
    maximum_ego_speed_mps: float = 28.0
    opposing_base_gap_m: float = 8.0
    opposing_closing_time_s: float = 0.22
    initial_position_sigma_m: float = 1.2
    relative_speed_sigma_mps: float = 0.35
    chance_confidence: float = 0.99
    maximum_collision_probability: float = 0.01
    completion_weight: float = 3.0
    ego_control_weight: float = 0.6
    response_weight: float = 0.8
    uncertainty_margin_weight: float = 5.0
    wait_cost: float = 42.0


def smoothstep5(progress: float) -> float:
    s = min(1.0, max(0.0, progress))
    return 10.0 * s ** 3 - 15.0 * s ** 4 + 6.0 * s ** 5


def position_at(state: VehicleState, acceleration: float, time_s: float) -> float:
    return state.position_m + state.direction * (
        state.speed_mps * time_s + 0.5 * acceleration * time_s * time_s
    )


def speed_at(state: VehicleState, acceleration: float, time_s: float) -> float:
    return max(0.0, state.speed_mps + acceleration * time_s)


def ego_plan_position(state: VehicleState, acceleration: float, start_delay_s: float, time_s: float, maximum_speed_mps: float) -> float:
    """自车在超车启动前保持当前速度，启动后施加候选加速度。"""
    active_time = max(0.0, time_s - start_delay_s)
    if acceleration <= 0.0 or state.speed_mps >= maximum_speed_mps:
        extra_distance = 0.5 * acceleration * active_time * active_time
    else:
        time_to_cap = (maximum_speed_mps - state.speed_mps) / acceleration
        accelerating_time = min(active_time, time_to_cap)
        capped_time = max(0.0, active_time - time_to_cap)
        extra_distance = (
            0.5 * acceleration * accelerating_time * accelerating_time
            + (maximum_speed_mps - state.speed_mps) * capped_time
        )
    return state.position_m + state.speed_mps * time_s + extra_distance


def ego_plan_speed(state: VehicleState, acceleration: float, start_delay_s: float, time_s: float, maximum_speed_mps: float) -> float:
    active_time = max(0.0, time_s - start_delay_s)
    return min(maximum_speed_mps, max(0.0, state.speed_mps + acceleration * active_time))


def relative_sigma(config: Config, time_s: float) -> float:
    return math.sqrt(
        config.initial_position_sigma_m ** 2
        + (config.relative_speed_sigma_mps * time_s) ** 2
    )


def inverse_standard_normal(probability: float) -> float:
    """Acklam有理逼近，避免依赖SciPy。"""
    if not 0.0 < probability < 1.0:
        raise ValueError("概率必须位于(0,1)")
    a = (-39.6968302866538, 220.946098424521, -275.928510446969, 138.357751867269, -30.6647980661472, 2.50662827745924)
    b = (-54.4760987982241, 161.585836858041, -155.698979859887, 66.8013118877197, -13.2806815528857)
    c = (-0.00778489400243029, -0.322396458041136, -2.40075827716184, -2.54973253934373, 4.37466414146497, 2.93816398269878)
    d = (0.00778469570904146, 0.32246712907004, 2.445134137143, 3.75440866190742)
    low, high = 0.02425, 0.97575
    if probability < low:
        q = math.sqrt(-2.0 * math.log(probability))
        return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    if probability > high:
        q = math.sqrt(-2.0 * math.log(1.0-probability))
        return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    q = probability - 0.5
    r = q*q
    return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q / (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)


def normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))


def determine_return_time(
    ego: VehicleState,
    leader: VehicleState,
    start_delay_s: float,
    ego_acceleration: float,
    leader_acceleration: float,
    config: Config,
) -> float | None:
    earliest = start_delay_s + config.lane_transition_time_s + config.minimum_opposing_hold_s
    steps = int(config.decision_horizon_s / config.time_step_s) + 1
    for step in range(steps):
        time_s = step * config.time_step_s
        if time_s + 1e-9 < earliest:
            continue
        ego_x = ego_plan_position(ego, ego_acceleration, start_delay_s, time_s, config.maximum_ego_speed_mps)
        leader_x = position_at(leader, leader_acceleration, time_s)
        leader_v = speed_at(leader, leader_acceleration, time_s)
        return_gap = config.standstill_gap_m + config.return_time_headway_s * leader_v
        net_lead = ego_x - leader_x - 0.5 * (ego.length_m + leader.length_m)
        if net_lead >= return_gap:
            return time_s
    return None


def evaluate_plan(
    ego: VehicleState,
    leader: VehicleState,
    oncoming: VehicleState,
    start_delay_s: float,
    ego_acceleration: float,
    leader_acceleration: float,
    oncoming_acceleration: float,
    config: Config,
) -> Dict[str, float | bool]:
    return_start = determine_return_time(
        ego, leader, start_delay_s, ego_acceleration, leader_acceleration, config
    )
    if return_start is None:
        return {
            "feasible": False,
            "return_start_time_s": config.decision_horizon_s,
            "completion_time_s": config.decision_horizon_s + config.lane_transition_time_s,
            "minimum_robust_opposing_margin_m": -999.0,
            "maximum_collision_probability": 1.0,
            "return_gap_margin_m": -999.0,
        }
    completion = return_start + config.lane_transition_time_s
    if completion > config.decision_horizon_s + 1e-9:
        return {
            "feasible": False,
            "return_start_time_s": return_start,
            "completion_time_s": completion,
            "minimum_robust_opposing_margin_m": -999.0,
            "maximum_collision_probability": 1.0,
            "return_gap_margin_m": -999.0,
        }

    z_value = inverse_standard_normal(config.chance_confidence)
    minimum_robust_margin = math.inf
    maximum_probability = 0.0
    # 车辆中心越过半幅车道后视为进入对向车道，返回越过半幅后解除对向冲突。
    conflict_start = start_delay_s + 0.5 * config.lane_transition_time_s
    conflict_end = return_start + 0.5 * config.lane_transition_time_s
    steps = int(config.decision_horizon_s / config.time_step_s) + 1
    for step in range(steps):
        time_s = step * config.time_step_s
        if time_s < conflict_start - 1e-9 or time_s > conflict_end + 1e-9:
            continue
        ego_x = ego_plan_position(ego, ego_acceleration, start_delay_s, time_s, config.maximum_ego_speed_mps)
        oncoming_x = position_at(oncoming, oncoming_acceleration, time_s)
        ego_v = ego_plan_speed(ego, ego_acceleration, start_delay_s, time_s, config.maximum_ego_speed_mps)
        oncoming_v = speed_at(oncoming, oncoming_acceleration, time_s)
        center_separation = oncoming_x - ego_x
        net_separation = center_separation - 0.5 * (ego.length_m + oncoming.length_m)
        required = config.opposing_base_gap_m + config.opposing_closing_time_s * (ego_v + oncoming_v)
        sigma = relative_sigma(config, time_s)
        deterministic_margin = net_separation - required
        robust_margin = deterministic_margin - z_value * sigma
        collision_probability = 1.0 - normal_cdf(deterministic_margin / sigma)
        minimum_robust_margin = min(minimum_robust_margin, robust_margin)
        maximum_probability = max(maximum_probability, collision_probability)

    ego_x = ego_plan_position(ego, ego_acceleration, start_delay_s, completion, config.maximum_ego_speed_mps)
    leader_x = position_at(leader, leader_acceleration, completion)
    leader_v = speed_at(leader, leader_acceleration, completion)
    actual_return_gap = ego_x - leader_x - 0.5 * (ego.length_m + leader.length_m)
    required_return_gap = config.standstill_gap_m + config.return_time_headway_s * leader_v
    return_margin = actual_return_gap - required_return_gap
    feasible = (
        minimum_robust_margin >= 0.0
        and maximum_probability <= config.maximum_collision_probability
        and return_margin >= 0.0
    )
    return {
        "feasible": feasible,
        "return_start_time_s": return_start,
        "completion_time_s": completion,
        "minimum_robust_opposing_margin_m": minimum_robust_margin,
        "maximum_collision_probability": maximum_probability,
        "return_gap_margin_m": return_margin,
    }


def follower_best_response(
    ego: VehicleState,
    leader: VehicleState,
    oncoming: VehicleState,
    start_delay_s: float,
    ego_acceleration: float,
    config: Config,
) -> Dict[str, float | bool]:
    """慢车和对向来车作为跟随者，对自车超车策略作安全—舒适最优响应。"""
    leader_actions = (0.0, -0.4, -0.8)
    oncoming_actions = (0.0, -0.5, -1.0, -1.5)
    best = None
    for leader_acceleration in leader_actions:
        for oncoming_acceleration in oncoming_actions:
            outcome = evaluate_plan(
                ego, leader, oncoming, start_delay_s, ego_acceleration,
                leader_acceleration, oncoming_acceleration, config
            )
            violation = max(0.0, -float(outcome["minimum_robust_opposing_margin_m"]))
            return_violation = max(0.0, -float(outcome["return_gap_margin_m"]))
            response_cost = (
                config.response_weight * (leader_acceleration ** 2 + oncoming_acceleration ** 2)
                + 2500.0 * violation ** 2
                + 2500.0 * return_violation ** 2
                + (0.0 if outcome["feasible"] else 25000.0)
            )
            candidate = {
                **outcome,
                "leader_acceleration_mps2": leader_acceleration,
                "oncoming_acceleration_mps2": oncoming_acceleration,
                "follower_response_cost": response_cost,
            }
            if best is None or response_cost < float(best["follower_response_cost"]):
                best = candidate
    assert best is not None
    return best


def solve_stackelberg_game(
    states: Dict[str, VehicleState], request: OvertakeRequest, config: Config
) -> Tuple[List[Dict[str, float | str | bool]], Dict[str, float | str | bool]]:
    ego, leader, oncoming = states["ego"], states["slow_leader"], states["oncoming"]
    evaluations: List[Dict[str, float | str | bool]] = []
    for start_delay in (0.0, 0.5, 1.0, 1.5):
        for ego_acceleration in (1.5, 2.0, 2.5):
            response = follower_best_response(
                ego, leader, oncoming, start_delay, ego_acceleration, config
            )
            robust_margin = float(response["minimum_robust_opposing_margin_m"])
            margin_cost = config.uncertainty_margin_weight / max(1.0, robust_margin + 1.0)
            leader_a = float(response["leader_acceleration_mps2"])
            oncoming_a = float(response["oncoming_acceleration_mps2"])
            objective = (
                config.completion_weight * float(response["completion_time_s"])
                + config.ego_control_weight * ego_acceleration ** 2
                + config.response_weight * (leader_a ** 2 + oncoming_a ** 2)
                + margin_cost
            )
            evaluations.append({
                "plan": f"overtake_d{start_delay:.1f}_a{ego_acceleration:.1f}",
                "start_delay_s": start_delay,
                "ego_acceleration_mps2": ego_acceleration,
                **response,
                "objective_value": objective,
            })
    feasible = [row for row in evaluations if bool(row["feasible"])]
    wait_plan: Dict[str, float | str | bool] = {
        "plan": "wait_follow",
        "start_delay_s": -1.0,
        "ego_acceleration_mps2": 0.0,
        "leader_acceleration_mps2": 0.0,
        "oncoming_acceleration_mps2": 0.0,
        "return_start_time_s": -1.0,
        "completion_time_s": -1.0,
        "minimum_robust_opposing_margin_m": 999.0,
        "maximum_collision_probability": 0.0,
        "return_gap_margin_m": 0.0,
        "follower_response_cost": 0.0,
        "feasible": True,
        "objective_value": config.wait_cost,
    }
    evaluations.append(wait_plan)
    selected = min(feasible + [wait_plan], key=lambda row: float(row["objective_value"]))
    for row in evaluations:
        row["selected"] = "是" if row is selected else "否"
    return evaluations, selected


def lateral_position(time_s: float, selected: Dict[str, float | str | bool], config: Config) -> float:
    if selected["plan"] == "wait_follow":
        return 0.0
    start = float(selected["start_delay_s"])
    return_start = float(selected["return_start_time_s"])
    transition = config.lane_transition_time_s
    if time_s <= start:
        return 0.0
    if time_s < start + transition:
        return config.lane_width_m * smoothstep5((time_s - start) / transition)
    if time_s <= return_start:
        return config.lane_width_m
    if time_s < return_start + transition:
        return config.lane_width_m * (1.0 - smoothstep5((time_s - return_start) / transition))
    return 0.0


def simulate_selected(
    states: Dict[str, VehicleState], selected: Dict[str, float | str | bool], config: Config
) -> List[Dict[str, float]]:
    ego, leader, oncoming = states["ego"], states["slow_leader"], states["oncoming"]
    ego_a = float(selected["ego_acceleration_mps2"])
    start_delay = max(0.0, float(selected["start_delay_s"]))
    leader_a = float(selected["leader_acceleration_mps2"])
    oncoming_a = float(selected["oncoming_acceleration_mps2"])
    z_value = inverse_standard_normal(config.chance_confidence)
    history = []
    steps = int(config.simulation_time_s / config.time_step_s) + 1
    for step in range(steps):
        time_s = step * config.time_step_s
        ego_x = ego_plan_position(ego, ego_a, start_delay, time_s, config.maximum_ego_speed_mps)
        leader_x = position_at(leader, leader_a, time_s)
        oncoming_x = position_at(oncoming, oncoming_a, time_s)
        ego_v = ego_plan_speed(ego, ego_a, start_delay, time_s, config.maximum_ego_speed_mps)
        leader_v = speed_at(leader, leader_a, time_s)
        oncoming_v = speed_at(oncoming, oncoming_a, time_s)
        y = lateral_position(time_s, selected, config)
        net_opposing = oncoming_x - ego_x - 0.5 * (ego.length_m + oncoming.length_m)
        required_opposing = config.opposing_base_gap_m + config.opposing_closing_time_s * (ego_v + oncoming_v)
        sigma = relative_sigma(config, time_s)
        robust_margin = net_opposing - required_opposing - z_value * sigma
        return_gap = ego_x - leader_x - 0.5 * (ego.length_m + leader.length_m)
        required_return_gap = config.standstill_gap_m + config.return_time_headway_s * leader_v
        history.append({
            "time_s": round(time_s, 3),
            "ego_position_m": ego_x,
            "ego_speed_mps": ego_v,
            "ego_lateral_position_m": y,
            "leader_position_m": leader_x,
            "leader_speed_mps": leader_v,
            "oncoming_position_m": oncoming_x,
            "oncoming_speed_mps": oncoming_v,
            "opposing_net_separation_m": net_opposing,
            "robust_opposing_margin_m": robust_margin,
            "return_gap_m": return_gap,
            "return_gap_margin_m": return_gap - required_return_gap,
        })
    return history


def summarize(evaluations, selected, history, config: Config) -> Dict[str, object]:
    feasible_overtakes = [row for row in evaluations if row["plan"] != "wait_follow" and row["feasible"]]
    return {
        "model": "基于机会约束Stackelberg博弈的对向借道超车协同决策模型",
        "selected_plan": selected["plan"],
        "overtake_authorized": selected["plan"] != "wait_follow",
        "start_delay_s": round(float(selected["start_delay_s"]), 2),
        "return_start_time_s": round(float(selected["return_start_time_s"]), 2),
        "completion_time_s": round(float(selected["completion_time_s"]), 2),
        "ego_acceleration_mps2": round(float(selected["ego_acceleration_mps2"]), 2),
        "leader_response_acceleration_mps2": round(float(selected["leader_acceleration_mps2"]), 2),
        "oncoming_response_acceleration_mps2": round(float(selected["oncoming_acceleration_mps2"]), 2),
        "minimum_robust_opposing_margin_m": round(float(selected["minimum_robust_opposing_margin_m"]), 3),
        "maximum_collision_probability": round(float(selected["maximum_collision_probability"]), 6),
        "return_gap_margin_m": round(float(selected["return_gap_margin_m"]), 3),
        "feasible_overtaking_plans": len(feasible_overtakes),
        "evaluated_overtaking_plans": len(evaluations) - 1,
        "chance_confidence": config.chance_confidence,
        "simulation_steps": len(history),
    }


def write_csv(path: Path, rows: Iterable[Dict[str, object]]) -> None:
    rows = list(rows)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _pillow_components():
    from PIL import Image, ImageDraw, ImageFont
    return Image, ImageDraw, ImageFont


def _font(size: int, bold: bool = False):
    _, _, image_font = _pillow_components()
    candidates = [
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/System/Library/Fonts/STHeiti Medium.ttc" if bold else "/System/Library/Fonts/STHeiti Light.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            try:
                return image_font.truetype(candidate, size, index=0)
            except OSError:
                pass
    return image_font.load_default()


def _polyline(draw, points, color, width=4, dashed=False):
    if not dashed:
        draw.line(points, fill=color, width=width, joint="curve")
        return
    for start, end in zip(points, points[1:]):
        x1, y1 = start
        x2, y2 = end
        distance = math.hypot(x2-x1, y2-y1)
        if distance <= 0:
            continue
        ux, uy = (x2-x1)/distance, (y2-y1)/distance
        cursor = 0.0
        while cursor < distance:
            finish = min(distance, cursor+10)
            draw.line((x1+ux*cursor, y1+uy*cursor, x1+ux*finish, y1+uy*finish), fill=color, width=width)
            cursor += 18


def _line_chart(path: Path, title: str, times: List[float], series, y_label: str, size=(1600, 760)):
    image_cls, image_draw, _ = _pillow_components()
    image = image_cls.new("RGB", size, "white")
    draw = image_draw.Draw(image)
    title_font, label_font, tick_font = _font(40, True), _font(25), _font(20)
    left, top, right, bottom = 145, 105, size[0]-70, size[1]-130
    values = [v for _, items, _, _ in series for v in items]
    y_min, y_max = min(values), max(values)
    span = max(1.0, y_max-y_min)
    y_min -= 0.08*span
    y_max += 0.08*span
    x_min, x_max = min(times), max(times)
    sx = lambda v: left + (v-x_min)/max(1e-9, x_max-x_min)*(right-left)
    sy = lambda v: bottom - (v-y_min)/max(1e-9, y_max-y_min)*(bottom-top)
    draw.text((size[0]/2, 40), title, font=title_font, fill="#1F1F1F", anchor="mm")
    for i in range(6):
        value = y_min + (y_max-y_min)*i/5
        y = sy(value)
        draw.line((left,y,right,y), fill="#E2E2E2", width=2)
        draw.text((left-15,y), f"{value:.1f}", font=tick_font, fill="#505050", anchor="rm")
    for i in range(6):
        value = x_min + (x_max-x_min)*i/5
        x = sx(value)
        draw.line((x,top,x,bottom), fill="#EEEEEE", width=2)
        draw.text((x,bottom+18), f"{value:.1f}", font=tick_font, fill="#505050", anchor="ma")
    draw.line((left,top,left,bottom), fill="#333333", width=3)
    draw.line((left,bottom,right,bottom), fill="#333333", width=3)
    for _, items, color, dashed in series:
        _polyline(draw, [(sx(t),sy(v)) for t,v in zip(times,items)], color, 5 if not dashed else 3, dashed)
    for i,(label,_,color,dashed) in enumerate(series):
        x = left+10+(i%3)*420
        y = size[1]-70+(i//3)*32
        _polyline(draw, [(x,y),(x+48,y)], color, 4, dashed)
        draw.text((x+60,y), label, font=tick_font, fill="#303030", anchor="lm")
    draw.text(((left+right)/2,size[1]-102), "时间 / s", font=label_font, fill="#303030", anchor="mm")
    draw.text((left+12,top+10), y_label, font=label_font, fill="#303030", anchor="la")
    image.save(path)


def draw_plan_evaluation(evaluations, selected, path: Path) -> None:
    image_cls, image_draw, _ = _pillow_components()
    plans = [row for row in evaluations if row["plan"] != "wait_follow"]
    lookup = {
        (float(row["start_delay_s"]), float(row["ego_acceleration_mps2"])): row
        for row in plans
    }
    delays = (0.0, 0.5, 1.0, 1.5)
    accelerations = (1.5, 2.0, 2.5)
    image = image_cls.new("RGB", (1700, 940), "white")
    draw = image_draw.Draw(image)
    title_font = _font(40, True)
    panel_font = _font(29, True)
    axis_font = _font(24)
    cell_font = _font(25, True)
    small_font = _font(20)
    draw.text((850, 48), "候选超车策略的机会约束与博弈代价评价", font=title_font, fill="#1F1F1F", anchor="mm")

    def rgb(hex_color):
        value = hex_color.lstrip("#")
        return tuple(int(value[i:i+2], 16) for i in (0, 2, 4))

    def mix(first, second, ratio):
        ratio = max(0.0, min(1.0, ratio))
        a, b = rgb(first), rgb(second)
        return tuple(round(a[i] + (b[i] - a[i]) * ratio) for i in range(3))

    margin_values = [float(row["minimum_robust_opposing_margin_m"]) for row in plans]
    cost_values = [float(row["objective_value"]) for row in plans]
    margin_limit = max(abs(min(margin_values)), abs(max(margin_values)))
    cost_min, cost_max = min(cost_values), max(cost_values)
    panel_specs = [
        (180, "(a) 最小鲁棒对向安全裕度  h_min / m", "margin"),
        (980, "(b) Stackelberg社会代价  J", "cost"),
    ]
    cell_w, cell_h = 180, 116
    grid_top = 190

    for panel_left, panel_title, kind in panel_specs:
        draw.text((panel_left + 1.5 * cell_w, 125), panel_title, font=panel_font, fill="#202020", anchor="mm")
        for column, acceleration in enumerate(accelerations):
            x = panel_left + column * cell_w + cell_w / 2
            draw.text((x, grid_top - 18), f"{acceleration:.1f}", font=axis_font, fill="#303030", anchor="ms")
        for row_index, delay in enumerate(delays):
            y = grid_top + row_index * cell_h + cell_h / 2
            draw.text((panel_left - 20, y), f"{delay:.1f}", font=axis_font, fill="#303030", anchor="rm")
            for column, acceleration in enumerate(accelerations):
                row = lookup[(delay, acceleration)]
                x0 = panel_left + column * cell_w
                y0 = grid_top + row_index * cell_h
                if kind == "margin":
                    value = float(row["minimum_robust_opposing_margin_m"])
                    if value >= 0:
                        fill = mix("#F7F7F7", "#2166AC", value / max(1e-9, margin_limit))
                    else:
                        fill = mix("#F7F7F7", "#B2182B", abs(value) / max(1e-9, margin_limit))
                    label = f"{value:.2f}"
                else:
                    value = float(row["objective_value"])
                    ratio = (value - cost_min) / max(1e-9, cost_max - cost_min)
                    fill = mix("#E8F1F8", "#2166AC", ratio)
                    label = f"{value:.2f}"
                draw.rectangle((x0, y0, x0 + cell_w, y0 + cell_h), fill=fill, outline="#FFFFFF", width=3)
                luminance = 0.299 * fill[0] + 0.587 * fill[1] + 0.114 * fill[2]
                text_color = "#FFFFFF" if luminance < 135 else "#202020"
                draw.text((x0 + cell_w / 2, y0 + cell_h / 2 - 5), label, font=cell_font, fill=text_color, anchor="mm")
                feasible = str(row["feasible"]).lower() == "true"
                status_color = "#1B7837" if feasible else "#7F0000"
                status = "●" if feasible else "×"
                draw.text((x0 + 15, y0 + 13), status, font=small_font, fill=status_color, anchor="la")
                if row["plan"] == selected["plan"]:
                    draw.rectangle((x0 + 3, y0 + 3, x0 + cell_w - 3, y0 + cell_h - 3), outline="#F4A300", width=7)
                    draw.text((x0 + cell_w - 13, y0 + 12), "★", font=small_font, fill="#F4A300", anchor="ra")
        draw.text((panel_left + 1.5 * cell_w, grid_top + 4 * cell_h + 48), "自车加速度  a_E / (m·s^-2)", font=axis_font, fill="#303030", anchor="mm")
        draw.text((panel_left - 82, grid_top + 2 * cell_h), "启动延迟 / s", font=axis_font, fill="#303030", anchor="mm")

    # 水平色标：左侧为以零为中心的发散色标，右侧为社会代价顺序色标。
    bar_y, bar_h = 760, 22
    for index in range(300):
        value = -margin_limit + 2 * margin_limit * index / 299
        fill = mix("#F7F7F7", "#2166AC", value / margin_limit) if value >= 0 else mix("#F7F7F7", "#B2182B", abs(value) / margin_limit)
        draw.rectangle((260 + index, bar_y, 261 + index, bar_y + bar_h), fill=fill)
    draw.text((260, bar_y + 31), f"{ -margin_limit:.1f}", font=small_font, fill="#303030", anchor="ma")
    draw.text((410, bar_y + 31), "0", font=small_font, fill="#303030", anchor="ma")
    draw.text((560, bar_y + 31), f"{margin_limit:.1f}", font=small_font, fill="#303030", anchor="ma")
    for index in range(300):
        fill = mix("#E8F1F8", "#2166AC", index / 299)
        draw.rectangle((1065 + index, bar_y, 1066 + index, bar_y + bar_h), fill=fill)
    draw.text((1065, bar_y + 31), f"{cost_min:.1f}", font=small_font, fill="#303030", anchor="ma")
    draw.text((1365, bar_y + 31), f"{cost_max:.1f}", font=small_font, fill="#303030", anchor="ma")
    draw.text((850, 870), "● 满足全部约束    × 不可行    ★ 最终选定策略", font=axis_font, fill="#303030", anchor="mm")
    image.save(path)


def draw_overtaking_trajectories(history, selected, config: Config, path: Path) -> None:
    image_cls, _, _ = _pillow_components()
    p1, p2 = path.with_name("_longitudinal.png"), path.with_name("_lateral.png")
    t = [float(row["time_s"]) for row in history]
    _line_chart(p1, "三车纵向轨迹", t, [
        ("自车", [float(row["ego_position_m"]) for row in history], "#4472C4", False),
        ("前方慢车", [float(row["leader_position_m"]) for row in history], "#70AD47", False),
        ("对向来车", [float(row["oncoming_position_m"]) for row in history], "#C00000", False),
    ], "纵向位置 / m", size=(1600,540))
    _line_chart(p2, "自车借道超车横向轨迹", t, [
        ("自车横向位置", [float(row["ego_lateral_position_m"]) for row in history], "#4472C4", False),
        ("本车道中心", [0.0 for _ in history], "#70AD47", True),
        ("对向车道中心", [config.lane_width_m for _ in history], "#A5A5A5", True),
    ], "横向位置 / m", size=(1600,520))
    image = image_cls.new("RGB", (1600,1100), "white")
    image.paste(image_cls.open(p1),(0,0))
    image.paste(image_cls.open(p2),(0,580))
    image.save(path)
    p1.unlink(); p2.unlink()


def draw_algorithm_flow(path: Path) -> None:
    image_cls, image_draw, _ = _pillow_components()
    image = image_cls.new("RGB", (1500,1180), "white")
    draw = image_draw.Draw(image)
    title_font, node_font = _font(43, True), _font(29)
    draw.text((750,55), "对向借道超车机会约束Stackelberg决策流程", font=title_font, fill="#1F1F1F", anchor="mm")
    labels = [
        "读取自车、慢车、对向来车状态及超车请求",
        "生成起始延迟与自车加速度候选超车策略",
        "跟随者选择慢车让行和对向来车减速最优响应",
        "预测驶出、超越及返回过程的三车状态",
        "计算对向冲突机会约束与返回安全间隙",
        "筛选可行策略并最小化完成时间、控制与协同代价",
        "生成五次平滑横向轨迹并输出测试结果",
    ]
    ys=[150,300,450,600,750,900,1050]
    for y,label in zip(ys,labels):
        draw.rounded_rectangle((235,y-52,1265,y+52), radius=22, fill="#DCE6F1", outline="#4F81BD", width=4)
        draw.text((750,y), label, font=node_font, fill="#1F1F1F", anchor="mm")
    for y1,y2 in zip(ys,ys[1:]):
        draw.line((750,y1+54,750,y2-56), fill="#4F81BD", width=5)
        draw.polygon([(750,y2-45),(735,y2-67),(765,y2-67)], fill="#4F81BD")
    image.save(path)


def write_outputs(evaluations, selected, history, metrics, config: Config, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir/"plan_evaluation.csv", evaluations)
    write_csv(output_dir/"cooperative_trajectory.csv", history)
    (output_dir/"decision_metrics.json").write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding="utf-8")
    draw_plan_evaluation(evaluations, selected, output_dir/"plan_evaluation.png")
    draw_overtaking_trajectories(history, selected, config, output_dir/"overtaking_trajectories.png")
    draw_algorithm_flow(output_dir/"algorithm_flow.png")


def demo_inputs() -> Tuple[List[VehicleState], OvertakeRequest, Config]:
    states = [
        VehicleState("CAV-E", "ego", 0, 1, 0.0, 18.0),
        VehicleState("CAV-L", "slow_leader", 0, 1, 32.0, 13.0),
        VehicleState("CAV-O", "oncoming", 1, -1, 235.0, 22.0),
    ]
    return states, OvertakeRequest("CAV-E"), Config()


def load_inputs(state_path: Path, request_path: Path, config_path: Path):
    states = [VehicleState(**item) for item in json.loads(state_path.read_text(encoding="utf-8"))]
    request = OvertakeRequest(**json.loads(request_path.read_text(encoding="utf-8")))
    config = Config(**json.loads(config_path.read_text(encoding="utf-8")))
    return states, request, config


def run(states: Sequence[VehicleState], request: OvertakeRequest, config: Config):
    role_map = {state.role: state for state in states}
    if set(role_map) != {"ego","slow_leader","oncoming"}:
        raise ValueError("车辆状态必须且仅包含ego、slow_leader、oncoming三种角色")
    if role_map["ego"].vehicle_id != request.ego_id:
        raise ValueError("超车请求车辆编号与ego角色车辆不一致")
    evaluations, selected = solve_stackelberg_game(role_map, request, config)
    history = simulate_selected(role_map, selected, config)
    metrics = summarize(evaluations, selected, history, config)
    return evaluations, selected, history, metrics


def main() -> None:
    parser = argparse.ArgumentParser(description="对向借道超车机会约束Stackelberg协同决策")
    parser.add_argument("--state", type=Path, help="vehicle_states.json")
    parser.add_argument("--request", type=Path, help="overtake_request.json")
    parser.add_argument("--config", type=Path, help="overtake_config.json")
    parser.add_argument("--output-dir", type=Path, default=Path("data/output"))
    parser.add_argument("--demo", action="store_true", help="运行内置对向借道超车测试场景")
    args = parser.parse_args()
    if args.demo:
        states, request, config = demo_inputs()
    elif args.state and args.request and args.config:
        states, request, config = load_inputs(args.state,args.request,args.config)
    else:
        parser.error("请使用--demo，或同时提供--state、--request和--config")
    evaluations, selected, history, metrics = run(states,request,config)
    write_outputs(evaluations,selected,history,metrics,config,args.output_dir)
    print(json.dumps(metrics,ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
