#!/usr/bin/env python3
"""基于优先级协商的快速路紧急车辆通行走廊协同决策模型。

模型用于三车道城市快速路上紧急车辆从后方接近时，组织联网车辆
通过横向让行和柔性减速共同清空优先通行车道。输入、输出均为 JSON/CSV，
运行 --demo 可生成可复现实验数据和结果。
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple


@dataclass(frozen=True)
class Vehicle:
    vehicle_id: str
    lane: int
    position_m: float
    speed_mps: float
    left_gap_m: float = 0.0
    right_gap_m: float = 0.0
    connected: bool = True


@dataclass(frozen=True)
class EmergencyVehicle:
    vehicle_id: str
    lane: int
    position_m: float
    speed_mps: float
    priority: int = 1


@dataclass(frozen=True)
class CorridorConfig:
    planning_horizon_s: float = 6.0
    clearance_distance_m: float = 130.0
    lane_change_duration_s: float = 2.6
    slow_clearance_duration_s: float = 5.0
    standstill_gap_m: float = 8.0
    headway_s: float = 0.55
    minimum_target_gap_m: float = 20.0
    same_lane_spacing_m: float = 18.0
    max_deceleration_mps2: float = 2.0
    coordination_range_m: float = 145.0
    weight_clearance: float = 24.0
    weight_speed_change: float = 0.35
    weight_lane_change: float = 1.4
    weight_risk: float = 80.0


@dataclass
class Candidate:
    assignments: Dict[str, str]
    score: float
    clearance_time_s: float
    min_gap_m: float
    feasible: bool
    reason: str = ""


def safe_gap(vehicle: Vehicle, config: CorridorConfig) -> float:
    """给出进入目标车道所需的纵向安全间隙。"""
    return max(config.minimum_target_gap_m, config.standstill_gap_m + config.headway_s * vehicle.speed_mps)


def identify_blockers(
    emergency: EmergencyVehicle, vehicles: Sequence[Vehicle], config: CorridorConfig
) -> List[Vehicle]:
    """识别优先车道前方、且位于协同范围内的待清空车辆。"""
    return sorted(
        [
            v
            for v in vehicles
            if v.connected
            and v.lane == emergency.lane
            and 0.0 < v.position_m - emergency.position_m <= config.coordination_range_m
        ],
        key=lambda v: v.position_m,
    )


def allowed_actions(vehicle: Vehicle, config: CorridorConfig) -> List[str]:
    """仅保留满足目标间隙约束的横向让行备选，减速让行作为保底选项。"""
    g = safe_gap(vehicle, config)
    actions = ["slow"]
    if vehicle.lane > 1 and vehicle.left_gap_m >= g:
        actions.append("left")
    if vehicle.lane < 3 and vehicle.right_gap_m >= g:
        actions.append("right")
    return actions


def _target_lane(vehicle: Vehicle, action: str) -> int:
    if action == "left":
        return vehicle.lane - 1
    if action == "right":
        return vehicle.lane + 1
    return vehicle.lane


def _lane_change_target_speed(vehicle: Vehicle, action: str, config: CorridorConfig) -> float:
    if action in ("left", "right"):
        return max(0.0, vehicle.speed_mps - 0.5)
    return max(0.0, vehicle.speed_mps - config.max_deceleration_mps2 * config.lane_change_duration_s)


def evaluate_assignment(
    blockers: Sequence[Vehicle], assignments: Dict[str, str], config: CorridorConfig
) -> Candidate:
    """评估一个协同让行组合，剔除目标车道的纵向重叠。"""
    by_lane: Dict[int, List[Vehicle]] = {1: [], 2: [], 3: []}
    total_speed_change = 0.0
    lane_changes = 0
    clearance_times = []
    min_gap = math.inf

    for vehicle in blockers:
        action = assignments[vehicle.vehicle_id]
        target_lane = _target_lane(vehicle, action)
        target_speed = _lane_change_target_speed(vehicle, action, config)
        by_lane[target_lane].append(vehicle)
        total_speed_change += (vehicle.speed_mps - target_speed) ** 2
        lane_changes += int(action != "slow")
        clearance_times.append(
            config.lane_change_duration_s if action != "slow" else config.slow_clearance_duration_s
        )
        min_gap = min(min_gap, vehicle.left_gap_m if action == "left" else vehicle.right_gap_m if action == "right" else safe_gap(vehicle, config))

    for lane, lane_vehicles in by_lane.items():
        ordered = sorted(lane_vehicles, key=lambda item: item.position_m)
        for first, second in zip(ordered, ordered[1:]):
            gap = second.position_m - first.position_m
            min_gap = min(min_gap, gap)
            if gap < config.same_lane_spacing_m:
                return Candidate(assignments, math.inf, math.inf, min_gap, False, f"车道{lane}目标位置重叠")

    clearance_time = max(clearance_times, default=0.0)
    risk_penalty = 0.0 if min_gap >= config.minimum_target_gap_m else config.weight_risk * (config.minimum_target_gap_m - min_gap)
    score = (
        config.weight_clearance * clearance_time
        + config.weight_speed_change * total_speed_change
        + config.weight_lane_change * lane_changes
        + risk_penalty
    )
    return Candidate(assignments, score, clearance_time, min_gap, True)


def negotiate_corridor(
    emergency: EmergencyVehicle, vehicles: Sequence[Vehicle], config: CorridorConfig
) -> Tuple[Candidate, List[Vehicle], int]:
    """枚举可行动作并返回最小协同代价的优先通行走廊方案。"""
    blockers = identify_blockers(emergency, vehicles, config)
    if not blockers:
        return Candidate({}, 0.0, 0.0, math.inf, True), [], 1

    action_spaces = [allowed_actions(v, config) for v in blockers]
    candidates: List[Candidate] = []
    for actions in itertools.product(*action_spaces):
        assignment = {vehicle.vehicle_id: action for vehicle, action in zip(blockers, actions)}
        candidates.append(evaluate_assignment(blockers, assignment, config))
    feasible = [item for item in candidates if item.feasible]
    if not feasible:
        raise RuntimeError("当前目标间隙和协同范围下不存在安全让行方案")
    return min(feasible, key=lambda item: (item.score, item.clearance_time_s)), blockers, len(feasible)


def build_commands(
    emergency: EmergencyVehicle,
    blockers: Sequence[Vehicle],
    solution: Candidate,
    config: CorridorConfig,
) -> List[Dict[str, object]]:
    commands = []
    for vehicle in blockers:
        action = solution.assignments[vehicle.vehicle_id]
        target_lane = _target_lane(vehicle, action)
        target_speed = _lane_change_target_speed(vehicle, action, config)
        accel = max(-config.max_deceleration_mps2, min(0.0, (target_speed - vehicle.speed_mps) / config.lane_change_duration_s))
        commands.append(
            {
                "vehicle_id": vehicle.vehicle_id,
                "current_lane": vehicle.lane,
                "action": action,
                "target_lane": target_lane,
                "target_speed_mps": round(target_speed, 2),
                "target_acceleration_mps2": round(accel, 2),
                "completion_time_s": round(config.lane_change_duration_s if action != "slow" else config.slow_clearance_duration_s, 2),
                "priority_vehicle_id": emergency.vehicle_id,
            }
        )
    return commands


def solve(payload: Dict[str, object]) -> Dict[str, object]:
    e = payload["emergency_vehicle"]
    emergency = EmergencyVehicle(**e)
    vehicles = [Vehicle(**item) for item in payload["surrounding_vehicles"]]
    config = CorridorConfig(**payload.get("config", {}))
    solution, blockers, feasible_count = negotiate_corridor(emergency, vehicles, config)
    commands = build_commands(emergency, blockers, solution, config)
    corridor_ready_position = emergency.position_m + emergency.speed_mps * solution.clearance_time_s
    return {
        "model": "基于优先级协商的快速路紧急车辆通行走廊协同决策模型",
        "emergency_vehicle": asdict(emergency),
        "blocker_vehicle_ids": [v.vehicle_id for v in blockers],
        "feasible_candidate_count": feasible_count,
        "selected_score": round(solution.score, 3),
        "estimated_clearance_time_s": round(solution.clearance_time_s, 2),
        "minimum_verified_gap_m": round(solution.min_gap_m, 2),
        "corridor_ready_position_m": round(corridor_ready_position, 2),
        "commands": commands,
    }


def demo_payload() -> Dict[str, object]:
    return {
        "emergency_vehicle": {"vehicle_id": "EV-01", "lane": 2, "position_m": 0.0, "speed_mps": 25.0, "priority": 1},
        "surrounding_vehicles": [
            {"vehicle_id": "CAV-01", "lane": 2, "position_m": 35.0, "speed_mps": 22.0, "left_gap_m": 30.0, "right_gap_m": 25.0},
            {"vehicle_id": "CAV-02", "lane": 2, "position_m": 66.0, "speed_mps": 21.0, "left_gap_m": 16.0, "right_gap_m": 31.0},
            {"vehicle_id": "CAV-03", "lane": 2, "position_m": 101.0, "speed_mps": 20.0, "left_gap_m": 28.0, "right_gap_m": 18.0},
            {"vehicle_id": "CAV-04", "lane": 1, "position_m": 53.0, "speed_mps": 21.0, "left_gap_m": 0.0, "right_gap_m": 0.0},
            {"vehicle_id": "CAV-05", "lane": 3, "position_m": 78.0, "speed_mps": 20.0, "left_gap_m": 0.0, "right_gap_m": 0.0},
        ],
        "config": asdict(CorridorConfig()),
    }


def write_results(result: Dict[str, object], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "corridor_decision.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with (output_dir / "yield_commands.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        fields = ["vehicle_id", "current_lane", "action", "target_lane", "target_speed_mps", "target_acceleration_mps2", "completion_time_s", "priority_vehicle_id"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(result["commands"])
    summary = [
        "紧急车辆通行走廊协同决策结果",
        f"可行候选方案数: {result['feasible_candidate_count']}",
        f"预计走廊清空时间(s): {result['estimated_clearance_time_s']}",
        f"最小已核验间隙(m): {result['minimum_verified_gap_m']}",
        f"走廊就绪位置(m): {result['corridor_ready_position_m']}",
    ]
    (output_dir / "decision_summary.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="紧急车辆通行走廊优先级协商模型")
    parser.add_argument("--input", type=Path, help="输入场景 JSON 文件")
    parser.add_argument("--output-dir", type=Path, default=Path("data/output"), help="输出目录")
    parser.add_argument("--demo", action="store_true", help="运行内置城市快速路三车道测试场景")
    args = parser.parse_args()
    if not args.demo and args.input is None:
        parser.error("请提供 --input 场景文件，或使用 --demo 运行内置测试")
    payload = demo_payload() if args.demo else json.loads(args.input.read_text(encoding="utf-8"))
    result = solve(payload)
    write_results(result, args.output_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
