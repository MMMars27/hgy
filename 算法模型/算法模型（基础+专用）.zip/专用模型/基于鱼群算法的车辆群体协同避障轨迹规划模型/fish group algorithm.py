import numpy as np
import matplotlib.pyplot as plt

NUM_FISH = 60
MAP_SIZE = 100
OBSTACLES = [
    [50, 50],
    [20, 80],
    [10, 90],
    [20, 20],
    [20, 40],
    [80, 80]
]
MAX_ITER = 200
DETECT_RANGE = 15
STEP_SIZE = 0.5

def initialize_fish(num_fish, map_size):
    np.random.seed(42)
    fish = []
    for _ in range(num_fish):
        fish.append({
            'position': np.random.rand(2) * map_size,
            'direction': np.random.rand() * 2 * np.pi
        })
    return fish

def calculate_distances(fish, obstacles):
    dist_matrix = []
    for f in fish:
        dists = [np.linalg.norm(f['position'] - np.array(obs)) for obs in obstacles]
        dist_matrix.append(dists)
    return np.array(dist_matrix)

def update_positions(fish, obstacles, detect_range, step_size):
    for i in range(len(fish)):
        current_pos = fish[i]['position'].copy()
        current_dir = fish[i]['direction']
        min_dist = float('inf')
        nearest_obs = None
        for obs in obstacles:
            dist = np.linalg.norm(current_pos - obs)
            if dist < detect_range and dist < min_dist:
                min_dist = dist
                nearest_obs = obs
        if nearest_obs is not None:
            escape_angle = np.arctan2(current_pos[1] - nearest_obs[1],
                                      current_pos[0] - nearest_obs[0])
            current_dir = escape_angle
        dx = step_size * np.cos(current_dir)
        dy = step_size * np.sin(current_dir)
        new_pos = current_pos + np.array([dx, dy])
        if new_pos[0] < 0 or new_pos[0] > MAP_SIZE:
            current_dir = np.pi - current_dir
        if new_pos[1] < 0 or new_pos[1] > MAP_SIZE:
            current_dir = -current_dir
        fish[i]['position'] = new_pos
        fish[i]['direction'] = current_dir % (2 * np.pi)
    return fish

if __name__ == "__main__":
    fish_school = initialize_fish(NUM_FISH, MAP_SIZE)
    plt.figure(figsize=(8, 8))
    for iter in range(MAX_ITER):
        dist_matrix = calculate_distances(fish_school, OBSTACLES)
        print(f"\nIteration {iter + 1}/{MAX_ITER} 障碍物距离矩阵:")
        np.set_printoptions(precision=3, suppress=True)
        print(dist_matrix)
        fish_school = update_positions(fish_school, OBSTACLES, DETECT_RANGE, STEP_SIZE)
        print(f"\nIteration {iter + 1}/{MAX_ITER} 车辆状态:")
        for i, v in enumerate(fish_school):
            pos = np.round(v['position'], 2)
            heading_deg = np.round(np.degrees(v['direction']) % 360, 1)
            print(f"车辆{i + 1}: 坐标({pos[0]:>6.2f}, {pos[1]:>6.2f}) 航向角{heading_deg:>6.1f}°")
        plt.clf()
        plt.xlim(0, MAP_SIZE)
        plt.ylim(0, MAP_SIZE)
        plt.title(f'Fish School Path Planning - Iteration {iter + 1}/{MAX_ITER}')
        for f in fish_school:
            plt.arrow(f['position'][0], f['position'][1],
                      0.5 * np.cos(f['direction']), 0.5 * np.sin(f['direction']),
                      head_width=1, head_length=1, fc='blue', ec='blue')
        for obs in OBSTACLES:
            plt.scatter(obs[0], obs[1], s=200, c='red', marker='o', alpha=0.6)
        plt.pause(0.1)
    plt.show()